"""Offline scripted workspace host. No real model gateway or platform is used."""
from pathlib import Path
import base64
import hashlib
import importlib.util
import json
import math
import os
import queue
import shutil
import subprocess
import sys
import threading
import time

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs/sdk102-agent-v020-20261117'
APP = OUT / 'context/app'
sys.path.insert(0, str(APP))
from official_model import Model
from official_data import flatten

DOCKER = Path(os.environ['LOCALAPPDATA']) / 'Programs/DockerDesktop/resources/bin/docker.exe'
IMAGE = 'zhixun-eric-agent:0.2.0'
ENV = {**os.environ, 'PATH': str(DOCKER.parent) + os.pathsep + os.environ['PATH'], 'PYTHONUTF8': '1'}
RESULTS = []


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def jsonlines(path, rows):
    Path(path).write_text(''.join(json.dumps(row, ensure_ascii=False, allow_nan=False) + '\n' for row in rows), encoding='utf-8')


def receipt(parent, artifact_id):
    checkpoint, = [p for p in parent.rglob('*.npz')]
    code = [p for p in parent.rglob('*.py')]
    files = [{'path': p.relative_to(parent).as_posix(), 'sha256': 'sha256:' + sha(p), 'size_bytes': p.stat().st_size}
             for p in [checkpoint, *code]]
    artifact = {'checkpoint_paths': [checkpoint.relative_to(parent).as_posix()],
                'code_paths': [p.relative_to(parent).as_posix() for p in code],
                'predict_argv': ['python3', '/app/harness.py', 'predict']}
    summary = {'artifact': artifact, 'files': files}
    digest = hashlib.sha256(json.dumps(summary, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    return {'artifact_id': artifact_id, 'artifact_sha256': 'sha256:' + digest, **summary}


def container_args(parent=None, data=None, work=None, state=None):
    args = [str(DOCKER), 'run', '--rm', '-i', '--network', 'none', '--read-only', '--cpus', '2',
            '--memory', '1536m', '--pids-limit', '64', '--tmpfs', '/tmp:rw,noexec,nosuid,size=64m']
    for source, target, readonly in ((parent, '/previous', True), (data, '/data', True),
                                     (work, '/workspace', False), (state, '/state', True)):
        if source:
            args += ['--mount', 'type=bind,source=' + str(source.resolve()) + ',target=' + target + (',readonly' if readonly else '')]
    return args


def fixture(key, official=False):
    case = OUT / 'fixtures' / (('official-' if official else 'synthetic-') + key)
    case.mkdir(parents=True, exist_ok=False)
    parent, data = case / 'parent', case / 'data'
    (parent / 'baselines').mkdir(parents=True)
    data.mkdir()
    task = 'classification' if key == 'A' else 'regression'
    if official:
        package = {'A': 'cpu-a-guide-20261110-v1', 'B': 'cpu-b-rul-20261110-v1', 'C': 'cpu-c-guide-20261110-v1'}[key]
        original = ROOT / 'inputs/official-platform-2026-11-11' / package
        shutil.copyfile(original / 'checkpoint.npz', parent / 'baselines/checkpoint.npz')
        for name, count in (('train', 32), ('validation', 8)):
            rows = [json.loads(line) for line in (original / 'public' / (name + '.jsonl')).read_text('utf-8').splitlines() if line.strip()][:count]
            jsonlines(data / (name + '.jsonl'), [{k: row[k] for k in ('id', 'inputs', 'answer')} for row in rows])
    else:
        x = np.asarray([[i / 10, (i % 7) / 4] for i in range(32)], dtype=np.float64)
        paths, _ = flatten({'sensor': x[0].tolist()})
        y = np.asarray([i % 2 for i in range(len(x))], dtype=np.int64) if key == 'A' else x[:, 0] * 3 + 1
        model = Model(task, paths, ['normal', 'fault'] if key == 'A' else [], x, y, hidden=4, batch_size=8)
        model.fit(x, y, 1)
        model.save(parent / 'baselines/checkpoint.npz')
        for name, offset, count in (('train', 0, 32), ('validation', 100, 8)):
            rows = [{'id': name + '-' + str(i), 'inputs': {'sensor': x[i].tolist()},
                     'answer': ['normal', 'fault'][int(y[i])] if key == 'A' else float(y[i])} for i in range(count)]
            jsonlines(data / (name + '.jsonl'), rows)
    shutil.copyfile(APP / 'official_model.py', parent / 'baselines/model.py')
    return case, parent, data


def host_round(name, key, parent, data, mode='accept', state=None, history=(), round_index=1, reference=False, parent_artifact_id=None):
    case = OUT / 'integration' / name
    case.mkdir(parents=True, exist_ok=False)
    work = case / 'workspace'
    work.mkdir()
    par = receipt(parent, parent_artifact_id or ('parent-' + name))
    before_path, = list(parent.rglob('*.npz'))
    before = Model.load(before_path)
    frame = {'protocol': 'contest.harness.workspace.v2', 'run_id': name, 'dataset_key': key,
             'round_index': round_index, 'stage_id': 'offline-contract-test',
             'prompt': 'OFFICIAL_PROMPT_HOST_ONLY', 'prompt_version': 'industrial-workspace-flexible-v3',
             'model_name': 'scripted-no-api', 'max_output_tokens': 1024, 'wall_seconds': 90,
             'task_contract': {'dataset_key': key, 'task': before.meta['task'],
                               'metric': 'macro_f1' if key == 'A' else 'rmse',
                               'metric_direction': 'higher' if key == 'A' else 'lower',
                               'public_projection': {'train_path': '/data/train.jsonl', 'validation_path': '/data/validation.jsonl'}},
             'parent_artifact': par, 'parent_checkpoint_sha256': 'sha256:' + sha(before_path),
             'artifacts': [par], 'current_validation': {'metrics': {'rmse': 10}},
             'state_path': '/state' if state else None, 'state_sha256': 'sha256:' + '1' * 64 if state else '',
             'resource_limits': {'candidate_upload_bytes_per_round': 64 * 1024**2}}
    if mode == 'tampered-parent':
        frame['parent_artifact']['files'][0]['sha256'] = 'sha256:' + '0' * 64
    args = container_args(parent, data, work, state) + ['--entrypoint', 'python3', IMAGE, '/app/harness.py', 'train']
    stderr_path = case / 'stderr.txt'
    frames, calls, state_saves, candidates = [], [], [], []
    record = None
    output_queue = queue.Queue()
    with stderr_path.open('wb') as stderr:
        process = subprocess.Popen(args, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=stderr,
                                   env=ENV, text=True, encoding='utf-8', bufsize=1)
        def read():
            for line in process.stdout:
                output_queue.put(line)
            output_queue.put(None)
        threading.Thread(target=read, daemon=True).start()
        def send(value):
            process.stdin.write(json.dumps(value, ensure_ascii=False, allow_nan=False) + '\n')
            process.stdin.flush()
        send(frame)
        try:
            for _ in range(30):
                line = output_queue.get(timeout=100)
                if line is None:
                    break
                request = json.loads(line)
                frames.append(request)
                kind = request['type']
                if kind == 'round_failed':
                    break
                if kind == 'round_complete':
                    record = request['record']
                    send({'type': 'round_ack', 'accepted': True})
                    break
                reply = {'id': request['id']}
                if kind == 'history_request':
                    reply.update(type='history_response', records=list(history))
                elif kind == 'state_request':
                    assert request['parent_state_sha256'] == frame['state_sha256']
                    saved = case / ('state-' + str(len(state_saves)))
                    saved.mkdir()
                    for item in request['files']:
                        target = saved / item['path']
                        target.parent.mkdir(parents=True, exist_ok=True)
                        target.write_bytes(base64.b64decode(item['data_base64'], validate=True))
                    state_saves.append(saved)
                    reply.update(type='state_response', state_sha256='sha256:' + '2' * 64)
                elif kind == 'model_request':
                    assert all('OFFICIAL_PROMPT_HOST_ONLY' not in message.get('content', '') for message in request['messages'])
                    assert request['max_tokens'] == 1024 and request['enable_thinking'] is False
                    context = json.loads(request['messages'][0]['content'])
                    calls.append(context)
                    if context['phase'] == 'propose':
                        action = {'action': 'train', 'hypothesis': 'Offline fixed continuation test.', 'epochs': 1,
                                  'lr_factor': 0.5, 'batch_factor': 1, 'weight_power': 0.5 if key == 'A' else 0}
                        if mode == 'retain':
                            action = {'action': 'retain', 'hypothesis': 'Keep this exact mounted parent.'}
                        if mode == 'invalid-proposal' and len(calls) == 1 or mode == 'invalid-proposals':
                            action = {'action': 'train', 'epochs': 999}
                    else:
                        action = {'action': 'reject' if mode == 'reject' else 'accept', 'reason': 'Scripted offline host result reviewed.'}
                        if mode == 'invalid-decisions':
                            action = {'action': 'finish'}
                    reply.update(type='model_response', call_id='offline-' + str(len(calls)),
                                 response={'choices': [{'message': {'content': json.dumps(action)}, 'finish_reason': 'stop'}],
                                           'usage': {'prompt_tokens': 10, 'completion_tokens': 10}})
                    if mode == 'no-call-receipt':
                        reply.pop('call_id')
                elif kind == 'candidate_request':
                    assert request['parent_checkpoint_sha256'] == frame['parent_checkpoint_sha256']
                    assert request['parent_artifact_id'] == par['artifact_id']
                    assert state_saves, 'training must reserve in host state before candidate'
                    reserved = json.loads((state_saves[0] / 'agent-ledger.json').read_text('utf-8'))
                    assert any(e['event'] == 'training_reserved' for e in reserved['rounds'][-1]['events'])
                    artifact = case / 'submitted'
                    artifact.mkdir()
                    for item in request['files']:
                        assert '..' not in item['path'].split('/')
                        target = artifact / item['path']
                        target.parent.mkdir(parents=True, exist_ok=True)
                        target.write_bytes(base64.b64decode(item['data_base64'], validate=True))
                    child = Model.load(artifact / 'checkpoint.npz')
                    meta = child.meta
                    assert meta['epochs'] == before.meta['epochs'] + 1
                    assert meta['seed'] == before.meta['seed']
                    assert np.array_equal(child.mean, before.mean) and np.array_equal(child.scale, before.scale)
                    assert meta['target_mean'] == before.meta['target_mean'] and meta['target_scale'] == before.meta['target_scale']
                    assert any(not np.array_equal(child.first[k], before.first[k]) for k in before.first)
                    assert any(not np.array_equal(child.params[k], before.params[k]) for k in before.params)
                    training_receipt = json.loads((artifact / 'training-receipt.json').read_text('utf-8'))
                    assert training_receipt['python'] == '3.12.14' and training_receipt['numpy'] == '1.26.4'
                    assert training_receipt['parent_sha256'] == sha(before_path)
                    assert training_receipt['training_rows'] == 32
                    if reference:
                        spec = importlib.util.spec_from_file_location('reference_' + name, artifact / 'model.py')
                        module = importlib.util.module_from_spec(spec)
                        spec.loader.exec_module(module)
                        direct = module.Model.load(before_path)
                        direct.meta['learning_rate'] *= 0.5
                        rows = [json.loads(line) for line in (data / 'train.jsonl').read_text('utf-8').splitlines()]
                        x = np.asarray([flatten(row['inputs'])[1] for row in rows], dtype=np.float64)
                        y = np.asarray([direct.meta['classes'].index(row['answer']) if key == 'A' else row['answer'] for row in rows])
                        direct.fit(x, y, 1)
                        for group in ('params', 'first', 'second'):
                            for k, value in getattr(direct, group).items():
                                np.testing.assert_allclose(getattr(child, group)[k], value, rtol=0, atol=1e-9)
                        assert direct.meta == child.meta
                    # Host stand-in measures the candidate; agent receives this RPC result.
                    rows = [json.loads(line) for line in (data / 'validation.jsonl').read_text('utf-8').splitlines()]
                    x = np.asarray([flatten(row['inputs'])[1] for row in rows], dtype=np.float64)
                    predicted = child.predict(x)
                    target = np.asarray([child.meta['classes'].index(row['answer']) if key == 'A' else row['answer'] for row in rows])
                    score = float(np.mean(np.argmax(predicted, axis=1) == target)) if key == 'A' else float(np.sqrt(np.mean((predicted - target)**2)))
                    candidates.append(artifact)
                    reply.update(type='candidate_response', artifact_id='candidate-' + name,
                                 summary={'metrics': {'accuracy' if key == 'A' else 'rmse': score}, 'source': 'offline_host_measurement'})
                else:
                    raise AssertionError('Unexpected frame ' + kind)
                send(reply)
            process.stdin.close()
            code = process.wait(timeout=20)
        except BaseException:
            process.kill()
            process.wait()
            raise
    dump(case / 'frames.json', frames)
    dump(case / 'start.json', frame)
    expected_failure = mode in ('tampered-parent', 'no-call-receipt', 'unsupported-source')
    if expected_failure:
        assert code != 0 and record is None, stderr_path.read_text('utf-8')
    else:
        assert code == 0 and record is not None, stderr_path.read_text('utf-8')
        assert record['model_call_ids'] == ['offline-' + str(i + 1) for i in range(len(calls))]
        assert record['history_ids'] == [row['id'] for row in history]
        expected_selection = 'candidate-' + name if mode in ('accept', 'invalid-proposal') else par['artifact_id']
        assert record['selected_artifact_id'] == expected_selection
    result = {'name': name, 'passed': True, 'mode': mode, 'exit_code': code, 'gateway_is_scripted': True,
              'fake_requests': len(calls), 'candidates': len(candidates), 'state_saves': len(state_saves),
              'selected': record['selected_artifact_id'] if record else None}
    RESULTS.append(result)
    print(json.dumps(result), flush=True)
    return case, record, candidates[-1] if candidates else None, state_saves[-1] if state_saves else None


def prediction_test(name, key, directory, data):
    checkpoint, = list(directory.rglob('*.npz'))
    model = Model.load(checkpoint)
    rows = [json.loads(line) for line in (data / 'validation.jsonl').read_text('utf-8').splitlines()][:2]
    context = {'protocol': 'contest.predict-context.v1', 'dataset_key': key, 'task': model.meta['task'],
               'artifact_id': name, 'artifact': {'checkpoint_paths': [checkpoint.relative_to(directory).as_posix()]}}
    args = container_args() + ['--mount', 'type=bind,source=' + str(directory.resolve()) + ',target=/model,readonly',
                             '-e', 'CONTEST_ARTIFACT_PATH=/model/' + checkpoint.relative_to(directory).as_posix(),
                             '-e', 'CONTEST_PREDICTION_CONTEXT=' + json.dumps(context),
                             '--entrypoint', 'python3', IMAGE, '/app/harness.py', 'predict']
    process = subprocess.Popen(args, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               text=True, encoding='utf-8', env=ENV, bufsize=1)
    output = queue.Queue()
    def read():
        for line in process.stdout:
            output.put(line)
    threading.Thread(target=read, daemon=True).start()
    replies = []
    try:
        for row in rows:
            process.stdin.write(json.dumps({'task': model.meta['task'], 'inputs': row['inputs']}) + '\n')
            process.stdin.flush()
            # Wait BEFORE sending next row or EOF: detects buffered batch implementations.
            result = json.loads(output.get(timeout=15))['outputs']
            prediction = model.predict(np.asarray([flatten(row['inputs'])[1]], dtype=np.float64))[0]
            if key == 'A':
                assert max(result, key=lambda item: item['score'])['label'] == model.meta['classes'][int(np.argmax(prediction))]
                assert len([r for r in result if r['score'] == max(p['score'] for p in result)]) == 1
                if len(result) > 1:
                    assert max(abs(p['score'] - float(prediction[model.meta['classes'].index(p['label'])])) for p in result) <= 1e-12
            else:
                assert math.isfinite(result['value']) and result['value'] >= 0
                assert abs(result['value'] - float(prediction)) <= 1e-9
            replies.append(result)
        process.stdin.close()
        assert process.wait(timeout=15) == 0, process.stderr.read()
    finally:
        if process.poll() is None:
            process.kill()
            process.wait()
    dump(OUT / ('prediction-' + name + '.json'), {'passed': True, 'responses_before_next_line_and_eof': True, 'outputs': replies})
    print('prediction passed:', name, flush=True)


def main():
    plan = json.loads((OUT / 'FROZEN-LOCAL-PLAN.json').read_text('utf-8'))
    assert all(sha(OUT / 'context' / name) == value for name, value in plan['context_files'].items())
    fixtures = {key: fixture(key) for key in 'ABC'}
    first_a = None
    for key in 'ABC':
        _, parent, data = fixtures[key]
        result = host_round('normal-' + key, key, parent, data, reference=True)
        prediction_test('normal-' + key, key, result[2], data)
        if key == 'A':
            first_a = result
    case, record, artifact, state = first_a
    history = [{'id': 'history-1', **record}]
    result = host_round('second-round-A', 'A', artifact, fixtures['A'][2], state=state, history=history, round_index=2, reference=True)
    prediction_test('second-round-A', 'A', result[2], fixtures['A'][2])
    for mode in ('retain', 'reject', 'invalid-proposal', 'invalid-proposals', 'invalid-decisions', 'tampered-parent', 'no-call-receipt'):
        host_round(mode, 'A', fixtures['A'][1], fixtures['A'][2], mode=mode)
    bad_data = OUT / 'fixtures' / 'worker-failure-data'
    shutil.copytree(fixtures['B'][2], bad_data)
    rows = [json.loads(line) for line in (bad_data / 'train.jsonl').read_text('utf-8').splitlines()]
    for row in rows:
        row['answer'] = 1e308
    jsonlines(bad_data / 'train.jsonl', rows)
    result = host_round('worker-failure', 'B', fixtures['B'][1], bad_data, mode='failed-fit')
    ledger = json.loads((result[3] / 'agent-ledger.json').read_text('utf-8'))
    events = ledger['rounds'][-1]['events']
    assert len([e for e in events if e['event'] == 'training_reserved']) == 1
    assert any(e['event'] == 'training_failed' and e['budget_retained'] for e in events)
    bad_parent = OUT / 'fixtures' / 'unsupported-parent'
    shutil.copytree(fixtures['A'][1], bad_parent)
    (bad_parent / 'baselines/model.py').write_text('raise RuntimeError("must never execute")\n', encoding='utf-8')
    host_round('unsupported-source', 'A', bad_parent, fixtures['A'][2], mode='unsupported-source')
    for key in 'ABC':
        _, parent, data = fixture(key, official=True)
        result = host_round('official-subset-' + key, key, parent, data)
        prediction_test('official-subset-' + key, key, result[2], data)
    # Exact ties must be valid and deterministic under the SDK output contract.
    tied = OUT / 'fixtures' / 'tie-parent'
    tied.mkdir()
    model = Model.load(next(fixtures['A'][1].rglob('*.npz')))
    model.params['w2'][:] = 0
    model.params['b2'][:] = 0
    model.save(tied / 'checkpoint.npz')
    prediction_test('tie-A', 'A', tied, fixtures['A'][2])
    audit = {'passed': True, 'scenarios': RESULTS, 'source_plan_sha256': sha(OUT / 'FROZEN-LOCAL-PLAN.json'),
             'real_api_calls': 0, 'platform_operations': 0, 'official_subset_fits': 3,
             'synthetic_initialization_fits': 3, 'synthetic_reference_fits': 4,
             'scripted_gateway_not_real_qwen': True, 'platform_acceptance_verified': False}
    dump(OUT / 'integration-audit.json', audit)


if __name__ == '__main__':
    main()
