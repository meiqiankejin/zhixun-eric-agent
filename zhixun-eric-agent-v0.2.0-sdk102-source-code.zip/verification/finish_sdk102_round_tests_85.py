import json
from test_sdk102_image_85 import OUT, host_round, dump

audit_path = OUT / 'integration-audit.json'
audit = json.loads(audit_path.read_text('utf-8'))
second = OUT / 'integration/second-round-A'
frames = json.loads((second / 'frames.json').read_text('utf-8'))
record = next(frame['record'] for frame in frames if frame['type'] == 'round_complete')
history = [{'id': 'history-2', **record}]
state = second / 'state-2'
parent = second / 'submitted'
selected_id = record['selected_artifact_id']
extra = []
for index in range(3, 11):
    case, record, _, state = host_round('round-' + str(index) + '-retain-A', 'A', parent,
                                      OUT / 'fixtures/synthetic-A/data', mode='retain',
                                      state=state, history=history, round_index=index,
                                      parent_artifact_id=selected_id)
    assert record['selected_artifact_id'] == selected_id
    history.append({'id': 'history-' + str(index), **record})
    ledger = json.loads((state / 'agent-ledger.json').read_text('utf-8'))
    assert len(ledger['rounds']) == index
    extra.append({'round_index': index, 'selected_artifact_id': selected_id,
                  'history_ids': record['history_ids'], 'passed': True, 'new_fits': 0})
dump(OUT / 'ten-round-audit.json', {'passed': True, 'rounds': 10, 'last_eight': extra,
                                  'scripted_gateway': True, 'official_platform_operations': 0})
print('Ten-round state/history contract passed; no added fits.')
