# 智训引擎 Agent v0.2.0（SDK 1.0.2）

上传镜像选择 `zhixun-eric-agent-0.2.0-linux-amd64.tar`，这是未压缩的 docker save tar；不要选源码 ZIP。
镜像名称：`zhixun-eric-agent:0.2.0`。文件约 84.85 MB。
源码仓库：https://github.com/meiqiankejin/zhixun-eric-agent
源码仓库的 v0.2.0 归档对应本版；旧 v0.1.0 归档保留供历史核对。
镜像 SHA256：`cc0128032c5d64db3014689765421d470580a0bd27d5ba48f59a7d1156d42d80`。

平台命令按 SDK：
```
python3 /app/harness.py describe
python3 /app/harness.py train
python3 /app/harness.py predict
```
默认启动仅 describe。train 必须由宿主写 start 帧并回复 RPC；手动运行后等输入属正常，不能仅靠启动判定训练失败。

本版使用 host_gateway_rpc：密钥和端点由平台持有，不填进镜像，不需要把个人 API Key 上传。
每轮读取真实 history、声明并校验 /previous 父模型，只用 /data 的公开训练投影拟合；宿主测量候选后再请求模型选择。
支持 A 分类、B/C 回归的官方 contest.cpu-mlp.v1 检查点；标准化、目标缩放、Adam、种子继承。
A 提供受审核的权重幂0/0.5/1模板（幂0为官方原代码）；B/C为原代码受限配方。不是任意写代码。
每轮最多1候选、1到3 epoch、2048步、4次网关请求，每次最多1536输出Token或平台更小上限。
候选被拒/训练失败不重试拟合、不退预算，保留父模型。无有效网关回执时失败退出，不伪造成功。
不支持自动恢复任意历史架构、自由代码生成、自动回滚到更早产物；不证明策略收益或乙醛问题解决。

已验证：SDK原样15测试在Windows与Linux均通过；16个独立宿主情形、A连续10轮（后8轮保留）、8组两行逐行预测。
容器训练使用Linux/Python3.12.14/NumPy1.26.4；只有合成训练与各任务前32条公开train样本的兼容检查。
宿主/千问回复是本地替身；真实网关、平台正式验收、云端同步尚未实测。本版未上传平台、未使用比赛次数。
Codex自查，未经Claude复核，目前无待Claude反馈。

重新构建：完整构建ZIP解压后，Docker可离线安装已锁定依赖；需先取得Dockerfile所锁的Python基础镜像。
```
docker build --platform linux/amd64 --network none -t zhixun-eric-agent:0.2.0 context
docker save -o zhixun-eric-agent-0.2.0-linux-amd64.tar zhixun-eric-agent:0.2.0
```
源码/上下文可核对，不保证不同构建器生成完全相同的tar字节。
