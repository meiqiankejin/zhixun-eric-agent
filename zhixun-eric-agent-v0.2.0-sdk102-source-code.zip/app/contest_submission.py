"""SDK 1.0.2 participant: host gateway, mounted parents, one candidate per round.

Supports the official contest.cpu-mlp.v1 checkpoint family. No bundled weights,
datasets, provider client, network endpoint, or credentials are used.
"""
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

import numpy as np
from contest_harness.errors import HarnessError
from official_data import flatten, read_dataset
from official_model import Model
from templates import source, difference, supported_model_source

TASKS = ('classification', 'regression')
VERSION = '0.2.0'
MAX_REQUESTS = 4
MAX_EPOCHS = 3
MAX_STEPS = 2048
MAX_TOKENS = 1536
APP = Path(__file__).resolve().parent
_CACHE = {}


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    Path(path).write_text(canonical(value) + '\n', encoding='utf-8')


def task_check(key, task, model):
    if key not in ('A', 'B', 'C') or task != ('classification' if key == 'A' else 'regression'):
        raise ValueError('dataset_task_mismatch')
    if model.meta['task'] != task:
        raise ValueError('parent_task_mismatch')


def recipe_for(action, parent, task, rows):
    if not isinstance(action, dict) or action.get('action') not in ('train', 'retain'):
        raise ValueError('action_must_be_train_or_retain')
    hypothesis = action.get('hypothesis')
    if not isinstance(hypothesis, str) or not 1 <= len(hypothesis.encode('utf-8')) <= 2000:
        raise ValueError('hypothesis_required_max_2000_bytes')
    if action['action'] == 'retain':
        if set(action) != {'action', 'hypothesis'}:
            raise ValueError('retain_fields_invalid')
        return None
    if set(action) != {'action', 'hypothesis', 'epochs', 'lr_factor', 'batch_factor', 'weight_power'}:
        raise ValueError('train_fields_invalid')
    epochs, lr, batch, power = (action[k] for k in ('epochs', 'lr_factor', 'batch_factor', 'weight_power'))
    if type(epochs) is not int or not 1 <= epochs <= MAX_EPOCHS:
        raise ValueError('epochs_outside_1_3')
    for value, options, name in ((lr, (1/3, 0.5, 1.0), 'lr_factor'),
                                  (batch, (1, 2), 'batch_factor'), (power, (0, 0.5, 1), 'weight_power')):
        if type(value) not in (int, float) or value not in options:
            raise ValueError(name + '_outside_allowlist')
    if task != 'classification' and power != 0:
        raise ValueError('regression_requires_weight_power_zero')
    batch_size = min(65536, parent.meta['batch_size'] * batch)
    steps = math.ceil(rows / batch_size) * epochs
    if steps > MAX_STEPS:
        raise ValueError('training_step_limit_exceeded_choose_larger_batch_or_fewer_epochs')
    return {'epochs': epochs, 'learning_rate': parent.meta['learning_rate'] * lr,
            'batch_size': batch_size, 'weight_power': power, 'steps': steps}


def ask(rnd, context, validate, events, deadline):
    feedback = []
    for ordinal in (1, 2):
        if sum(item['event'] == 'model_reserved' for item in events) >= MAX_REQUESTS:
            break
        if time.monotonic() >= deadline - 5:
            break
        events.append({'event': 'model_reserved', 'phase': context['phase'], 'ordinal': ordinal})
        try:
            # The host attaches its official prompt. Never include rnd.prompt again.
            receipt = rnd.model([{'role': 'user', 'content': canonical({**context, 'feedback': feedback})}],
                                max_tokens=min(MAX_TOKENS, rnd.max_output_tokens), temperature=0,
                                enable_thinking=False, response_format={'type': 'json_object'})
            events.append({'event': 'model_returned', 'call_id': receipt.call_id,
                           'response': receipt.response, 'phase': context['phase']})
            body = json.loads(receipt.text)
            validate(body)
            return body
        except (ValueError, TypeError, KeyError, HarnessError) as error:
            feedback.append({'error': str(error)[:500]})
            events.append({'event': 'model_or_action_error', 'phase': context['phase'], 'error': str(error)[:500]})
    return None


def train(rnd):
    started = time.monotonic()
    seconds = rnd.wall_seconds
    if seconds is None:
        seconds = 600
    if type(seconds) not in (int, float) or not math.isfinite(seconds) or seconds <= 0:
        raise ValueError('wall_seconds_invalid')
    deadline = started + seconds
    if rnd.round_index > 10:
        raise ValueError('round_index_exceeds_supported_ten_rounds')
    task = rnd.task.get('task')
    if rnd.task.get('dataset_key', rnd.dataset_key) != rnd.dataset_key:
        raise ValueError('contract_dataset_mismatch')
    declared = rnd.parent.declared_paths()
    if len(declared) != len(set(declared)) or len(rnd.parent.descriptor['checkpoint_paths']) != 1:
        raise ValueError('single_checkpoint_required')
    parent_paths = {name: rnd.parent.path(name) for name in declared}
    checkpoint = parent_paths[rnd.parent.descriptor['checkpoint_paths'][0]]
    if digest(checkpoint) != rnd.parent.checkpoint_sha256.removeprefix('sha256:'):
        raise ValueError('parent_checkpoint_summary_mismatch')
    for name, path in parent_paths.items():
        if Path(name).name in ('model.py', 'official_model.py') and not supported_model_source(path.read_bytes()):
            raise ValueError('unsupported_parent_model_source')
    parent = Model.load(checkpoint)
    task_check(rnd.dataset_key, task, parent)
    # Only the SDK-declared public projection is read. Validation is never passed
    # to the worker and no local validation scores are substituted for host scores.
    data = read_dataset(rnd.data.train_path, task, parent.meta['classes'], parent.meta['paths'])
    history = rnd.history()
    work = Path('/workspace')
    work.mkdir(parents=True, exist_ok=True)
    state = rnd.state_workspace(work / 'agent-state')
    ledger_path = state / 'agent-ledger.json'
    ledger = json.loads(ledger_path.read_text(encoding='utf-8')) if ledger_path.exists() else {'version': VERSION, 'rounds': []}
    if not isinstance(ledger, dict) or not isinstance(ledger.get('rounds'), list):
        raise ValueError('agent_state_invalid')
    events = []
    def persist(status):
        entry = {'dataset_key': rnd.dataset_key, 'round_index': rnd.round_index,
                 'stage_id': rnd.stage_id, 'parent_artifact_id': rnd.parent.artifact_id,
                 'parent_checkpoint_sha256': rnd.parent.checkpoint_sha256,
                 'status': status, 'events': events}
        # State is evidence/experience only. Host history and parent are authoritative.
        write(ledger_path, {**ledger, 'rounds': (ledger['rounds'] + [entry])[-10:]})
        rnd.save_state(state)
    def reserve_fit():
        events.append({'event': 'training_reserved', 'recipe': recipe, 'budget_retained_on_failure': True})
        persist('training_reserved')
    configuration = {'agent_version': VERSION, 'max_candidates_this_round': 1,
                     'max_gateway_requests': MAX_REQUESTS, 'max_epochs': MAX_EPOCHS,
                     'max_steps': MAX_STEPS, 'max_output_tokens_per_request': min(MAX_TOKENS, rnd.max_output_tokens),
                     'parent_artifact_id': rnd.parent.artifact_id, 'train_sha256': data['sha256'],
                     'metric': rnd.task.get('metric'), 'metric_direction': rnd.task.get('metric_direction'),
                     'selection_policy': 'qwen_host_measurements_no_developer_score_gate'}
    context = {'phase': 'propose', 'instruction': 'Return one JSON object. Use history and the actual parent. '
               'Either {action:retain,hypothesis:string}, or {action:train,hypothesis:string,epochs:int 1..3,'
               'lr_factor:one of [0.3333333333333333,0.5,1],batch_factor:one of [1,2],'
               'weight_power:one of [0,0.5,1] for classification and 0 for regression}. '
               'These are reviewed templates, not arbitrary code. No early stopping or feature changes. '
               'At most one candidate, 2048 gradient steps; seed and normalization/Adam are inherited. '
               'Do not invent experiments, hidden results, or effects. Projections contain authorized training labels only.',
               'dataset_key': rnd.dataset_key, 'round_index': rnd.round_index,
               'parent': parent.meta, 'training_rows': len(data['x']), 'contract': rnd.task,
               'current_validation': rnd.frame.get('current_validation', {}),
               'history': bounded_history(history), 'history_ids_read': rnd.history_ids,
               'source_fit': source(0).split('    def fit(', 1)[1].split('    def predict(', 1)[0],
               'configuration': configuration}
    action = ask(rnd, context, lambda body: recipe_for(body, parent, task, len(data['x'])), events, deadline)
    selected = rnd.parent.artifact_id
    hypothesis = (action or {}).get('hypothesis', 'No valid proposal returned within the declared request budget; preserve the mounted parent.')
    reason = 'Model chose to retain the parent.' if action else 'Current-round fallback: invalid or failed proposal; no training.'
    change = 'Parent retained; no parameter changes.'
    if action and action['action'] == 'train':
        recipe = recipe_for(action, parent, task, len(data['x']))
        configuration['recipe'] = recipe
        directory = work / 'candidate'
        directory.mkdir(exist_ok=False)
        (directory / 'model.py').write_text(source(recipe['weight_power']), encoding='utf-8', newline='\n')
        shutil.copyfile(APP / 'official_data.py', directory / 'data.py')
        (directory / 'patch.diff').write_text(difference(recipe['weight_power']), encoding='utf-8', newline='\n')
        arrays = work / 'train-only.npz'
        np.savez(arrays, x=data['x'], y=data['y'])
        request = work / 'worker-request.json'
        write(request, {'directory': str(directory), 'parent': str(checkpoint),
                        'train_arrays': str(arrays), 'recipe': recipe})
        reserve_fit()
        remaining = min(300, deadline - time.monotonic() - 20)
        try:
            if remaining < 1:
                raise TimeoutError('insufficient_worker_wall_time')
            with (work / 'worker-stderr.txt').open('wb') as stderr:
                result = subprocess.run([sys.executable, '-B', str(APP / 'worker.py'), str(request)],
                                        stdin=subprocess.DEVNULL, stdout=stderr, stderr=stderr, timeout=remaining,
                                        env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'OPENBLAS_NUM_THREADS': '1',
                                             'OMP_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1'})
            if result.returncode:
                raise RuntimeError('worker_failed_exit_' + str(result.returncode))
            child = Model.load(directory / 'checkpoint.npz')
            expected = {**parent.meta, 'epochs': parent.meta['epochs'] + recipe['epochs'],
                        'steps': parent.meta['steps'] + recipe['steps'],
                        'learning_rate': recipe['learning_rate'], 'batch_size': recipe['batch_size']}
            if child.meta != expected or not np.array_equal(child.mean, parent.mean) or not np.array_equal(child.scale, parent.scale):
                raise ValueError('child_inheritance_mismatch')
        except (subprocess.TimeoutExpired, TimeoutError, RuntimeError) as error:
            events.append({'event': 'training_failed', 'error': str(error)[:500], 'budget_retained': True})
            reason = 'Training failed or timed out; retain the verified parent without retrying the fit.'
        else:
            change = 'Continue the mounted parent with inherited Adam/scalers; reviewed weighted-CE template for A, original regression fit for B/C.'
            write(directory / 'provenance.json', {**configuration, 'parent_checkpoint_sha256': rnd.parent.checkpoint_sha256,
                                                 'model_source_sha256': digest(directory / 'model.py')})
            persist('candidate_ready')
            submitted = rnd.submit_candidate(directory, hypothesis=hypothesis, change_summary=change,
                                             configuration=configuration, seed=parent.meta['seed'],
                                             checkpoint_paths=['checkpoint.npz'], code_paths=['model.py', 'data.py'],
                                             predict_argv=['python3', '/app/harness.py', 'predict'])
            events.append({'event': 'candidate_measured', 'receipt': submitted})
            def valid_decision(body):
                if not isinstance(body, dict) or set(body) != {'action', 'reason'} or body['action'] not in ('accept', 'reject'):
                    raise ValueError('decision_must_be_accept_or_reject_with_reason')
                if not isinstance(body['reason'], str) or not 1 <= len(body['reason'].encode('utf-8')) <= 2000:
                    raise ValueError('reason_required_max_2000_bytes')
            decision = ask(rnd, {'phase': 'decide', 'instruction': 'Return {action:accept|reject,reason:string}. '
                                'Choose the measured candidate or keep the parent using host measurements and the official objective. '
                                'No private threshold is an official scoring rule. If results are missing or uncertain, reject. '
                                'The candidate has already used its fit budget, even if rejected.',
                                'proposal': action, 'candidate_receipt': submitted,
                                'parent_validation': rnd.frame.get('current_validation', {}),
                                'task_contract': rnd.task, 'history': bounded_history(history)},
                           valid_decision, events, deadline)
            if decision and decision['action'] == 'accept':
                selected = submitted['artifact_id']
                reason = decision['reason']
            else:
                reason = decision['reason'] if decision else 'Current-round fallback: no valid decision; parent retained.'
                change += ' Candidate rejected; selected parent unchanged.'
    if not rnd.call_ids:
        # SDK requires a real host receipt even when retaining. Never fabricate one.
        persist('gateway_failed_no_receipt')
        raise HarnessError('MODEL_CALL_REQUIRED', 'No host model receipt; no fabricated successful round.')
    configuration['selected_artifact_id'] = selected
    events.append({'event': 'selection', 'artifact_id': selected, 'reason': reason,
                   'history_ids': rnd.history_ids, 'model_call_ids': rnd.call_ids})
    persist('finishing')
    rnd.finish(selected_artifact_id=selected, hypothesis=hypothesis, change_summary=change, reason=reason,
               configuration=configuration, seed=parent.meta['seed'], history_ids=rnd.history_ids,
               model_call_ids=list(rnd.call_ids))


def bounded_history(history):
    # IDs are all cited as actually read, but only a bounded view is sent to the model.
    chosen = []
    for record in reversed(history):
        item = record if len(canonical(record).encode()) <= 6000 else {'id': record['id'], 'record_truncated': True,
                                                                       'preview': canonical(record)[:2000]}
        if len(canonical(chosen + [item]).encode()) > 24000:
            break
        chosen.append(item)
        if len(chosen) == 12:
            break
    return list(reversed(chosen))


def predict(sample, model_dir):
    # Only the selected mounted artifact. No search for image weights or stale exports.
    root = Path(model_dir).resolve()
    path = Path(os.environ.get('CONTEST_ARTIFACT_PATH', str(root / 'checkpoint.npz')))
    path = path.absolute()
    if path.is_symlink() or not path.resolve().is_relative_to(root):
        raise ValueError('selected_checkpoint_outside_model_mount')
    if sample.context:
        declared = sample.context['artifact'].get('checkpoint_paths', [])
        if path.relative_to(root).as_posix() not in declared:
            raise ValueError('selected_checkpoint_not_declared')
    key = str(path)
    if key not in _CACHE:
        _CACHE[key] = Model.load(path)
    model = _CACHE[key]
    if sample.dataset_key:
        task_check(sample.dataset_key, sample.task, model)
    elif sample.task != model.meta['task']:
        raise ValueError('prediction_task_mismatch')
    paths, values = flatten(sample.inputs)
    if paths != model.meta['paths']:
        raise ValueError('prediction_feature_schema_changed')
    result = model.predict(np.asarray([values], dtype=np.float64))[0]
    if sample.task == 'regression':
        return {'value': float(result)}
    # On exact numerical ties, return the deterministic argmax label alone.
    # Otherwise retain full official probabilities without recalibration.
    maximum = float(np.max(result))
    if int(np.sum(result == maximum)) > 1:
        return [{'label': model.meta['classes'][int(np.argmax(result))], 'score': maximum}]
    return [{'label': label, 'score': float(score)} for label, score in zip(model.meta['classes'], result)]
