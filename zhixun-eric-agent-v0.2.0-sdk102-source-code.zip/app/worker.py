"""One bounded continuation, receiving train-only arrays and a verified parent."""
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import sys

import numpy as np


def fingerprint(model, groups):
    digest = hashlib.sha256()
    for group in groups:
        value = getattr(model, group)
        entries = sorted(value.items()) if isinstance(value, dict) else [(group, value)]
        for key, array in entries:
            digest.update(key.encode())
            digest.update(array.tobytes())
    return digest.hexdigest()


def run(request_path):
    request = json.loads(Path(request_path).read_text(encoding='utf-8'))
    directory = Path(request['directory'])
    spec = importlib.util.spec_from_file_location('candidate_model', directory / 'model.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    model = module.Model.load(request['parent'])
    before = dict(model.meta)
    norm = fingerprint(model, ['mean', 'scale'])
    optimizer = fingerprint(model, ['first', 'second'])
    with np.load(request['train_arrays'], allow_pickle=False) as arrays:
        x, y = arrays['x'], arrays['y']
    recipe = request['recipe']
    model.meta['learning_rate'] = recipe['learning_rate']
    model.meta['batch_size'] = recipe['batch_size']
    model.validate()
    if fingerprint(model, ['first', 'second']) != optimizer:
        raise ValueError('optimizer_reset')
    losses = model.fit(x, y, recipe['epochs'])
    expected = {**before, 'learning_rate': recipe['learning_rate'], 'batch_size': recipe['batch_size'],
                'epochs': before['epochs'] + recipe['epochs'],
                'steps': before['steps'] + math.ceil(len(x) / recipe['batch_size']) * recipe['epochs']}
    if model.meta != expected or fingerprint(model, ['mean', 'scale']) != norm:
        raise ValueError('inheritance_changed')
    model.save(directory / 'checkpoint.npz')
    receipt = {'parent_sha256': hashlib.sha256(Path(request['parent']).read_bytes()).hexdigest(),
               'before_meta': before, 'after_meta': model.meta, 'training_rows': len(x),
               'step_delta': expected['steps'] - before['steps'], 'losses': losses,
               'normalization_inherited': True, 'optimizer_before_fit_sha256': optimizer,
               'optimizer_after_fit_sha256': fingerprint(model, ['first', 'second']),
               'python': sys.version.split()[0], 'numpy': np.__version__}
    (directory / 'training-receipt.json').write_text(json.dumps(receipt, sort_keys=True, allow_nan=False), encoding='utf-8')


if __name__ == '__main__':
    # The platform controls the whole process tree. This only bounds this worker.
    if sys.platform == 'linux':
        import resource
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        resource.setrlimit(resource.RLIMIT_AS, (1536 * 1024**2, 1536 * 1024**2))
    run(sys.argv[1])
