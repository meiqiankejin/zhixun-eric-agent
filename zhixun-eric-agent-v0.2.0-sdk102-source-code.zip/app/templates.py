"""Reviewed weighted CE actions only; no execution of model-generated Python."""
import ast
import difflib
import hashlib
from pathlib import Path

BASE = Path(__file__).with_name('official_model.py').read_text(encoding='utf-8')
BASE_SHA256 = '325026d80747eb36f39c8df1be02b640ae21b3cd082827c66aacbdf273dd61c5'
POWERS = (0.0, 0.5, 1.0)


def source(power):
    if type(power) not in (int, float) or power not in POWERS:
        raise ValueError('unsupported_weight_power')
    if power == 0:
        return BASE
    epoch = '        epoch_losses = []'
    loss = '                    loss_sum -= float(np.log(np.maximum(probabilities[np.arange(len(indices)), expected], 1e-300)).sum())'
    divide = '                    delta /= len(indices)'
    edits = [
        (epoch, '        class_weights = None\n'
         '        if self.meta["task"] == "classification":\n'
         '            counts = np.bincount(target, minlength=len(self.meta["classes"]))\n'
         f'            class_weights = (len(target) / (len(counts) * np.maximum(counts, 1))) ** {float(power)!r}\n'
         '            class_weights /= np.mean(class_weights[target])\n' + epoch),
        (loss, '                    loss_sum -= float((np.log(np.maximum(probabilities[np.arange(len(indices)), expected], 1e-300)) * class_weights[expected]).sum())'),
        (divide, '                    delta *= class_weights[expected, None]\n' + divide),
    ]
    result = BASE
    for old, new in edits:
        if result.count(old) != 1:
            raise ValueError('template_anchor_changed')
        result = result.replace(old, new, 1)
    before = ast.parse(BASE)
    after = ast.parse(result)
    def other_methods(tree):
        cls = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == 'Model')
        return {node.name: ast.dump(node) for node in cls.body
                if isinstance(node, ast.FunctionDef) and node.name != 'fit'}
    if other_methods(before) != other_methods(after):
        raise ValueError('prediction_or_loading_changed')
    compile(result, 'model.py', 'exec')
    return result


def difference(power):
    return ''.join(difflib.unified_diff(BASE.splitlines(True), source(power).splitlines(True),
                                       fromfile='official/model.py', tofile='candidate/model.py'))


def supported_model_source(raw):
    # Normalize newlines only: the original source may be mounted with CRLF.
    text = raw.decode('utf-8').replace('\r\n', '\n')
    return any(text == source(power) for power in POWERS)
