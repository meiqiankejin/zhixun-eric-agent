"""Verify an authorized source archive and restore its exact image build context."""
from pathlib import Path, PurePosixPath
import argparse, hashlib, json, zipfile

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-zip', required=True)
parser.add_argument('--output', required=True)
args = parser.parse_args()
manifest = json.loads((root / 'docs/IMAGE-CORRESPONDENCE.json').read_text('utf-8'))
source, output = Path(args.source_zip), Path(args.output).resolve()
if output.exists():
    raise SystemExit('output already exists; choose a new directory')
with source.open('rb') as f:
    if hashlib.file_digest(f, 'sha256').hexdigest() != manifest['source_archive_sha256']:
        raise SystemExit('source archive differs from the delivered version')
with zipfile.ZipFile(source) as archive:
    expected = {'context/' + n: h for n, h in manifest['context_files'].items()}
    if set(archive.namelist()) != set(expected):
        raise SystemExit('source archive member list differs')
    for name, digest in expected.items():
        path = PurePosixPath(name)
        if path.is_absolute() or '..' in path.parts or '\\' in name:
            raise SystemExit('invalid archive path')
        if hashlib.sha256(archive.read(name)).hexdigest() != digest:
            raise SystemExit('source member hash mismatch')
    output.mkdir(parents=True, exist_ok=False)
    for name in expected:
        dest = output.joinpath(*PurePosixPath(name).parts[1:])
        dest.parent.mkdir(parents=True, exist_ok=True)
        with dest.open('xb') as f:
            f.write(archive.read(name))
print(json.dumps({'verified_files': len(expected), 'training': 0, 'api_calls': 0}))
