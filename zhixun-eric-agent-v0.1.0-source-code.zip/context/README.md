# 智训引擎 Linux 开发入口 v2

支持check、predict、freeze-development和显式train-live。仍不是官方SDK/10轮合同。
Codex自查，未经Claude复核；没有待Claude反馈。

先freeze-development，将打印的plan_sha256存放在容器外。train-live必须指定同一计划摘要、
全新输出目录和--live；读取stdin前验证模型/数据/源码/环境/预算及入口绑定。

```sh
docker run --rm --read-only --network none --tmpfs /tmp:rw,noexec,nosuid,size=64m \
  --mount type=bind,src="$(pwd)/output",dst=/output \
  zhixun-dev:linux-live-v2 freeze-development --tasks A B C --max-fits 1 --output /output/plan
```

真实运行需网络及--interactive stdin，命令末尾为：
`train-live --plan /output/plan --expected-plan-sha256 <冻结摘要> --output /output/run --live`。
由宿主受控进程通过stdin传入包含api_key/base_url/model的单个JSON对象（最多4096字节），
不要将真实密钥直接粘贴到终端、命令行参数、环境变量、配置文件、镜像、日志或聊天中。
随本项目的Windows桥接程序读取当前用户已有DPAPI配置，直接给子进程stdin，不写明文临时文件。
其他机器应由当地的凭据管理工具提供stdin；本包不会携带Windows账户密钥。

固定PyTRiO HTTPS端点及模型Qwen/Qwen3.8-27B；不猜主办方未来端点或凭据注入合同。
训练子进程环境仍由原监督器清理，不继承密钥；宿主/main控制器为请求在内存中持有密钥。
stdin不是抵抗同机管理员或Docker守护进程的安全边界。

每任务最多1或3个拟合/决策轮；A调用预算为拟合数4倍、B/C为2倍。请求和训练启动前预扣，
失败不退，重试和当前轮接管沿用已验证控制器；finish可提前停止。保留所有失败，不补跑。
原train仅用于梯度，public validation重复用于挑选；输出包含根/子记录、实际用量、
选中源码/checkpoint/配置、导出清单及尾锚。未同步云端，不声明隐藏集或自改进收益。
对外固定根尾摘要后方能做完整性审计；仅依赖本地锚不防整个目录回退。

本次开发验收限定ABC各至多一次拟合，总至多3拟合8请求，不保证千问一定用完。
真实结果、构建/模拟测试、容器与归档审计见交付报告，不能用README代替实测。
原Windows工作台、v1镜像和历史保留模型不被替换。官方接口对齐前不上传或启动平台评测。
