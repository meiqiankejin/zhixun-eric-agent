"""Offline development entry; not the unknown competition execution protocol."""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import importlib.util
import json
import os
import platform
import sys

os.environ.update(OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1')
ROOT = Path(__file__).resolve().parent
CODE = ROOT / 'outputs/industrial-maintenance-demo'
INPUTS = ROOT / 'inputs/official-platform-2026-11-11'
EXPORTS = ROOT / 'outputs/unified-entry-v1-existing-model-exports-final'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def write(path, value):
    with Path(path).open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


def module(path):
    spec = importlib.util.spec_from_file_location('linux_dev_' + sha(path), path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def verify():
    manifest = load(ROOT / 'APP-MANIFEST.json')
    if manifest['schema'] != 'linux-development-app-v1':
        raise ValueError('manifest_schema_changed')
    for name, expected in manifest['files'].items():
        relative = PurePosixPath(name)
        if (relative.is_absolute() or '..' in relative.parts or '\\' in name
                or not relative.parts):
            raise ValueError('manifest_path_invalid')
        path = ROOT.joinpath(*relative.parts)
        if (any(p.is_symlink() for p in [path, *path.parents] if p.is_relative_to(ROOT))
                or not path.is_file() or sha(path) != expected):
            raise ValueError('app_file_changed')
    import numpy as np
    if (platform.python_version(), np.__version__) != ('3.12.14', '1.26.4'):
        raise ValueError('development_runtime_changed')
    catalog = load(ROOT / 'catalog.json')
    if set(catalog['tasks']) != {'A', 'B', 'C'}:
        raise ValueError('task_mapping_changed')
    for task, item in catalog['tasks'].items():
        for folder, hashes in [(INPUTS / item['package'], item['official_hashes']),
                               (EXPORTS / task, item['export_hashes'])]:
            for name, expected in hashes.items():
                if sha(folder / name) != expected:
                    raise ValueError('catalog_artifact_changed')
        artifact = EXPORTS / task
        if sha(artifact / 'EXPORT.json') != item['export_manifest_sha256']:
            raise ValueError('export_manifest_changed')
        selected = module(artifact / 'baselines/model.py').Model.load(artifact / 'checkpoint.npz')
        cfg = load(artifact / f'baselines/configs/{task}.json')
        expected_kind = 'classification' if task == 'A' else 'regression'
        if (cfg['profile'] != task or cfg['task'] != expected_kind
                or selected.meta['task'] != expected_kind
                or selected.meta['classes'] != cfg['classes']
                or selected.meta['hidden'] != cfg['hidden']
                or (task == 'B' and cfg.get('target_unit') != 'minutes')):
            raise ValueError('task_config_model_mismatch')
    return catalog


def check():
    catalog = verify()
    import numpy as np
    return {'passed': True, 'scope': 'offline_development_entry',
            'system': platform.system(), 'python': platform.python_version(), 'numpy': np.__version__,
            'tasks': list(catalog['tasks']), 'model_loaded': True,
            'training': False, 'api_requests': 0, 'platform_runs': 0,
            'official_sdk_compatible': False, 'claude_reviewed': False}


def predict(task, input_path, output):
    catalog = verify()
    if task not in catalog['tasks']:
        raise ValueError('unknown_task')
    input_path, output = Path(input_path), Path(output).resolve()
    if output.exists() or output.is_relative_to(ROOT):
        raise ValueError('output_exists_or_inside_app')
    if not input_path.is_file() or input_path.is_symlink() or input_path.stat().st_size > 8 * 1024**2:
        raise ValueError('input_not_regular_or_too_large')
    raw = input_path.read_bytes()
    if len(raw) > 8 * 1024**2:
        raise ValueError('input_too_large')
    artifact = EXPORTS / task
    reader = module(artifact / 'baselines/data.py')
    model = module(artifact / 'baselines/model.py').Model.load(artifact / 'checkpoint.npz')
    identifiers, features, seen = [], [], set()
    for number, line in enumerate(raw.decode('utf-8-sig').splitlines(), 1):
        if not line.strip():
            continue
        row = reader.json_value(line)
        if not isinstance(row, dict) or 'inputs' not in row:
            raise ValueError('row_requires_inputs')
        identity = row.get('id', f'row-{number}')
        if not isinstance(identity, str) or not identity or len(identity) > 500 or identity in seen:
            raise ValueError('invalid_or_duplicate_id')
        paths, values = reader.flatten(row['inputs'])
        if paths != model.meta['paths'] or len(identifiers) >= 10000:
            raise ValueError('feature_schema_or_row_limit')
        identifiers.append(identity); features.append(values); seen.add(identity)
    if not identifiers:
        raise ValueError('empty_input')
    import numpy as np
    # Only inputs enter the model. answer and meta never enter prediction or scoring.
    rows = []
    for start in range(0, len(identifiers), 512):
        predicted = model.predict(np.asarray(features[start:start + 512], dtype=np.float64))
        for identity, value in zip(identifiers[start:start + 512], predicted):
            outputs = ([{'label': label, 'score': float(score)}
                        for label, score in zip(model.meta['classes'], value)]
                       if task == 'A' else {'value': float(value)})
            rows.append({'id': identity, 'outputs': outputs})
    # Check source files again before committing outputs; reject existing destinations.
    verify()
    output.mkdir(parents=True, exist_ok=False)
    with (output / 'predictions.jsonl').open('x', encoding='utf-8', newline='\n') as stream:
        for row in rows:
            stream.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + '\n')
    receipt = {'schema': 'linux-development-prediction-v1', 'task': task, 'rows': len(rows),
               'labels_used': False, 'model_origin': 'retained_development_model',
               'input_sha256': hashlib.sha256(raw).hexdigest(),
               'checkpoint_sha256': sha(artifact / 'checkpoint.npz'),
               'source_sha256': sha(artifact / 'baselines/model.py'),
               'app_manifest_sha256': sha(ROOT / 'APP-MANIFEST.json'),
               'predictions_sha256': sha(output / 'predictions.jsonl'),
               'training': False, 'api_requests': 0, 'platform_runs': 0,
               'official_sdk_compatible': False, 'claude_reviewed': False}
    write(output / 'receipt.json', receipt)
    return receipt


def freeze(output, tasks, fits):
    verify()
    output = Path(output).resolve()
    if output.exists() or output.is_relative_to(ROOT):
        raise ValueError('output_exists_or_inside_app')
    if type(fits) is not int or not 1 <= fits <= 3:
        raise ValueError('development_fits_requires_1_to_3')
    sys.path.insert(0, str(CODE))
    import official_unified_entry_v1 as engine
    result = engine.freeze(output, inputs=INPUTS, tasks=tasks, max_fits=fits,
                           max_decisions=fits, calls={t: fits * (4 if t == 'A' else 2) for t in tasks})
    engine.verify(output, INPUTS)
    return {'plan_sha256': sha(output / 'plan.json'), 'tasks': list(result['tasks']),
            'training': False, 'api_requests': 0, 'platform_runs': 0,
            'live_entry_implemented': False, 'official_sdk_compatible': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('check')
    prediction = commands.add_parser('predict')
    prediction.add_argument('--task', choices=list('ABC'), required=True)
    prediction.add_argument('--input', required=True)
    prediction.add_argument('--output', required=True)
    plan = commands.add_parser('freeze-development')
    plan.add_argument('--tasks', nargs='+', choices=list('ABC'), default=list('ABC'))
    plan.add_argument('--max-fits', type=int, default=1)
    plan.add_argument('--output', required=True)
    args = parser.parse_args()
    if args.command == 'check':
        result = check()
    elif args.command == 'predict':
        result = predict(args.task, args.input, args.output)
    else:
        result = freeze(args.output, args.tasks, args.max_fits)
    print(json.dumps(result, ensure_ascii=False, allow_nan=False))


if __name__ == '__main__':
    main()
