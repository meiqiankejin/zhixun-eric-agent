"""Tool-loop teaching prototype. Defaults to scripted decisions; live clients are explicit."""
from __future__ import annotations

import argparse
import json
import random
import time
from copy import deepcopy
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Protocol

from demo import Model, Sample, accuracy, fit, make_data, score


def model_state(model: Model) -> dict:
    """Keep runtime records JSON-native so saving and reading preserve their structure."""
    return {"weights": list(model.weights), "bias": model.bias}


def tool(name: str, description: str, properties: dict | None = None) -> dict:
    properties = properties or {}
    return {"name": name, "description": description,
            "parameters": {"type": "object", "properties": properties,
                           "required": list(properties), "additionalProperties": False}}


TOOLS = [
    tool("read_history", "读取已完成批次的结果和实验；不含未来数据。"),
    tool("inspect_data", "查看当前已公开数据摘要和新旧版本在留出数据上的表现。"),
    tool("train_candidate", "真实训练一个候选；不使用验证数据。", {
        "strategy": {"type": "string", "enum": ["recent", "replay"]},
        "epochs": {"type": "integer", "minimum": 1, "maximum": 200}}),
    tool("evaluate_candidate", "在留出数据上实测候选，与本批当前模型比较。", {
        "candidate_id": {"type": "string"}}),
    tool("request_deployment", "申请下一批启用候选；程序独立检查验证门槛。", {
        "candidate_id": {"type": "string"}}),
    tool("request_rollback", "申请下一批恢复上一版本；程序实测其是否优于当前版本。"),
    tool("finish", "结束本批决策；没有通过的替换申请就保留当前版本。"),
]
SYSTEM = (
    "你是工业模型维护决策端。只返回一个JSON对象，键为reason、tool、arguments。"
    "reason是简短、基于已知事实的操作依据；无需输出内部思维过程。"
    "只能请求列出的工具，不能执行任意代码、读取任意文件或自行宣布实验成绩。"
    "模型版本变更从下一批生效；所有成绩必须来自工具。"
    "若current_accuracy>=limits.minimum_accuracy或has_next_batch为false，直接finish，不再检查或训练。"
    "否则先read_history和inspect_data，再根据观察提出有限训练实验。"
    "候选训练后必须evaluate_candidate，验证通过才能request_deployment，申请批准后调用finish提交。"
    "没有预算、没有后续批次或没有可靠改善证据时保留当前版本并finish。"
    "本任务使用教学模拟数据，门槛不是官方规则。"
)


class DecisionClient(Protocol):
    """Provider-neutral seam; the official service adapter must translate its wire format."""
    source: str

    def respond(self, messages: list[dict], tools: list[dict]) -> str: ...


@dataclass(frozen=True)
class Limits:
    max_calls_per_batch: int = 10
    max_trainings: int = 8
    max_trainings_per_batch: int = 2
    max_epochs: int = 200
    minimum_accuracy: float = .88
    minimum_gain: float = .04

    def __post_init__(self):
        for value in (self.max_calls_per_batch, self.max_trainings,
                      self.max_trainings_per_batch, self.max_epochs):
            if type(value) is not int or value < 0:
                raise ValueError("Budgets must be nonnegative integers")
        if self.max_epochs > 200:
            raise ValueError("This prototype supports at most 200 epochs")
        if not 0 <= self.minimum_accuracy <= 1 or not 0 <= self.minimum_gain <= 1:
            raise ValueError("Invalid validation threshold")


class RequestError(ValueError):
    pass


def parse_request(raw: str, limits: Limits) -> dict:
    def unique_object(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise RequestError("duplicate_key")
            result[key] = value
        return result

    if not isinstance(raw, str) or len(raw) > 8192:
        raise RequestError("invalid_response_size_or_type")
    try:
        request = json.loads(raw, object_pairs_hook=unique_object)
    except (ValueError, RecursionError) as exc:
        raise RequestError("invalid_json") from exc
    if not isinstance(request, dict) or set(request) != {"reason", "tool", "arguments"}:
        raise RequestError("invalid_envelope")
    if not isinstance(request["reason"], str) or not request["reason"].strip() or len(request["reason"]) > 1000:
        raise RequestError("invalid_reason")
    name, args = request["tool"], request["arguments"]
    if not isinstance(name, str) or not isinstance(args, dict):
        raise RequestError("invalid_tool_or_arguments")
    definition = next((t for t in TOOLS if t["name"] == name), None)
    if definition is None:
        raise RequestError("unknown_tool")
    if set(args) != set(definition["parameters"]["properties"]):
        raise RequestError("invalid_argument_keys")
    if name == "train_candidate":
        if args["strategy"] not in ("recent", "replay"):
            raise RequestError("unknown_strategy")
        if type(args["epochs"]) is not int or not 1 <= args["epochs"] <= limits.max_epochs:
            raise RequestError("invalid_epochs")
    if "candidate_id" in args and (not isinstance(args["candidate_id"], str)
                                  or not 1 <= len(args["candidate_id"]) <= 80):
        raise RequestError("invalid_candidate_id")
    return request


class ScriptedClient:
    """A deterministic test double, NOT Qwen. Only reads supplied observations/results."""
    source = "scripted_mock_not_qwen"

    def respond(self, messages: list[dict], tools: list[dict]) -> str:
        context = json.loads(messages[1]["content"])
        results = [(m["name"], json.loads(m["content"]))
                   for m in messages if m["role"] == "tool"]

        def reply(name, reason, **args):
            return json.dumps({"reason": reason, "tool": name, "arguments": args}, ensure_ascii=False)

        if any(not result["ok"] for _, result in results):
            return reply("finish", "工具拒绝或执行失败，本批停止尝试，保留已通过检查的决定。")
        if (not context["has_next_batch"]
                or context["current_accuracy"] >= context["limits"]["minimum_accuracy"]):
            return reply("finish", "本批无须启动维护，或没有下一批可启用新版本。")
        names = [name for name, _ in results]
        if "read_history" not in names:
            return reply("read_history", "当前表现下降，先读取已完成实验，确认历史和预算。")
        if "inspect_data" not in names:
            return reply("inspect_data", "检查当前数据摘要及旧版本，分布变化只是待检验线索。")
        if "request_deployment" in names or "request_rollback" in names:
            return reply("finish", "版本申请已有程序检查结果，结束本批决策。")
        inspected = next(r for name, r in results if name == "inspect_data")
        if inspected["rollback_allowed"]:
            return reply("request_rollback", "上一版本在相同留出数据上通过改善门槛，申请恢复以减少训练。")
        trained = [r for name, r in results if name == "train_candidate"]
        evaluated = {r["candidate_id"]: r for name, r in results if name == "evaluate_candidate"}
        for candidate in trained:
            if candidate["candidate_id"] not in evaluated:
                return reply("evaluate_candidate", "候选训练完成，必须先用未参加训练的数据验证。",
                             candidate_id=candidate["candidate_id"])
        remaining = inspected["training_budget_remaining"] - len(trained)
        per_batch = context["limits"]["max_trainings_per_batch"]
        if len(trained) < min(2, per_batch) and remaining > 0:
            strategy = "recent" if not trained else "replay"
            reason = ("先检验近期数据重训是否能适应变化。" if not trained else
                      "再检验加入少量旧训练数据的方案，实际结果交给验证工具比较。")
            return reply("train_candidate", reason, strategy=strategy,
                         epochs=min(100, context["limits"]["max_epochs"]))
        passed = [r for r in evaluated.values() if r["passed"]]
        if passed:
            best = max(passed, key=lambda r: r["candidate_accuracy"])
            return reply("request_deployment", "依据工具实测结果，申请启用通过门槛的最佳候选。",
                         candidate_id=best["candidate_id"])
        return reply("finish", "没有通过验证的候选，或训练预算不足，保留当前版本。")


class MaintenanceHarness:
    def __init__(self, initial_train: list[Sample], reference: list[Sample],
                 limits: Limits | None = None):
        self.limits = limits or Limits()
        self.initial_train, self.reference = initial_train, reference
        self.models = {0: fit(initial_train)}
        self.active_version = 0
        self.previous_version = None
        self.trainings = 0
        self.history = []
        self.trace = []
        self.versions = [{"version": 0, "effective_from_batch": 1,
                          "model": model_state(self.models[0])}]

    def _passes(self, new: float, old: float) -> bool:
        return new >= self.limits.minimum_accuracy and new - old >= self.limits.minimum_gain

    def process_batch(self, rows: list[Sample], batch: int, client: DecisionClient,
                      seed: int, has_next_batch: bool = True) -> dict:
        used_version = self.active_version
        used_model = self.models[used_version]
        # Teaching environment: commit predictions first, then reveal this batch's labels.
        predictions = used_model.predict(rows)
        frozen_predictions = self.models[0].predict(rows)
        current_accuracy = accuracy(predictions, rows)
        shuffled = list(rows)
        random.Random(seed + batch * 17).shuffle(shuffled)
        training, validation = shuffled[:160], shuffled[160:]
        if not training or not validation:
            raise ValueError("Teaching batches require more than 160 samples")
        old_validation = score(used_model, validation)
        candidates, tool_log = {}, []
        pending = None
        failure = None
        finished = False
        starting_trainings = self.trainings
        context = {"batch": batch, "current_version": used_version,
                   "current_accuracy": current_accuracy, "has_next_batch": has_next_batch,
                   "limits": asdict(self.limits),
                   "training_budget_remaining": self.limits.max_trainings - self.trainings,
                   "label_protocol": "teaching: predict then release; NOT official SDK protocol"}
        messages = [{"role": "system", "content": SYSTEM},
                    {"role": "user", "content": json.dumps(context, ensure_ascii=False)}]
        self.trace.append({"batch": batch, "event": "context", "context": deepcopy(context)})

        def execute(request):
            nonlocal pending
            name, args = request["tool"], request["arguments"]
            if name == "read_history":
                return {"ok": True, "completed_batches": deepcopy(self.history)}
            if name == "inspect_data":
                prior_score = (score(self.models[self.previous_version], validation)
                               if self.previous_version is not None else None)
                return {"ok": True, "training_count": len(training),
                        "validation_count": len(validation),
                        "temperature_mean_shift": abs(
                            sum(r.temperature for r in rows) / len(rows)
                            - sum(r.temperature for r in self.initial_train) / len(self.initial_train)),
                        "current_validation_accuracy": old_validation,
                        "previous_version": self.previous_version,
                        "previous_validation_accuracy": prior_score,
                        "rollback_allowed": (has_next_batch and prior_score is not None
                                             and self._passes(prior_score, old_validation)),
                        "training_budget_remaining": self.limits.max_trainings - self.trainings}
            if name == "train_candidate":
                if not has_next_batch or pending is not None:
                    return {"ok": False, "error": "training_not_allowed_now"}
                if (self.trainings >= self.limits.max_trainings
                        or self.trainings - starting_trainings >= self.limits.max_trainings_per_batch):
                    return {"ok": False, "error": "training_budget_exhausted"}
                self.trainings += 1  # Failed attempts also consume the training budget.
                candidate_id = f"b{batch}-c{self.trainings}"
                data = training + (self.initial_train[:40] if args["strategy"] == "replay" else [])
                start = time.perf_counter()
                candidate_model = fit(data, epochs=args["epochs"])
                candidates[candidate_id] = {
                    "candidate_id": candidate_id, **args, "model": candidate_model,
                    "training_ids": [r.sample_id for r in data],
                    "validation_ids": [r.sample_id for r in validation],
                    "training_seconds": time.perf_counter() - start, "evaluation": None}
                return {"ok": True, "candidate_id": candidate_id,
                        "training_count": len(data), "strategy": args["strategy"],
                        "training_seconds": candidates[candidate_id]["training_seconds"]}
            if name in {"evaluate_candidate", "request_deployment"}:
                candidate = candidates.get(args["candidate_id"])
                if candidate is None:
                    return {"ok": False, "error": "unknown_candidate_in_this_batch"}
                if name == "evaluate_candidate":
                    candidate_score = score(candidate["model"], validation)
                    result = {"ok": True, "candidate_id": args["candidate_id"],
                              "current_accuracy": old_validation, "candidate_accuracy": candidate_score,
                              "gain_percentage_points": (candidate_score - old_validation) * 100,
                              "reference_current_accuracy": score(used_model, self.reference),
                              "reference_candidate_accuracy": score(candidate["model"], self.reference),
                              "passed": self._passes(candidate_score, old_validation)}
                    candidate["evaluation"] = deepcopy(result)
                    return result
                if pending is not None or not has_next_batch:
                    return {"ok": False, "error": "deployment_not_allowed_now"}
                # A reason or claimed score in a model response can never bypass this gate.
                if candidate["evaluation"] is None:
                    return {"ok": False, "error": "validation_required"}
                if not self._passes(score(candidate["model"], validation), old_validation):
                    return {"ok": False, "error": "validation_gate_failed"}
                pending = {"kind": "deploy", "candidate_id": args["candidate_id"]}
                return {"ok": True, "status": "approved_pending_finish", "effective_from_batch": batch + 1}
            if name == "request_rollback":
                if pending is not None or not has_next_batch or self.previous_version is None:
                    return {"ok": False, "error": "rollback_not_allowed_now"}
                previous_score = score(self.models[self.previous_version], validation)
                if not self._passes(previous_score, old_validation):
                    return {"ok": False, "error": "rollback_gate_failed"}
                pending = {"kind": "rollback", "version": self.previous_version}
                return {"ok": True, "status": "approved_pending_finish",
                        "restored_version": self.previous_version,
                        "current_accuracy": old_validation, "previous_accuracy": previous_score,
                        "effective_from_batch": batch + 1}
            return {"ok": True, "status": "finished"}

        for _ in range(self.limits.max_calls_per_batch):
            try:
                # The decision side receives only copies of exposed summaries, never engine objects.
                raw = client.respond(deepcopy(messages), deepcopy(TOOLS))
            except Exception:
                failure = "decision_client_error"
                self.trace.append({"batch": batch, "event": "client_error", "error": failure})
                break
            try:
                request = parse_request(raw, self.limits)
            except RequestError as exc:
                failure = str(exc)
                self.trace.append({"batch": batch, "event": "request_rejected", "error": failure})
                break
            messages.append({"role": "assistant", "content": raw})
            self.trace.append({"batch": batch, "event": "request", "request": deepcopy(request)})
            try:
                outcome = execute(request)
            except Exception:
                # Do not include provider exception messages, credentials or local paths in records.
                outcome = {"ok": False, "error": "tool_execution_failed"}
            tool_log.append({"request": deepcopy(request), "result": deepcopy(outcome)})
            self.trace.append({"batch": batch, "event": "tool_result", "tool": request["tool"],
                               "result": deepcopy(outcome)})
            messages.append({"role": "tool", "name": request["tool"],
                             "content": json.dumps(outcome, ensure_ascii=False)})
            if not outcome["ok"]:
                failure = outcome["error"]
                break
            if request["tool"] == "finish":
                finished = True
                break
        if not finished and failure is None:
            failure = "decision_call_budget_exhausted"
        # Atomic commit: any malformed request, tool failure or unfinished loop cancels pending changes.
        action = "keep"
        if finished and failure is None and pending is not None:
            self.previous_version = used_version
            if pending["kind"] == "deploy":
                candidate = candidates[pending["candidate_id"]]
                new_version = len(self.versions)
                self.models[new_version] = candidate["model"]
                self.active_version = new_version
                self.versions.append({"version": new_version, "effective_from_batch": batch + 1,
                                      "candidate_id": pending["candidate_id"],
                                      "model": model_state(candidate["model"])})
                action = "deploy_next_batch"
            else:
                self.active_version = pending["version"]
                action = "rollback_next_batch"
        event = {"batch": batch, "used_version": used_version,
                 "current_accuracy": current_accuracy,
                 "fixed_accuracy": accuracy(frozen_predictions, rows),
                 "action": action, "next_version": self.active_version,
                 "failure": failure, "tool_calls": tool_log,
                 "candidates": [{**c, "model": model_state(c["model"])} for c in candidates.values()],
                 "predictions": [{"sample_id": r.sample_id, "prediction": p,
                                  "fixed_prediction": fp, "label": r.label}
                                 for r, p, fp in zip(rows, predictions, frozen_predictions)]}
        self.history.append({"batch": batch, "used_version": used_version,
                             "accuracy": current_accuracy, "action": action,
                             "next_version": self.active_version, "failure": failure,
                             "experiments": [{"strategy": c["strategy"], "epochs": c["epochs"],
                                              "evaluation": c["evaluation"]} for c in candidates.values()]})
        self.trace.append({"batch": batch, "event": "batch_commit", "action": action,
                           "next_version": self.active_version, "failure": failure})
        return event


def run(seed: int = 20261106, client: DecisionClient | None = None,
        limits: Limits | None = None, max_batches: int = 8) -> dict:
    if type(max_batches) is not int or not 1 <= max_batches <= 8:
        raise ValueError("Teaching run supports 1 to 8 batches")
    client = client or ScriptedClient()
    engine = MaintenanceHarness(make_data(360, 0, seed, "initial-train"),
                                make_data(160, 0, seed + 1, "initial-validation"), limits)
    offsets = [0, 0, .95, .95, -1.05, -1.05, .7, .7][:max_batches]
    events = []
    for batch, offset in enumerate(offsets, 1):
        # Synthetic truth is owned by this environment, never sent to the decision client.
        rows = make_data(240, offset, seed + batch * 101, f"batch-{batch}")
        events.append(engine.process_batch(rows, batch, client, seed, batch < len(offsets)))
    remote = bool(getattr(client, "is_remote", False))
    return {"kind": "live_harness_teaching_prototype" if remote else "offline_harness_teaching_prototype",
            "decision_source": client.source, "remote_client": remote,
            "real_model_service_connected": bool(getattr(client, "connected", False)), "seed": seed,
            "service_diagnostics": client.diagnostics() if remote else None,
            "system_instruction": SYSTEM, "tools": deepcopy(TOOLS),
            "limits": asdict(engine.limits), "trained_candidates": engine.trainings,
            "accepted_updates": sum(e["action"] == "deploy_next_batch" for e in events),
            "rollbacks": sum(e["action"] == "rollback_next_batch" for e in events),
            "events": events, "versions": engine.versions, "trace": engine.trace}


def write_outputs(result: dict, output: Path) -> None:
    output.mkdir(parents=True, exist_ok=True)
    (output / "run.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    (output / "tool-trace.jsonl").write_text(
        "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in result["trace"]), encoding="utf-8")
    model_dir = output / "models"
    model_dir.mkdir(exist_ok=True)
    for version in result["versions"]:
        (model_dir / f"V{version['version']}.json").write_text(
            json.dumps(version, ensure_ascii=False, indent=2), encoding="utf-8")
    labels = {"keep": "保留", "deploy_next_batch": "下一批启用新模型",
              "rollback_next_batch": "下一批恢复旧版本"}
    remote = result.get("remote_client", False)
    decision_label = "千问决策端" if remote else "模拟决策端"
    if remote:
        diagnostics = result["service_diagnostics"]
        provider_label = "PyTRiO" if diagnostics.get("provider") == "pytrio" else "百炼"
        status = (f"**本次使用{provider_label} API：{diagnostics['model']}，发送{diagnostics['calls']}次请求；"
                  f"{'收到服务响应' if result['real_model_service_connected'] else '尚未收到有效服务响应'}。"
                  "逐批失败与否见完整记录，收到响应不等于整个维护实验成功。**")
    else:
        status = "**已跑通本地工具通路；决策端仍是固定规则模拟器，没有接通千问，也没有联网或消耗模型额度。**"
    lines = ["# 第四步：决策端怎样指挥程序", "", status, "",
             ("操作请求来自实际API响应。" if remote else "模拟的是决策回复。")
             + "训练、预测、验证、版本保存和回滚检查均由本地程序真实执行。数据仍是人工构造，成绩不代表比赛效果。", "",
             "## 用人话说", "",
             "程序把‘现在表现怎么样、有哪些工具’交给决策端。决策端发出操作请求，程序检查后执行，再把实测结果交回去；直到决定换、退回旧版或者保留。后续接千问时，要接到这个位置。", "",
             f"这次处理{len(result['events'])}批数据，实际训练候选{result['trained_candidates']}个，接受新模型{result['accepted_updates']}次，恢复旧版本{result['rollbacks']}次。", "",
             "| 批次 | 本批使用 | 本批正确率 | 固定V0正确率 | 批后决定 | 下一批使用 |",
             "|---|---|---|---|---|---|"]
    for e in result["events"]:
        lines.append(f"| {e['batch']} | V{e['used_version']} | {e['current_accuracy']:.1%} | "
                     f"{e['fixed_accuracy']:.1%} | {labels[e['action']]} | V{e['next_version']} |")
    example = next((e for e in result["events"] if e["candidates"]), None)
    if example:
        lines += ["", f"## 看第{example['batch']}批的一次完整往返", "",
                  f"本批已经预测完并公开答案，当前模型正确率{example['current_accuracy']:.1%}。", ""]
        for index, call in enumerate(example["tool_calls"], 1):
            req, res = call["request"], call["result"]
            descriptions = {"read_history": "读取已经完成的批次和实验",
                            "inspect_data": "查看当前数据和可恢复的版本",
                            "train_candidate": "训练候选模型", "evaluate_candidate": "实测候选表现",
                            "request_deployment": "申请下一批使用候选", "request_rollback": "申请恢复旧版本",
                            "finish": "结束本批"}
            detail = "程序完成。"
            if req["tool"] == "train_candidate" and res["ok"]:
                detail = f"真实训练{res['training_count']}条数据，得到{res['candidate_id']}。"
            elif req["tool"] == "evaluate_candidate" and res["ok"]:
                detail = (f"同一份留出数据：旧模型{res['current_accuracy']:.1%}，候选{res['candidate_accuracy']:.1%}；"
                          f"{'通过' if res['passed'] else '未通过'}教学门槛。")
            elif req["tool"] == "request_deployment" and res["ok"]:
                detail = "程序重新核验门槛，同意申请；正常结束本批后提交，下一批才生效。"
            elif not res["ok"]:
                detail = f"程序拒绝：{res['error']}。"
            lines += [f"{index}. **{decision_label}：{descriptions[req['tool']]}。** {req['reason']}  ",
                      f"   **程序：** {detail}", ""]
    rollbacks = [e for e in result["events"] if e["action"] == "rollback_next_batch"]
    for e in rollbacks:
        res = next(c["result"] for c in e["tool_calls"] if c["request"]["tool"] == "request_rollback")
        lines += ["## 回滚也经过了检查", "",
                  f"第{e['batch']}批结束时，同一份留出数据上，当前V{e['used_version']}为{res['current_accuracy']:.1%}，"
                  f"旧版V{e['next_version']}为{res['previous_accuracy']:.1%}。程序据此批准下一批恢复旧版，没有再训练。", "",
                  "这里的回滚只是恢复上一个版本，并不保证未来永远更好，也不代表已经具备生产级故障恢复。", ""]
    lines += ["## 已经具备的检查", "",
              "- 只能使用列出的工具和受限参数，不能让决策回复直接执行代码或指定任意文件。",
              "- 候选必须经过真实验证；程序独立决定是否放行，不能凭回复里自报的成绩替换。",
              "- 每批最多10次决策调用、2次候选训练，整个演示最多8次候选训练；失败训练也占预算。",
              "- 决策异常、工具失败、格式错误或达到调用上限时，本批尚未生效的版本申请取消，保留当前版本。",
              "- 训练样本和验证样本分开，历史只包含已完成批次；当前批成绩不会被后续决定改写。", "",
              "88%、4个百分点、训练次数、数据顺序都是教学设置。训练耗时只记录，尚无进程级训练超时和正式比赛Token预算。初始工况验证成绩会记录，但本版还未设置抗遗忘上线门槛。", "",
              "## 还在等什么", "",
              "官方数据、SDK、基线、评分程序、指定千问服务的调用说明，以及SwanLab字段规范。当前没有实现分类以外的任务、策略学习、正式镜像或SwanLab同步。", "",
              "已经接入PyTRiO公开兼容API，并保留百炼适配选项；正式赛方评测环境的认证、资源、SDK时序等仍需按其最终说明联调。", "",
              "完整记录：run.json；逐次操作：tool-trace.jsonl；模型版本：models/。以上均为本地教学记录。"]
    (output / "先看这个_工具通路.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=20261106)
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parent / "harness-results")
    args = parser.parse_args()
    result = run(args.seed)
    write_outputs(result, args.output)
    print(json.dumps({"decision_source": result["decision_source"],
                      "trained_candidates": result["trained_candidates"],
                      "accepted_updates": result["accepted_updates"],
                      "rollbacks": result["rollbacks"], "output": str(args.output)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
