"""Template patch interface and structured tool failures; frozen v1 unchanged.

The core links host tool execution, not provider provenance. A separate controller
must record actual Qwen requests, responses and fallback sources. No SDK claims.
"""
from pathlib import Path
from copy import deepcopy
import ast
import difflib
import hashlib
import json
import math
import shutil
import numpy as np
from experiment_records import Recorder, LocalBackend
from official_model_adapter import sha, module_from, metrics, write_json
from official_training_v2 import Recipe, prepare, launch, verify, CandidateFailure, array_fingerprint, IntegrityError

APPROVED_BASE = '325026d80747eb36f39c8df1be02b640ae21b3cd082827c66aacbdf273dd61c5'

LOSS = '                    loss_sum -= float(np.log(np.maximum(probabilities[np.arange(len(indices)), expected], 1e-300)).sum())'
WEIGHTED_LOSS = '                    loss_sum -= float((np.log(np.maximum(probabilities[np.arange(len(indices)), expected], 1e-300)) * class_weights[expected]).sum())'
DIVIDE = '                    delta /= len(indices)'
WEIGHTED_DIVIDE = '                    delta *= class_weights[expected, None]\n' + DIVIDE
EPOCH = '        epoch_losses = []'
POWERS = (0.0, 0.5, 1.0)


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def approved_edits(power):
    if isinstance(power, bool) or not isinstance(power, (int, float)) or power not in POWERS:
        raise ValueError('unsupported_weight_power')
    setup = ('        class_weights = None\n'
             '        if self.meta["task"] == "classification":\n'
             '            counts = np.bincount(target, minlength=len(self.meta["classes"]))\n'
             f'            class_weights = (len(target) / (len(counts) * np.maximum(counts, 1))) ** {float(power)!r}\n'
             '            class_weights /= np.mean(class_weights[target])\n' + EPOCH)
    return [{'old': EPOCH, 'new': setup}, {'old': LOSS, 'new': WEIGHTED_LOSS},
            {'old': DIVIDE, 'new': WEIGHTED_DIVIDE}]


def apply_checked_patch(original, edits, power):
    """Exact source allowlist; no claim that a general AST scan is a sandbox."""
    if not isinstance(edits, list) or edits != approved_edits(power):
        raise ValueError('patch_outside_reviewed_templates')
    result = original
    for edit in edits:
        if result.count(edit['old']) != 1:
            raise ValueError('patch_anchor_not_unique')
        result = result.replace(edit['old'], edit['new'], 1)
    before, after = ast.parse(original), ast.parse(result)
    # The whole text must be produced by the approved substitutions. AST syntax
    # and unchanged class members are additional compatibility checks only.
    before_class = next(n for n in before.body if isinstance(n, ast.ClassDef) and n.name == 'Model')
    after_class = next(n for n in after.body if isinstance(n, ast.ClassDef) and n.name == 'Model')
    def unchanged(tree):
        return {n.name: ast.dump(n, include_attributes=False) for n in tree.body
                if isinstance(n, ast.FunctionDef) and n.name != 'fit'}
    if unchanged(before_class) != unchanged(after_class):
        raise ValueError('loader_predictor_or_scaling_changed')
    compile(result, 'reviewed-model.py', 'exec')
    return result


class CodeToolsV2:
    def __init__(self, output, source, source_hash, parent, parent_hash,
                 train_x, train_y, selection_x, selection_y, *, recipes,
                 minimum_gain, max_fits=3, max_tool_calls=40, runner=None):
        if source_hash != APPROVED_BASE or sha(source) != source_hash or sha(parent) != parent_hash:
            raise ValueError('source_or_parent_changed')
        if (isinstance(minimum_gain, bool) or not isinstance(minimum_gain, (int, float))
                or not math.isfinite(minimum_gain) or minimum_gain < 0):
            raise ValueError('invalid_minimum_gain')
        if type(max_fits) is not int or not 1 <= max_fits <= 10 or type(max_tool_calls) is not int or max_tool_calls < 1:
            raise ValueError('invalid_budget')
        self.recipes = tuple(recipes)
        if not self.recipes or any(type(r) is not Recipe for r in self.recipes) or len(set(self.recipes)) != len(self.recipes):
            raise ValueError('invalid_recipes')
        self.Model = module_from(source, source_hash).Model
        initial = self.Model.load(parent)
        if initial.meta['task'] != 'classification':
            raise ValueError('v2_supports_classification_only')
        self.output = Path(output).resolve()
        self.output.mkdir(parents=True, exist_ok=False)
        (self.output / 'official-base/baselines').mkdir(parents=True)
        self.base = self.output / 'official-base/baselines/model.py'
        shutil.copyfile(source, self.base)
        self.source_hash = source_hash
        self.original = self.base.read_text(encoding='utf-8')
        # Fail before execution if this is not the reviewed source layout.
        for power in POWERS:
            apply_checked_patch(self.original, approved_edits(power), power)
        initial_path = self.output / 'initial.npz'
        shutil.copyfile(parent, initial_path)
        self.active = {'path': initial_path.name, 'sha256': parent_hash,
                       'source': self.base.relative_to(self.output).as_posix(), 'source_sha256': source_hash}
        self.x, self.y, self.sx, self.sy = [np.array(a, copy=True) for a in (train_x, train_y, selection_x, selection_y)]
        for a in (self.x, self.y, self.sx, self.sy):
            a.flags.writeable = False
        self.training_hash = array_fingerprint(self.x, self.y)
        self.selection_hash = array_fingerprint(self.sx, self.sy)
        self.score = metrics(initial, self.sx, self.sy)[0]
        self.minimum_gain, self.max_fits, self.max_tool_calls = minimum_gain, max_fits, max_tool_calls
        self.runner = runner or launch
        self.attempts = self.calls = 0
        self.history, self.reads, self.sources, self.patches = [], {}, {}, {}
        self.tried = set()
        self.pending = None
        self.closed = False
        self.terminal_reason = None
        self.terminal_details = None
        self.recorder = Recorder('official-code-tools-v2', LocalBackend(self.output / 'records.jsonl'))
        self.recorder.emit('run_start', 'setup', fields={'parent': self.active, 'primary': 'macro_f1',
            'minimum_gain': minimum_gain, 'max_fits': max_fits, 'max_tool_calls': max_tool_calls,
            'approved_weight_powers': list(POWERS), 'controller_source': 'host_tool_linkage_only',
            'remote_controller_connected': False, 'sdk_connected': False,
            'training_arrays_sha256': self.training_hash, 'selection_arrays_sha256': self.selection_hash,
            'training_receives_selection': False, 'resume_supported': False})

    def _tool(self, name):
        if self.terminal_reason is not None:
            raise ValueError('session_terminal')
        if self.closed or self.calls >= self.max_tool_calls:
            raise ValueError('tool_budget_or_closed')
        self.calls += 1
        return self.recorder.emit('tool_call_reserved', 'tool', fields={'name': name, 'ordinal': self.calls})

    def _parent(self):
        path = self.output / self.active['path']
        if (sha(path) != self.active['sha256'] or sha(self.output / self.active['source']) != self.active['source_sha256']
                or sha(self.base) != self.source_hash):
            raise ValueError('active_artifact_changed')
        if array_fingerprint(self.x, self.y) != self.training_hash or array_fingerprint(self.sx, self.sy) != self.selection_hash:
            raise ValueError('data_arrays_changed')
        return path, self.Model.load(path)

    def read_history(self):
        call = self._tool('read_history')
        self._parent()
        result = {'receipt': call, 'completed_cycles': len(self.history),
                  'history_sha256': digest(self.history), 'cycle_ids': [h['cycle_id'] for h in self.history],
                  'active_parent_sha256': self.active['sha256'], 'history': deepcopy(self.history)}
        self.reads[call] = deepcopy(result)
        self.recorder.emit('history_read', 'history', fields=result)
        return deepcopy(result)

    def read_source(self, path='baselines/model.py'):
        call = self._tool('read_source')
        if path != 'baselines/model.py' or sha(self.base) != self.source_hash:
            raise ValueError('source_path_or_hash_not_allowed')
        result = {'receipt': call, 'path': path, 'base_sha256': self.source_hash,
                  'text': self.original, 'base_policy': 'new patch against official template; weights from active selected parent'}
        self.sources[call] = deepcopy(result)
        self.recorder.emit('source_read', 'source', fields={'receipt': call, 'path': path, 'base_sha256': self.source_hash})
        return result

    def write_patch(self, proposal):
        call = self._tool('write_patch')
        expected = {'template', 'source_receipt', 'history_receipt', 'hypothesis', 'weight_power'}
        if not isinstance(proposal, dict) or set(proposal) != expected or proposal['template'] != 'weighted_ce':
            raise ValueError('invalid_patch_fields')
        public_request = deepcopy(proposal)
        proposal = {'path': 'baselines/model.py', 'base_sha256': self.source_hash,
                    'source_receipt': proposal['source_receipt'], 'history_receipt': proposal['history_receipt'],
                    'hypothesis': proposal['hypothesis'], 'weight_power': proposal['weight_power'],
                    'edits': approved_edits(proposal['weight_power'])}
        source = self.sources.get(proposal['source_receipt'])
        history = self.reads.get(proposal['history_receipt'])
        if source is None or history is None or history['history_sha256'] != digest(self.history) or history['active_parent_sha256'] != self.active['sha256']:
            raise ValueError('missing_or_stale_reads')
        if type(proposal['hypothesis']) is not str or not 1 <= len(proposal['hypothesis'].strip()) <= 500:
            raise ValueError('hypothesis_required')
        self._parent()
        text = apply_checked_patch(self.original, proposal['edits'], proposal['weight_power'])
        folder = self.output / f'patch-{len(self.patches) + 1:03d}'
        (folder / 'baselines').mkdir(parents=True)
        target = folder / 'baselines/model.py'
        target.write_text(text, encoding='utf-8', newline='\n')
        diff = ''.join(difflib.unified_diff(self.original.splitlines(True), text.splitlines(True),
                                         fromfile='official/baselines/model.py', tofile='candidate/baselines/model.py'))
        (folder / 'patch.diff').write_text(diff, encoding='utf-8', newline='\n')
        receipt = {'patch_id': call, 'template_request': public_request, 'proposal': deepcopy(proposal), 'source': target.relative_to(self.output).as_posix(),
                   'source_sha256': sha(target), 'diff': (folder / 'patch.diff').relative_to(self.output).as_posix(),
                   'diff_sha256': sha(folder / 'patch.diff'), 'parent': deepcopy(self.active),
                   'history_sha256': history['history_sha256']}
        write_json(folder / 'patch.json', receipt)
        self.patches[call] = deepcopy(receipt)
        self.recorder.emit('patch_written', 'source', fields=receipt)
        return deepcopy(receipt)

    def train_candidate(self, patch_id, recipe):
        self._tool('train_candidate')
        if self.pending is not None or self.attempts >= self.max_fits or recipe not in self.recipes:
            raise ValueError('pending_budget_or_recipe')
        patch = self.patches.get(patch_id)
        if patch is None or patch['parent'] != self.active or patch['history_sha256'] != digest(self.history):
            raise ValueError('unknown_or_stale_patch')
        source = self.output / patch['source']
        patch_receipt = source.parent.parent / 'patch.json'
        try:
            changed = (sha(source) != patch['source_sha256'] or sha(self.output / patch['diff']) != patch['diff_sha256']
                       or json.loads(patch_receipt.read_text(encoding='utf-8')) != patch)
        except (OSError, ValueError) as exc:
            raise IntegrityError('patch_artifact_changed') from exc
        if changed:
            raise IntegrityError('patch_artifact_changed')
        key = digest({'parent': self.active['sha256'], 'source': patch['source_sha256'], 'recipe': recipe.dictionary()})
        if key in self.tried:
            raise ValueError('duplicate_experiment')
        parent_path, parent = self._parent()
        self.attempts += 1
        self.tried.add(key)
        experiment = f'experiment-{self.attempts:03d}'
        reservation = {'experiment_id': experiment, 'patch_id': patch_id, 'parent': deepcopy(self.active),
                       'recipe': recipe.dictionary(), 'attempt': self.attempts}
        self.recorder.emit('training_reserved', 'training', fields=reservation)
        self.pending = deepcopy(reservation)
        folder = self.output / experiment
        request = prepare(folder, source, patch['source_sha256'], parent_path, self.active['sha256'], self.x, self.y, recipe)
        try:
            process = self.runner(folder, 60)
        except CandidateFailure:
            result = {**reservation, 'status': 'training_failed', 'eligible': False,
                      'reason': 'candidate_failure', 'budget_retained': True}
        else:
            Candidate = module_from(source, patch['source_sha256']).Model
            child, receipt = verify(folder, request, parent, Candidate)
            score = metrics(child, self.sx, self.sy)[0]
            gain = score['macro_f1'] - self.score['macro_f1']
            result = {**reservation, 'status': 'evaluated', 'selection_before': deepcopy(self.score),
                      'selection': score, 'gain': gain, 'minimum_gain': self.minimum_gain,
                      'eligible': gain > 1e-12 and gain >= self.minimum_gain,
                      'candidate': {'path': (folder / 'model.npz').relative_to(self.output).as_posix(),
                                    'sha256': sha(folder / 'model.npz'), 'source': patch['source'],
                                    'source_sha256': patch['source_sha256']},
                      'receipt_sha256': sha(folder / 'receipt.json'), 'process': process}
        self._parent()
        result['result_id'] = digest(result)
        self.pending = deepcopy(result)
        self.recorder.emit('experiment_result', 'selection', fields=result)
        return deepcopy(result)

    def decide(self, result_id, decision, reason):
        self._tool('decide')
        result = self.pending
        if result is None or result.get('result_id') != result_id or decision not in {'accept', 'reject'}:
            raise ValueError('decision_must_reference_pending_result')
        if type(reason) is not str or not 1 <= len(reason.strip()) <= 500:
            raise ValueError('decision_reason_required')
        if decision == 'accept' and not result['eligible']:
            raise ValueError('host_rejects_nonimproving_candidate')
        self._parent()
        patch = self.patches[result['patch_id']]
        if result['status'] == 'evaluated':
            if sha(self.output / result['candidate']['path']) != result['candidate']['sha256']:
                raise ValueError('candidate_changed_before_decision')
        if decision == 'accept':
            if sha(self.output / result['candidate']['source']) != result['candidate']['source_sha256']:
                raise ValueError('candidate_source_changed_before_decision')
            self.active = deepcopy(result['candidate'])
            self.score = deepcopy(result['selection'])
        cycle = {'cycle_id': f'cycle-{len(self.history) + 1:03d}', 'controller_source': 'host_tool_linkage_only',
                 'history_receipt': patch['proposal']['history_receipt'],
                 'history_sha256': patch['history_sha256'], 'read_cycle_ids': self.reads[patch['proposal']['history_receipt']]['cycle_ids'],
                 'source_receipt': patch['proposal']['source_receipt'], 'hypothesis': patch['proposal']['hypothesis'],
                 'patch_id': result['patch_id'], 'source_sha256': patch['source_sha256'],
                 'diff_sha256': patch['diff_sha256'], 'experiment_id': result['experiment_id'],
                 'parent_sha256': result['parent']['sha256'], 'result_id': result_id,
                 'result_status': result['status'], 'result_sha256': digest(result),
                 'selection': result.get('selection'), 'gain': result.get('gain'),
                 'decision': decision, 'reason': reason, 'selected_parent': deepcopy(self.active)}
        self.history.append(cycle)
        self.pending = None
        self.recorder.emit('learning_cycle_linked', 'decision', fields=cycle)
        return deepcopy(cycle)

    def _stop(self, code):
        self.terminal_reason = 'integrity_stop'
        if self.pending is not None and 'result_id' not in self.pending:
            result = {**self.pending, 'status': 'integrity_stop', 'eligible': False,
                      'reason_code': code, 'budget_retained': True}
            result['result_id'] = digest(result)
            self.pending = result
            self.recorder.emit('experiment_result', 'selection', fields=result)
        self.terminal_details = {'reason_code': code, 'fit_attempts': self.attempts,
                                 'pending_result_id': (self.pending or {}).get('result_id'),
                                 'automatic_retry': False, 'budget_refunded': False}
        self.recorder.emit('integrity_stop', 'control', fields=self.terminal_details)

    def invoke(self, name, arguments):
        """Structured boundary for controller calls. Log I/O failure still raises.

        Direct methods remain internal engineering primitives. The controller
        uses this boundary; unknown input never becomes raw exception feedback.
        """
        if self.closed or self.terminal_reason:
            return {'ok': False, 'error': 'session_closed' if self.closed else 'session_terminal',
                    'terminal': True, 'fit_attempts': self.attempts}
        before_calls, before_fits = self.calls, self.attempts
        operations = {'read_history', 'read_source', 'write_patch', 'train_candidate', 'decide'}
        safe_name = name if type(name) is str and name in operations else 'invalid_tool'
        try:
            if safe_name == 'invalid_tool' or type(arguments) is not dict:
                raise ValueError('invalid_tool_call')
            if name == 'train_candidate':
                if set(arguments) != {'patch_id', 'recipe'}:
                    raise ValueError('invalid_tool_call')
                value = self.train_candidate(arguments['patch_id'], Recipe.from_dict(arguments['recipe']))
            elif name == 'write_patch':
                value = self.write_patch(arguments)
            else:
                value = getattr(self, name)(**arguments)
            return {'ok': True, 'value': value, 'terminal': False, 'fit_attempts': self.attempts}
        except (ValueError, KeyError, TypeError, OSError) as exc:
            if self.calls == before_calls and self.calls < self.max_tool_calls:
                self._tool(safe_name)
            integrity_codes = {'source_or_parent_changed', 'active_artifact_changed', 'data_arrays_changed',
                               'patch_artifact_changed', 'candidate_changed_before_decision',
                               'candidate_source_changed_before_decision'}
            input_codes = {'invalid_tool_call', 'invalid_patch_fields', 'unsupported_weight_power',
                           'missing_or_stale_reads', 'hypothesis_required', 'pending_budget_or_recipe',
                           'unknown_or_stale_patch', 'duplicate_experiment', 'decision_must_reference_pending_result',
                           'decision_reason_required', 'host_rejects_nonimproving_candidate',
                           'tool_budget_or_closed', 'source_path_or_hash_not_allowed'}
            text = str(exc)
            if isinstance(exc, IntegrityError) or text in integrity_codes or self.attempts > before_fits or isinstance(exc, OSError):
                code = text if text in integrity_codes else 'training_integrity_or_io_failure'
                self._stop(code)
                return {'ok': False, 'error': code, 'terminal': True, 'fit_attempts': self.attempts,
                        'result_id': (self.pending or {}).get('result_id')}
            code = text if text in input_codes else 'invalid_arguments'
            self.recorder.emit('tool_error', 'tool', fields={'name': safe_name,
                                'reason_code': code, 'tool_calls': self.calls, 'terminal': False})
            return {'ok': False, 'error': code, 'terminal': False, 'fit_attempts': self.attempts}

    def close(self):
        if self.closed:
            return
        self.closed = True
        try:
            self._parent()
            active_usable = True
        except (ValueError, OSError):
            active_usable = False
            self.terminal_reason = 'integrity_stop'
        result = {'schema': 'code-tools-v2', 'fit_attempts': self.attempts, 'tool_calls': self.calls,
                  'linked_cycles': len(self.history), 'cycles': deepcopy(self.history), 'active': deepcopy(self.active),
                  'pending': deepcopy(self.pending), 'selection': deepcopy(self.score),
                  'remote_controller_connected': False, 'complete_learning_cycles_inferred': False,
                  'formal_requirement_satisfied': False, 'resume_supported': False,
                  'terminal_reason': self.terminal_reason, 'terminal_details': deepcopy(self.terminal_details),
                  'active_usable': active_usable}
        write_json(self.output / 'result.json', result)
        self.recorder.emit('run_end', 'complete', fields={'result_sha256': sha(self.output / 'result.json'),
                           'linked_cycles': len(self.history), 'fit_attempts': self.attempts})
        write_json(self.output / 'TAIL.json', {'tail_sha256': self.recorder.previous,
                   'records': self.recorder.sequence, 'records_sha256': sha(self.output / 'records.jsonl')})
        self.recorder.close()
        return result
