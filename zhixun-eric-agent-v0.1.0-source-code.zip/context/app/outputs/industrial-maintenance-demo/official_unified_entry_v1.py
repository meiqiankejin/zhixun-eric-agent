"""Unified local A/B/C entry. Default offline; no competition-platform client."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import json
import math
import platform
import shutil
import numpy as np
from official_model_adapter import sha, module_from, metrics, write_json
from official_training_v2 import Recipe
from official_code_tools_v2 import CodeToolsV2, APPROVED_BASE
from unified_code_controller_v1 import CodeController, FinishActions, SYSTEM as CODE_SYSTEM
from official_decision_v3 import DecisionSession, ActionSpace, SYSTEM as PARAM_SYSTEM
from experiment_records import Recorder, LocalBackend
from qwen_config import load_config
from qwen_client import QwenClient
from qwen_direct_transport import direct_post_json

ROOT = Path(__file__).resolve().parents[2]
CODE = Path(__file__).resolve().parent
INPUTS = ROOT / 'inputs/official-platform-2026-11-11'
SPECS = {'A': ('cpu-a-guide-20261110-v1', 'classification', 'macro_f1', 'six_class_macro_f1'),
         'B': ('cpu-b-rul-20261110-v1', 'regression', 'rmse', 'minutes'),
         'C': ('cpu-c-guide-20261110-v1', 'regression', 'rmse', 'cycles')}
CLASSES = ['Ethanol', 'Ethylene', 'Ammonia', 'Acetaldehyde', 'Acetone', 'Toluene']
SOURCES = ['official_unified_entry_v1.py', 'unified_code_controller_v1.py', 'official_code_controller_v2.py',
           'official_code_tools_v2.py', 'official_decision_v3.py', 'official_model_adapter.py', 'official_training_v2.py',
           'official_fit_worker_v2.py', 'experiment_records.py', 'training_supervisor.py', 'training_posix_launch.py',
           'qwen_client.py', 'qwen_config.py', 'qwen_direct_transport.py', 'maintenance_harness.py', 'decision_notes.py', 'demo.py']


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def task_names(tasks):
    if not tasks or len(set(tasks)) != len(tasks) or any(t not in SPECS for t in tasks):
        raise ValueError('invalid_tasks')
    return list(tasks)


def budget(fits, decisions, calls):
    if not (type(fits) is int and 1 <= fits <= 10 and type(decisions) is int and 1 <= decisions <= 10
            and type(calls) is int and 1 <= calls <= 40):
        raise ValueError('invalid_budget')
    return {'fits': fits, 'decisions': decisions, 'provider_calls': calls}


def files(task):
    return ['checkpoint.npz', 'public/train.jsonl', 'public/validation.jsonl', 'TASK.md', 'TRAINING_GUIDE.md',
            'baselines/model.py', 'baselines/data.py', 'baselines/predict.py', 'baselines/requirements.txt',
            f'baselines/configs/{task}.json']


def datasets(package, task):
    directory, kind, primary, units = SPECS[task]
    cfg = load(package / f'baselines/configs/{task}.json')
    Model = module_from(package / 'baselines/model.py', sha(package / 'baselines/model.py')).Model
    parent = Model.load(package / 'checkpoint.npz')
    if (cfg['profile'] != task or cfg['task'] != kind or parent.meta['task'] != kind
            or cfg['classes'] != parent.meta['classes'] or cfg['hidden'] != parent.meta['hidden']
            or parent.meta['classes'] != (CLASSES if task == 'A' else [])):
        raise ValueError('task_config_checkpoint_mismatch')
    if task == 'B' and cfg.get('target_unit') != 'minutes':
        raise ValueError('B_requires_minutes_regression')
    if task == 'A' and sha(package / 'baselines/model.py') != APPROVED_BASE:
        raise ValueError('A_requires_approved_template_source')
    reader = module_from(package / 'baselines/data.py', sha(package / 'baselines/data.py'))
    args = kind, parent.meta['classes'], parent.meta['paths']
    train, selection = [reader.read_dataset(package / f'public/{n}.jsonl', *args) for n in ('train', 'validation')]
    if not len(train['y']) or not len(selection['y']) or set(train['ids']) & set(selection['ids']):
        raise ValueError('empty_or_overlapping_split')
    groups = []
    for name in ('train', 'validation'):
        rows = [json.loads(line) for line in (package / f'public/{name}.jsonl').read_text(encoding='utf-8').splitlines()]
        if task == 'B':
            groups.append({r['meta']['bearing'] for r in rows})
        elif task == 'C':
            groups.append({(r['meta']['source_subset'], r['meta']['unit']) for r in rows})
    if groups and groups[0] & groups[1]:
        raise ValueError('training_validation_device_overlap')
    return Model, parent, train, selection


def freeze(folder, *, inputs=INPUTS, tasks=('A', 'B', 'C'), max_fits=10, max_decisions=10, calls=None,
           synthetic=False):
    tasks = task_names(tasks)
    if type(synthetic) is not bool:
        raise ValueError('invalid_fixture_flag')
    calls = calls or {'A': 40, 'B': 20, 'C': 20}
    entries = {}
    for task in tasks:
        package = Path(inputs).resolve() / SPECS[task][0]
        limits = budget(max_fits, max_decisions, calls[task])
        Model, parent, train, val = datasets(package, task)
        recipes = [Recipe(parent.meta['learning_rate'] / divisor, parent.meta['batch_size'], epochs).dictionary()
                   for epochs in (1, 3) for divisor in (1, 3, 10)]
        entries[task] = {'package': SPECS[task][0], 'kind': SPECS[task][1], 'primary': SPECS[task][2],
                         'units': SPECS[task][3], 'hashes': {n: sha(package / n) for n in files(task)},
                         'controller': 'reviewed_code_templates' if task == 'A' else 'parameter_controller',
                         'minimum_gain': {'A': .001, 'B': .5, 'C': .1}[task], 'recipes': recipes,
                         'budgets': limits, 'rows': {'train': len(train['y']), 'validation': len(val['y'])}}
    folder = Path(folder).resolve()
    plan = {'schema': 'official-unified-local-v1', 'created_utc': datetime.now(timezone.utc).isoformat(),
            'python': platform.python_version(), 'numpy': np.__version__, 'tasks': entries,
            'sources': {name: sha(CODE / name) for name in SOURCES}, 'synthetic_fixture': bool(synthetic),
            'selection': 'public validation reused; no hidden-quality claim', 'train': 'train.jsonl only',
            'provider': {'endpoint': 'https://pytrio.com/api/openai/v1', 'model': 'Qwen/Qwen3.8-27B',
                         'timeout': 90, 'output_tokens': 4096, 'input_bytes': 60000,
                         'temperature': 0, 'thinking': 'provider default'},
            'round_definition': 'local fit/decision/provider budgets; finish may end early; failures count',
            'A_decision_semantics': 'proposal and post-result decision; <=2 provider requests per phase; finish at proposal',
            'BC_decision_semantics': 'one train-or-finish phase; host selects; <=2 provider requests per round',
            'worker_timeout_seconds': 60, 'worker_memory_limit_mb': 1024,
            'resume_supported': False, 'sdk_compatible': False, 'cloud_synced': False,
            'official_round_equivalence_confirmed': False, 'official_numpy1264_training_verified': False,
            'formal_requirement_satisfied': False, 'new_streams_used': False, 'platform_runs': 0}
    folder.mkdir(parents=True, exist_ok=False)
    write_json(folder / 'plan.json', plan)
    write_json(folder / 'PIN.json', {'plan_sha256': sha(folder / 'plan.json')})
    return plan


def verify(folder, inputs=INPUTS, *, runtime=True):
    folder, inputs = Path(folder), Path(inputs).resolve()
    plan = load(folder / 'plan.json')
    if sha(folder / 'plan.json') != load(folder / 'PIN.json')['plan_sha256'] or plan['schema'] != 'official-unified-local-v1':
        raise ValueError('plan_changed')
    task_names(list(plan['tasks']))
    if runtime and (plan['python'], plan['numpy']) != (platform.python_version(), np.__version__):
        raise ValueError('runtime_changed')
    if set(plan['sources']) != set(SOURCES) or any(sha(CODE / n) != h for n, h in plan['sources'].items()):
        raise ValueError('source_changed')
    for task, item in plan['tasks'].items():
        budget(**{'fits': item['budgets']['fits'], 'decisions': item['budgets']['decisions'], 'calls': item['budgets']['provider_calls']})
        if (item['package'], item['kind'], item['primary'], item['units']) != SPECS[task]:
            raise ValueError('task_mapping_changed')
        package = inputs / item['package']
        if set(item['hashes']) != set(files(task)) or any(sha(package / n) != h for n, h in item['hashes'].items()):
            raise ValueError('input_changed')
    return plan


def export_selected(package, task, checkpoint, source, output, *, provenance):
    """Caller supplies verified selected artifacts; this also binds hashes and config."""
    output = Path(output)
    if output.exists():
        raise ValueError('export_exists')
    Model = module_from(source, sha(source)).Model
    model = Model.load(checkpoint)
    if task not in SPECS or model.meta['task'] != SPECS[task][1]:
        raise ValueError('export_task_mismatch')
    cfg = load(package / f'baselines/configs/{task}.json')
    if model.meta['task'] != SPECS[task][1] or model.meta['classes'] != cfg['classes'] or cfg['profile'] != task:
        raise ValueError('export_task_mismatch')
    output.mkdir(parents=True)
    for name in ['data.py', 'predict.py', 'requirements.txt', f'configs/{task}.json']:
        target = output / 'baselines' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(package / 'baselines' / name, target)
    shutil.copyfile(source, output / 'baselines/model.py')
    shutil.copyfile(checkpoint, output / 'checkpoint.npz')
    if (sha(output / 'checkpoint.npz') != sha(checkpoint) or sha(output / 'baselines/model.py') != sha(source)
            or sha(output / f'baselines/configs/{task}.json') != sha(package / f'baselines/configs/{task}.json')):
        raise ValueError('export_artifact_changed')
    Model.load(output / 'checkpoint.npz')
    write_json(output / 'provenance.json', {**provenance, 'task': task, 'units': SPECS[task][3],
        'checkpoint_sha256': sha(checkpoint), 'source_sha256': sha(source),
        'config_sha256': sha(package / f'baselines/configs/{task}.json'), 'sdk_compatible': False})
    manifest = {p.relative_to(output).as_posix(): sha(p) for p in sorted(output.rglob('*')) if p.is_file()}
    write_json(output / 'EXPORT.json', manifest)
    return {'directory': output.name, 'manifest_sha256': sha(output / 'EXPORT.json'), **load(output / 'provenance.json')}


def usage(client):
    return {'calls': client.calls, 'records': client.records,
            'reported_tokens': {k: sum((r.get('usage') or {}).get(k, 0) for r in client.records)
                                for k in ('prompt_tokens', 'completion_tokens', 'total_tokens')},
            'without_usage': sum(r.get('usage') is None for r in client.records), 'currency_cost_known': False}


def grouped_metrics(package, task, model, val):
    if task == 'A':
        return {}
    rows = [json.loads(s) for s in (package / 'public/validation.jsonl').read_text(encoding='utf-8').splitlines()]
    groups = [r['meta']['bearing'] if task == 'B' else r['meta']['source_subset'] for r in rows]
    return {g: metrics(model, val['x'][np.asarray(groups) == g], val['y'][np.asarray(groups) == g])[0] for g in sorted(set(groups))}


def run_task(task, item, package, folder, client, *, live, runner=None):
    Model, parent, train, val = datasets(package, task)
    limits, recipes = item['budgets'], [Recipe.from_dict(r) for r in item['recipes']]
    initial = metrics(parent, val['x'], val['y'])[0]
    folder.mkdir(parents=True, exist_ok=False)
    if task == 'A':
        engine = CodeToolsV2(folder / 'session', package / 'baselines/model.py', item['hashes']['baselines/model.py'],
            package / 'checkpoint.npz', item['hashes']['checkpoint.npz'], train['x'], train['y'], val['x'], val['y'],
            recipes=recipes, minimum_gain=item['minimum_gain'], max_fits=limits['fits'],
            max_tool_calls=6 * limits['fits'] + 6, runner=runner)
        controller = CodeController(engine, client, allow_live=live, max_provider_calls=limits['provider_calls'],
                                   experiments=min(limits['fits'], limits['decisions']), first_nonzero=False)
        try:
            raw = controller.run()
        finally:
            if not engine.closed:
                engine.close()
        core = raw['engine']
        active = core['active']
        source, checkpoint = engine.output / active['source'], engine.output / active['path']
        status, reason = raw['status'], raw.get('reason', raw['status'])
        fits, calls, selected = core['fit_attempts'], raw['provider_calls_reserved'], core['selection']
        decisions = raw['proposal_rounds']
        failures = sum(c['result_status'] == 'training_failed' for c in core['cycles'])
        usable = core['active_usable']
        tail = load(engine.output / 'TAIL.json')
        patches = [c['diff_sha256'] for c in core['cycles'] if c['decision'] == 'accept']
        accepted = sum(c['decision'] == 'accept' for c in core['cycles'])
    else:
        session = DecisionSession(folder / 'session', package / 'baselines/model.py', item['hashes']['baselines/model.py'],
            package / 'checkpoint.npz', item['hashes']['checkpoint.npz'], train['x'], train['y'], val['x'], val['y'],
            actions=ActionSpace(recipes), primary=item['primary'], minimum_gain=item['minimum_gain'],
            max_fits=limits['fits'], max_decisions=limits['decisions'], max_provider_calls=limits['provider_calls'],
            data_scope=f'unified_{task}_train_only_public_selection', client=client, allow_live=live, runner=runner)
        raw = session.run()
        active = raw['final_version']
        source, checkpoint = session.source, session.output / active['path']
        status, reason = raw['status'], raw['reason']
        fits, calls, decisions, selected = raw['fit_attempts'], raw['provider_attempts'], raw['decision_rounds'], raw['selection']
        failures = sum(c['status'] == 'training_failed' for c in raw['history'])
        usable = raw['active_usable']
        tail = load(session.output / 'EXTERNAL-TAIL.json')
        patches, accepted = [], sum(c['accepted'] for c in raw['history'])
    if not usable:
        status, reason = 'integrity_stop', 'selected_artifact_unverified'
    if usable and (sha(checkpoint) != active['sha256'] or (task == 'A' and sha(source) != active['source_sha256'])):
        raise ValueError('selected_artifact_changed')
    if usable:
        score = metrics(Model.load(checkpoint), val['x'], val['y'])[0]
        for key in ('macro_f1', 'accuracy', 'rmse', 'mae'):
            if key in score and abs(score[key] - selected[key]) > 1e-9:
                raise ValueError('selected_metrics_changed')
    report = {'task': task, 'status': status, 'reason': reason, 'primary': item['primary'], 'units': item['units'],
              'initial': initial, 'selected': selected, 'fit_attempts': fits, 'provider_reservations': calls,
              'decision_rounds': decisions, 'training_failures': failures, 'accepted': accepted, 'budgets': limits,
              'session_tail': tail, 'active_usable': usable, 'api_usage': usage(client), 'export': None,
              'group_metrics': grouped_metrics(package, task, Model.load(checkpoint), val) if usable else None,
              'C_nasa_auxiliary_implemented': False if task == 'C' else None,
              'formal_requirement_satisfied': False, 'sdk_compatible': False, 'cloud_synced': False}
    write_json(folder / 'api-usage.json', report['api_usage'])
    if usable:
        report['export'] = export_selected(package, task, checkpoint, source, folder / 'selected', provenance={
            'initial_checkpoint_sha256': item['hashes']['checkpoint.npz'], 'accepted_patch_diff_sha256': patches,
            'session_tail_sha256': tail['tail_sha256'], 'selected_not_hidden_evaluated': True})
    write_json(folder / 'task-result.json', report)
    return report


def execute(plan_folder, output, *, inputs=INPUTS, live=False, factory=None, runners=None):
    plan = verify(plan_folder, inputs)
    output = Path(output).resolve()
    if output.exists():
        raise ValueError('output_exists')
    if output.is_relative_to(Path(plan_folder).resolve()) or output.is_relative_to(Path(inputs).resolve()):
        raise ValueError('output_inside_plan_or_inputs')
    if not live and factory is None:
        raise ValueError('explicit_live_flag_or_injected_factory_required')
    if live and (factory is not None or plan['synthetic_fixture']):
        raise ValueError('live_fixture_or_factory_forbidden')
    # Validate every task before credentials or output creation.
    for task, item in plan['tasks'].items():
        datasets(Path(inputs) / item['package'], task)
    config = load_config() if live else None
    if live and (config['base_url'], config['model']) != (plan['provider']['endpoint'], plan['provider']['model']):
        raise ValueError('provider_changed')
    output.mkdir(parents=True, exist_ok=False)
    shutil.copytree(plan_folder, output / 'frozen-plan')
    (output / 'source').mkdir()
    for name in SOURCES:
        shutil.copyfile(CODE / name, output / 'source' / name)
    recorder = Recorder('official-unified-local-v1', LocalBackend(output / 'records.jsonl'))
    results, status = {}, 'completed'
    recorder.emit('run_start', 'setup', fields={'plan_sha256': sha(Path(plan_folder) / 'plan.json'),
        'python': platform.python_version(), 'numpy': np.__version__, 'source_hashes': plan['sources'],
        'data_hashes': {t: i['hashes'] for t, i in plan['tasks'].items()},
        'mode': 'qwen_live' if live else 'qwen_protocol_injected', 'synthetic_fixture': plan['synthetic_fixture'],
        'sdk_compatible': False, 'cloud_synced': False, 'platform_runs': 0})
    try:
        for task, item in plan['tasks'].items():
            if status == 'host_failure':
                results[task] = {'status': 'not_started'}
                continue
            recipes = [Recipe.from_dict(r) for r in item['recipes']]
            actions = FinishActions(recipes) if task == 'A' else ActionSpace(recipes)
            system = CODE_SYSTEM if task == 'A' else PARAM_SYSTEM
            system += f' 任务{task}；单位{item["units"]}；主指标{item["primary"]}；本地开发工程门槛，非官方评分。'
            recorder.emit('task_start', 'control', fields={'task': task, 'budgets': item['budgets'], 'controller': item['controller']})
            try:
                verify(plan_folder, inputs)
                if live:
                    client = QwenClient(**config, max_calls=item['budgets']['provider_calls'],
                        max_output_tokens=plan['provider']['output_tokens'], max_input_bytes=plan['provider']['input_bytes'],
                        timeout=plan['provider']['timeout'], task_system=system, action_validator=actions.parse)
                    client._transport = direct_post_json
                else:
                    client = factory(task, item, actions, system)
                    if type(client) is not QwenClient or not client._transport_is_injected:
                        raise ValueError('offline_requires_injected_exact_client')
                result = run_task(task, item, Path(inputs) / item['package'], output / task, client,
                                  live=live, runner=(runners or {}).get(task))
                verify(plan_folder, inputs)
            except Exception as exc:
                # Preserve partial child records/budget reservations. Never fabricate zero spending.
                result = {'task': task, 'status': 'host_failure', 'reason': 'host_io_failed' if isinstance(exc, OSError) else 'host_operation_failed',
                          'budget_refunded': False, 'usage_complete': False, 'automatic_retry': False,
                          'fit_attempts': None, 'provider_reservations': None, 'export': None,
                          'partial_files_sha256': {p.relative_to(output / task).as_posix(): sha(p)
                              for p in sorted((output / task).rglob('*')) if p.is_file()}}
                status = 'host_failure'
            results[task] = result
            recorder.emit('task_completed', 'control', fields={'task': task, 'result': result,
                'task_result_sha256': sha(output / task / 'task-result.json') if (output / task / 'task-result.json').is_file() else None})
        if status != 'host_failure' and any(r['status'] not in {'completed', 'finished'} or r['training_failures'] for r in results.values()):
            status = 'completed_with_failures'
        recorder.emit('acceptance', 'complete', fields={'all_tasks_returned': all(r['status'] != 'not_started' for r in results.values()),
            'all_exports_verified': all(r.get('export') is not None for r in results.values()),
            'status': status, 'quality_effect_claimed': False, 'formal_requirement_satisfied': False})
        report = {'schema': 'official-unified-result-v1', 'status': status, 'tasks': results,
                  'mode': 'qwen_live' if live else 'qwen_protocol_injected', 'synthetic_fixture': plan['synthetic_fixture'],
                  'sdk_compatible': False, 'cloud_synced': False, 'platform_runs': 0, 'formal_requirement_satisfied': False}
        write_json(output / 'result.json', report)
        recorder.emit('run_end', 'complete', fields={'status': status, 'result_sha256': sha(output / 'result.json')})
        write_json(output / 'EXTERNAL-TAIL.json', {'records': recorder.sequence, 'tail_sha256': recorder.previous,
                                                'records_sha256': sha(output / 'records.jsonl')})
        return report
    finally:
        recorder.close()


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode', choices=['freeze', 'check', 'run'])
    p.add_argument('--plan', required=True)
    p.add_argument('--inputs-root', default=str(INPUTS))
    p.add_argument('--tasks', default='ABC')
    p.add_argument('--output')
    p.add_argument('--max-fits', type=int, default=10)
    p.add_argument('--max-decisions', type=int, default=10)
    p.add_argument('--live', action='store_true')
    a = p.parse_args()
    if a.mode == 'freeze':
        freeze(a.plan, inputs=a.inputs_root, tasks=tuple(a.tasks), max_fits=a.max_fits, max_decisions=a.max_decisions)
    elif a.mode == 'check':
        verify(a.plan, a.inputs_root)
        print(json.dumps({'passed': True, 'training_calls': 0, 'api_calls': 0}))
    else:
        if not a.output:
            p.error('--output required for run')
        print(json.dumps(execute(a.plan, a.output, inputs=a.inputs_root, live=a.live), ensure_ascii=False))
