"""Per-round bounded re-selection; frozen v2 remains untouched.

Only the known QwenClient is supported. Explicit live consent remains a caller's
obligation, not something a Python flag or class identity can establish.
"""
from pathlib import Path
from copy import deepcopy
import json
import math
import shutil
import numpy as np
from experiment_records import Recorder, LocalBackend
from official_model_adapter import sha, write_json, module_from, metrics
from official_training_v2 import (Recipe, strict_json, recipe_key, array_fingerprint,
                                  IntegrityError, CandidateFailure, prepare, launch, verify)
from qwen_client import QwenClient, ConnectionFailure
from training_supervisor import run_process
import sys


class WorkerLaunchFailure(RuntimeError):
    """Launch/supervision raised: stop safely, do not assume cleanup or retry."""


def launch_with_startup_classification(folder, timeout=60):
    worker = Path(__file__).with_name('official_fit_worker_v2.py')
    try:
        result = run_process([str(Path(sys.executable).resolve()), '-I', '-B', str(worker), str(Path(folder).resolve())],
                             str(Path(folder).resolve()), timeout, memory_mb=1024)
    except OSError as exc:
        raise WorkerLaunchFailure('launch_or_supervision_failed') from exc
    # Disk/log I/O is outside the launch-exception boundary and still propagates.
    write_json(Path(folder) / 'attempt.json', result)
    if result['status'] in {'timeout', 'worker_failed'}:
        failure_path = Path(folder) / 'failure.json'
        if failure_path.is_file() and strict_json(failure_path.read_text(encoding='utf-8')).get('kind') == 'integrity':
            raise IntegrityError('worker_integrity_failure')
        raise CandidateFailure(result['status'])
    if result['status'] != 'completed':
        raise IntegrityError('worker_cleanup_not_confirmed')
    return result

SYSTEM = ('你是工业模型训练决策端。仅返回reason、tool、arguments的JSON。'
          'train_candidate可选宿主白名单内learning_rate、batch_size、epochs；finish保留当前版本并结束。'
          '只依据宿主给出的挑选指标和本次历史，不读取文件或复核集。候选是否接受由宿主决定。'
          '候选被拒可尝试不同配置；遵守预算，不重复相同父版本和配置。')


class ActionSpace:
    def __init__(self, recipes):
        self.recipes = tuple(recipes)
        if not self.recipes or any(not isinstance(r, Recipe) for r in self.recipes) or len(set(self.recipes)) != len(self.recipes):
            raise ValueError('invalid_action_space')

    def parse(self, raw):
        if not isinstance(raw, str) or len(raw) > 8192:
            raise ValueError('invalid_action_size')
        action = strict_json(raw)
        if not isinstance(action, dict) or set(action) != {'reason', 'tool', 'arguments'}:
            raise ValueError('invalid_action_fields')
        if not isinstance(action['reason'], str) or not 1 <= len(action['reason'].strip()) <= 500:
            raise ValueError('invalid_reason')
        if action['tool'] == 'finish' and action['arguments'] == {}:
            return action
        if action['tool'] != 'train_candidate':
            raise ValueError('unknown_tool')
        if Recipe.from_dict(action['arguments']) not in self.recipes:
            raise ValueError('recipe_not_allowed')
        return action

    def tools(self):
        properties = {key: {'type': 'number' if key == 'learning_rate' else 'integer',
                            'enum': sorted({getattr(r, key) for r in self.recipes})}
                      for key in ('learning_rate', 'batch_size', 'epochs')}
        return [{'name': 'train_candidate', 'description': 'Train one allowed configuration; host rechecks allowed combinations.',
                 'parameters': {'type': 'object', 'properties': properties,
                                'required': list(properties), 'additionalProperties': False}},
                {'name': 'finish', 'description': 'Keep current model and finish.',
                 'parameters': {'type': 'object', 'properties': {}, 'required': [], 'additionalProperties': False}}]


class DecisionSession:
    def __init__(self, output, model_source, source_hash, parent_path, parent_hash, train_x, train_y, selection_x, selection_y,
                 *, actions, primary, minimum_gain, max_fits, max_decisions, max_provider_calls, data_scope,
                 client=None, allow_live=False, timeout=60, runner=None):
        if primary not in {'macro_f1', 'rmse'}:
            raise ValueError('invalid_primary_metric')
        if isinstance(minimum_gain, bool) or not isinstance(minimum_gain, (float, int)) or not math.isfinite(minimum_gain) or minimum_gain < 0:
            raise ValueError('explicit_minimum_gain_required')
        if any(type(n) is not int or n < 0 for n in (max_fits, max_decisions, max_provider_calls)):
            raise ValueError('invalid_budget')
        if not isinstance(data_scope, str) or not data_scope:
            raise ValueError('data_scope_required')
        if client is not None and type(client) is not QwenClient:
            raise ValueError('unsupported_client_type')
        if client is not None and (client.protocol != 'json_actions' or client.calls != 0
                                   or client.max_calls < max_provider_calls):
            raise ValueError('client_protocol_or_budget_mismatch')
        self.injected = client is not None and client._transport_is_injected is True
        if client is not None and not self.injected and not allow_live:
            raise ValueError('live_calls_not_authorized')
        if sha(model_source) != source_hash or sha(parent_path) != parent_hash:
            raise IntegrityError('source_or_parent_changed')
        self.output = Path(output).resolve()
        self.output.mkdir(parents=True, exist_ok=False)
        self.models_dir = self.output / 'models'
        self.models_dir.mkdir()
        self.source = self.output / 'model-source.py'
        shutil.copyfile(model_source, self.source)
        self.source_hash = source_hash
        self.Model = module_from(self.source, source_hash).Model
        path = self.models_dir / 'v0.npz'
        shutil.copyfile(parent_path, path)
        parent = self.Model.load(path)
        if (parent.meta['task'] == 'classification') != (primary == 'macro_f1'):
            raise ValueError('task_metric_mismatch')
        self.x, self.y = np.array(train_x, copy=True), np.array(train_y, copy=True)
        self.sx, self.sy = np.array(selection_x, copy=True), np.array(selection_y, copy=True)
        for array in (self.x, self.y, self.sx, self.sy):
            array.flags.writeable = False
        self.train_hash, self.selection_hash = array_fingerprint(self.x, self.y), array_fingerprint(self.sx, self.sy)
        self.actions, self.primary, self.minimum_gain = actions, primary, minimum_gain
        self.max_fits, self.max_decisions, self.max_provider_calls = max_fits, max_decisions, max_provider_calls
        self.client, self.timeout, self.runner = client, timeout, runner or launch_with_startup_classification
        self.feedback, self.provider_outcomes = [], []
        self.retry_requests = self.fallback_rounds = self.successful_actions = 0
        self.launch_failed = False
        self.history, self.tried, self.stack, self.quarantined = [], [], [{'path': 'models/v0.npz', 'sha256': parent_hash}], []
        self.score = metrics(parent, self.sx, self.sy)[0]
        self.fit_attempts = self.decision_rounds = self.provider_attempts = self.revision = 0
        self.pending = None
        self.fallback = client is None
        self.locked = False
        self.recorder = Recorder('official-decision-interface-v3', LocalBackend(self.output / 'records.jsonl'))
        self.recorder.emit('run_start', 'setup', fields={'data_scope': data_scope, 'source_sha256': source_hash,
            'parent_sha256': parent_hash, 'training_arrays_sha256': self.train_hash, 'selection_arrays_sha256': self.selection_hash,
            'allowed_recipes_in_fallback_order': [r.dictionary() for r in actions.recipes],
            'primary_metric': primary, 'minimum_gain': minimum_gain,
            'quality_rule': 'gain > 1e-12 AND gain >= minimum_gain; caller-defined, not official scoring',
            'max_fits': max_fits, 'max_decisions': max_decisions, 'max_provider_calls': max_provider_calls,
            'transport': 'injected' if self.injected else 'live_authorized' if client is not None and allow_live else 'local',
            'resume_supported': False, 'review_received': False,
            'requests_per_decision_round': 2, 'fallback_scope': 'current_round_only_unless_total_budget_exhausted',
            'retain_all_runs_including_failures': True, 'supported_client': 'exact_QwenClient_json_actions'})
        self._checkpoint('initialized')

    def _state(self):
        return {'schema': 'official-decision-state-v3', 'fit_attempts': self.fit_attempts, 'decision_rounds': self.decision_rounds,
                'provider_attempts': self.provider_attempts, 'revision': self.revision,
                'stack': deepcopy(self.stack), 'quarantined': self.quarantined[:], 'tried': self.tried[:],
                'pending': deepcopy(self.pending), 'fallback': self.fallback, 'locked': self.locked,
                'feedback': deepcopy(self.feedback), 'provider_outcomes': deepcopy(self.provider_outcomes),
                'retry_requests': self.retry_requests, 'fallback_rounds': self.fallback_rounds,
                'successful_actions': self.successful_actions, 'launch_failed': self.launch_failed}

    def _checkpoint(self, reason):
        self.revision += 1
        path = self.output / f'state-{self.revision:03d}.json'
        state = self._state()
        write_json(path, state)
        self.recorder.emit('control_v3_checkpoint', 'control', fields={'reason': reason, 'state': state,
                           'path': path.name, 'state_sha256': sha(path)})

    def _active(self):
        entry = self.stack[-1]
        path = self.output / entry['path']
        if sha(path) != entry['sha256'] or sha(self.source) != self.source_hash:
            raise IntegrityError('active_artifact_changed')
        if array_fingerprint(self.x, self.y) != self.train_hash or array_fingerprint(self.sx, self.sy) != self.selection_hash:
            raise IntegrityError('data_changed')
        return path, self.Model.load(path)

    def _key(self, recipe):
        return recipe_key(self.stack[-1]['sha256'], self.train_hash, recipe)

    def _fixed(self):
        for recipe in self.actions.recipes:
            if self._key(recipe) not in self.tried:
                return {'reason': 'fixed_next_untried_configuration', 'tool': 'train_candidate', 'arguments': recipe.dictionary()}
        return {'reason': 'no_untried_configuration', 'tool': 'finish', 'arguments': {}}

    def _provider_metadata(self):
        # Record bounded numeric usage/model identity, never provider text or credentials.
        result = {'transport': 'injected' if self.injected else 'external'}
        entries = getattr(self.client, 'records', [])
        if entries:
            entry = entries[-1]
            result['usage'] = {key: value for key, value in (entry.get('usage') or {}).items()
                               if key in {'prompt_tokens', 'completion_tokens', 'total_tokens'} and type(value) is int and value >= 0}
            for key in ('model_requested', 'model_returned', 'status'):
                if isinstance(entry.get(key), str) and len(entry[key]) <= 150:
                    result[key] = entry[key]
        return result

    def _decision(self):
        if self.client is None:
            self.fallback = True
            return self._fixed(), 'fixed_rule_without_controller'
        self.fallback = False
        fallback_reason = 'provider_budget_exhausted'
        for ordinal in (1, 2):
            if self.provider_attempts >= self.max_provider_calls:
                break
            self.provider_attempts += 1
            if ordinal == 2:
                self.retry_requests += 1
            self._checkpoint('provider_call_reserved')
            view = {'selection': self.score, 'history': deepcopy(self.history), 'controller_feedback': deepcopy(self.feedback),
                    'remaining_fits': self.max_fits - self.fit_attempts,
                    'remaining_provider_calls_after_this_request': self.max_provider_calls - self.provider_attempts,
                    'remaining_decision_rounds_after_current': self.max_decisions - self.decision_rounds,
                    'remaining_requests_in_current_round_after_this': 2 - ordinal,
                    'tried_recipes_for_current_parent': [r.dictionary() for r in self.actions.recipes if self._key(r) in self.tried],
                    'allowed_recipes': [r.dictionary() for r in self.actions.recipes], 'minimum_gain': self.minimum_gain}
            self.recorder.emit('controller_input', 'decision', fields={'round': self.decision_rounds, 'request_in_round': ordinal,
                                                                       'provider_attempts': self.provider_attempts, 'view': view})
            messages = [{'role': 'system', 'content': SYSTEM}, {'role': 'user', 'content': json.dumps(view, ensure_ascii=False)}]
            before_records = len(self.client.records)
            error, parsed_recipe = None, None
            try:
                raw = self.client.respond(messages, self.actions.tools())
                action = self.actions.parse(raw)
                if action['tool'] == 'train_candidate':
                    parsed_recipe = action['arguments']
                    if self._key(Recipe.from_dict(parsed_recipe)) in self.tried:
                        error = 'duplicate_configuration'
            except (ValueError, ConnectionFailure) as exc:
                error = 'invalid_action' if isinstance(exc, ValueError) or str(exc) == 'invalid_remote_action' else 'provider_call_failed'
            except Exception:
                error = 'provider_call_failed'
            metadata = self._provider_metadata() if len(self.client.records) > before_records else {
                'transport': 'injected' if self.injected else 'external', 'request_recorded': False}
            outcome = {'round': self.decision_rounds, 'request_in_round': ordinal, 'provider_attempts': self.provider_attempts,
                       'status': 'rejected' if error else 'ok', 'reason_code': error, 'metadata': metadata}
            if error:
                feedback = {'round': self.decision_rounds, 'request_in_round': ordinal, 'code': error}
                if parsed_recipe is not None:
                    feedback['attempted_recipe'] = parsed_recipe
                self.feedback.append(feedback)
                self.provider_outcomes.append(outcome)
                self.recorder.emit('controller_rejected', 'decision', fields=outcome)
                self._checkpoint('feedback_recorded_for_reselection')
                fallback_reason = 'round_request_limit_reached'
                continue
            self.successful_actions += 1
            self.provider_outcomes.append(outcome)
            self.recorder.emit('controller_responded', 'decision', fields=outcome)
            return action, 'qwen_protocol_injected' if self.injected else 'qwen_live'
        self.fallback, self.fallback_rounds = True, self.fallback_rounds + 1
        if self.provider_attempts >= self.max_provider_calls:
            fallback_reason = 'provider_budget_exhausted'
        self.recorder.emit('rule_takeover', 'decision', fields={'round': self.decision_rounds, 'reason': fallback_reason,
                                                             'scope': 'current_round', 'provider_attempts': self.provider_attempts})
        self._checkpoint('fixed_rule_for_current_round')
        return self._fixed(), 'fixed_rule_fallback'

    def _train(self, action, decision_source):
        recipe = Recipe.from_dict(action['arguments'])
        if recipe not in self.actions.recipes:
            raise IntegrityError('recipe_outside_action_space')
        parent_path, parent = self._active()
        key = self._key(recipe)
        if self.fit_attempts >= self.max_fits or key in self.tried:
            raise IntegrityError('budget_or_duplicate_invariant')
        self.fit_attempts += 1
        self.tried.append(key)
        self.pending = {'parent_sha256': self.stack[-1]['sha256'], 'recipe': recipe.dictionary(),
                        'attempt': self.fit_attempts, 'decision_source': decision_source, 'key': key}
        self._checkpoint('training_budget_reserved')
        folder = self.output / f'fit-{self.fit_attempts}'
        request = prepare(folder, self.source, self.source_hash, parent_path, self.stack[-1]['sha256'], self.x, self.y, recipe)
        self.recorder.emit('fit_started', 'training', fields={'attempt': self.fit_attempts, 'request': request,
                                                            'decision_source': decision_source})
        try:
            process = self.runner(folder, self.timeout)
        except CandidateFailure as exc:
            self._active()
            result = {'attempt': self.fit_attempts, 'recipe': recipe.dictionary(), 'parent_sha256': self.stack[-1]['sha256'],
                      'accepted': False, 'status': 'training_failed', 'reason_code': 'timeout' if str(exc) == 'timeout' else 'worker_failed',
                      'decision_source': decision_source}
            self.history.append(result)
            self.pending = None
            self.recorder.emit('candidate_training_failed', 'training', fields=result)
            self._checkpoint('training_failed_budget_retained')
            return
        try:
            child, receipt = verify(folder, request, parent, self.Model)
        except (ValueError, KeyError, TypeError) as exc:
            raise IntegrityError('candidate_output_contract_failed') from exc
        self._active()
        score = metrics(child, self.sx, self.sy)[0]
        gain = score[self.primary] - self.score[self.primary] if self.primary == 'macro_f1' else self.score[self.primary] - score[self.primary]
        accepted = gain > 1e-12 and gain >= self.minimum_gain
        result = {'attempt': self.fit_attempts, 'recipe': recipe.dictionary(), 'parent_sha256': self.stack[-1]['sha256'],
                  'candidate_sha256': sha(folder / 'model.npz'), 'parent_selection': self.score, 'selection': score,
                  'gain': gain, 'minimum_gain': self.minimum_gain, 'accepted': accepted, 'status': 'evaluated',
                  'decision_source': decision_source, 'receipt_sha256': sha(folder / 'receipt.json'), 'process': process}
        self.recorder.emit('candidate_selection', 'selection', fields=result)
        if accepted:
            self.stack.append({'path': (folder / 'model.npz').relative_to(self.output).as_posix(), 'sha256': result['candidate_sha256']})
            self.score = score
        else:
            self.quarantined.append(result['candidate_sha256'])
        self.history.append(result)
        self.pending = None
        self._checkpoint('candidate_accepted' if accepted else 'candidate_rejected_continue_within_budget')

    def run(self):
        status, reason = 'completed', 'decision_budget_exhausted'
        try:
            try:
                while self.decision_rounds < self.max_decisions:
                    self._active()
                    if self.fit_attempts >= self.max_fits:
                        reason = 'training_budget_exhausted'
                        break
                    self.decision_rounds += 1
                    self._checkpoint('decision_round_reserved')
                    action, source = self._decision()
                    self.recorder.emit('decision', 'decision', fields={'action': action, 'source': source, 'round': self.decision_rounds})
                    if action['tool'] == 'finish':
                        reason = 'controller_finished'
                        break
                    self._train(action, source)
            except WorkerLaunchFailure:
                self.launch_failed = True
                self.recorder.emit('worker_launch_failed', 'training', fields={'fit_attempts': self.fit_attempts,
                    'reason': 'launch_or_supervision_failed', 'cleanup_confirmed': False, 'automatic_retry': False})
                status, reason = 'safe_ended', 'worker_launch_failed'
            except IntegrityError:
                status, reason = 'integrity_stop', 'integrity_check_failed'
            except OSError:
                # Disk/log failures are never routed to fixed rules or suppressed.
                raise
            except Exception:
                status, reason = 'safe_ended', 'unexpected_controller_host_error'
            self.locked = True
            self.pending = None
            active_usable = True
            try:
                self._active()
            except Exception:
                active_usable = False
                status, reason = 'integrity_stop', 'active_version_not_verified'
            self._checkpoint('session_ended')
            report = {'schema': 'official-decision-result-v3', 'status': status, 'reason': reason,
                      'fit_attempts': self.fit_attempts, 'provider_attempts': self.provider_attempts, 'decision_rounds': self.decision_rounds,
                      'final_version': self.stack[-1], 'active_usable': active_usable, 'selection': self.score,
                      'history': self.history, 'state': self._state(), 'actual_paid_calls_inferred': False,
                      'provider_outcomes': self.provider_outcomes, 'retry_requests': self.retry_requests,
                      'fallback_rounds': self.fallback_rounds, 'successful_actions': self.successful_actions,
                      'complete_learning_cycles_inferred': False, 'retain_run_even_if_incomplete': True,
                      'official_scoring_ready': False, 'review_received': False, 'resume_supported': False}
            write_json(self.output / 'result.json', report)
            self.recorder.emit('run_end', 'complete', fields={'status': status, 'reason': reason, 'active_usable': active_usable,
                'fit_attempts': self.fit_attempts, 'provider_attempts': self.provider_attempts, 'final_version': self.stack[-1],
                'result_sha256': sha(self.output / 'result.json')})
            write_json(self.output / 'EXTERNAL-TAIL.json', {'tail_sha256': self.recorder.previous, 'records': self.recorder.sequence,
                                                         'records_sha256': sha(self.output / 'records.jsonl')})
            return report
        finally:
            self.recorder.close()
