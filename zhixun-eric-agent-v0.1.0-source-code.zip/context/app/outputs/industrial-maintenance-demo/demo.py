"""Offline teaching experiment; synthetic data, no official competition results."""
from __future__ import annotations

import argparse
import csv
import json
import math
import random
import time
from dataclasses import asdict, dataclass, replace
from pathlib import Path

from decision_notes import describe_plan, write_decision_report


@dataclass(frozen=True)
class Sample:
    sample_id: str
    temperature: float
    vibration: float
    label: int


@dataclass(frozen=True)
class Model:
    weights: tuple[float, float]
    bias: float

    def predict(self, rows: list[Sample]) -> list[int]:
        return [int(self.weights[0] * r.temperature
                    + self.weights[1] * r.vibration + self.bias >= 0) for r in rows]


def make_data(count: int, offset: float, seed: int, prefix: str) -> list[Sample]:
    """Two normalized sensor features; offset simulates sensor calibration drift."""
    rng = random.Random(seed)
    rows = []
    for i in range(count):
        physical_a, physical_b = rng.gauss(0, 1), rng.gauss(0, 1)
        label = int(physical_a + .7 * physical_b + rng.gauss(0, .16) > 0)
        rows.append(Sample(f"{prefix}-{i}", physical_a + offset,
                           physical_b + .5 * offset, label))
    return rows


def fit(rows: list[Sample], epochs: int = 100) -> Model:
    """Fit logistic regression by gradient descent using training rows only."""
    w0, w1, bias = 0., 0., 0.
    for _ in range(epochs):
        g0 = g1 = gb = 0.
        for r in rows:
            z = max(-40., min(40., w0 * r.temperature + w1 * r.vibration + bias))
            error = 1 / (1 + math.exp(-z)) - r.label
            g0 += error * r.temperature
            g1 += error * r.vibration
            gb += error
        w0 -= .3 * (g0 / len(rows) + .002 * w0)
        w1 -= .3 * (g1 / len(rows) + .002 * w1)
        bias -= .3 * gb / len(rows)
    return Model((w0, w1), bias)


def accuracy(predictions: list[int], rows: list[Sample]) -> float:
    return sum(p == r.label for p, r in zip(predictions, rows)) / len(rows)


def score(model: Model, rows: list[Sample]) -> float:
    return accuracy(model.predict(rows), rows)


def run(seed: int = 20261106, attempt_budget: int = 4,
        candidate_training: str = "correct", deployment_policy: str = "validated") -> dict:
    if candidate_training not in {"correct", "flipped-labels"}:
        raise ValueError("Unknown candidate training condition")
    if deployment_policy not in {"validated", "unconditional"}:
        raise ValueError("Unknown deployment policy")
    start = time.perf_counter()
    initial_train = make_data(360, 0, seed, "initial-train")
    initial_validation = make_data(160, 0, seed + 1, "initial-validation")
    frozen = fit(initial_train)
    current, version = frozen, 0
    attempts = 0
    events, predictions, deployment_followups = [], [], []
    pending_followups = {}
    versions = [{"version": 0, "effective_from_batch": 1, **asdict(frozen)}]
    # Offset is known only to this synthetic generator; it is never a controller input.
    offsets = [0, 0, .95, .95, -1.05, -1.05, .7, .7]
    reference_mean = sum(r.temperature for r in initial_train) / len(initial_train)
    for batch, offset in enumerate(offsets, 1):
        rows = make_data(240, offset, seed + batch * 101, f"batch-{batch}")
        used_version, used_model = version, current
        # Predict before the simulated environment releases this batch's answers.
        fixed_predictions = frozen.predict(rows)
        adaptive_predictions = used_model.predict(rows)
        mean_shift = abs(sum(r.temperature for r in rows) / len(rows) - reference_mean)
        fixed_accuracy = accuracy(fixed_predictions, rows)
        adaptive_accuracy = accuracy(adaptive_predictions, rows)
        if batch in pending_followups:
            deployment = pending_followups.pop(batch)
            parent_accuracy = score(deployment["parent_model"], rows)
            deployment_followups.append({
                "decision_batch": deployment["decision_batch"], "evaluation_batch": batch,
                "deployed_version": deployment["deployed_version"],
                "parent_version": deployment["parent_version"],
                "deployed_accuracy": adaptive_accuracy, "parent_accuracy": parent_accuracy,
                "gain_percentage_points": (adaptive_accuracy-parent_accuracy)*100,
            })
        for r, fixed_p, adaptive_p in zip(rows, fixed_predictions, adaptive_predictions):
            predictions.append({"batch": batch, "used_version": used_version,
                                **asdict(r), "fixed_prediction": fixed_p,
                                "adaptive_prediction": adaptive_p})

        event = {"batch": batch, "used_version": used_version,
                 "fixed_accuracy": fixed_accuracy, "adaptive_accuracy": adaptive_accuracy,
                 "temperature_mean_shift": mean_shift, "attempt": None,
                 "action": "keep", "reason": "表现稳定，保留当前模型", "candidates": []}
        event["phases"] = ["predict", "release_answers", "observe_and_read_history"]
        event["reasoning"] = describe_plan(batch, version, adaptive_accuracy, mean_shift,
                                            events, attempts, attempt_budget, batch == len(offsets))
        event["phases"].append("hypothesis_and_plan")
        # Answers are now available. Trigger uses past/current released outcomes.
        if adaptive_accuracy < .88:
            if attempts >= attempt_budget:
                event.update(action="budget_stop", reason="维护次数预算已用完，保留当前模型")
            elif batch == len(offsets):
                event.update(reason="演示已结束，没有下一批，不再启动训练")
            else:
                attempts += 1
                event["attempt"] = attempts
                # Split only released samples; holdout rows never enter fit().
                shuffled = list(rows)
                random.Random(seed + batch * 17).shuffle(shuffled)
                train, validation = shuffled[:160], shuffled[160:]
                old_validation = score(used_model, validation)
                candidate_models = []
                for name, training in (("近期数据重训", train),
                                       ("近期数据加少量旧数据", train + initial_train[:40])):
                    candidate_start = time.perf_counter()
                    # Deliberate teaching fault: corrupt candidate training labels only.
                    # Validation answers and every stream batch remain unchanged.
                    training_input = ([replace(r, label=1-r.label) for r in training]
                                      if candidate_training == "flipped-labels" else training)
                    candidate = fit(training_input)
                    heldout_score = score(candidate, validation)
                    record = {"strategy": name, "training_ids": [r.sample_id for r in training],
                              "candidate_id": f"batch-{batch}-attempt-{attempts}-candidate-{len(candidate_models)+1}",
                              "training_label_condition": candidate_training,
                              "validation_ids": [r.sample_id for r in validation],
                              "old_validation_accuracy": old_validation,
                              "candidate_validation_accuracy": heldout_score,
                              "training_seconds": time.perf_counter() - candidate_start,
                              "model": asdict(candidate)}
                    event["candidates"].append(record)
                    candidate_models.append((heldout_score, candidate, name))
                event["phases"].extend(["train_candidates", "validate_candidates"])
                best_score, candidate, strategy = max(candidate_models, key=lambda item: item[0])
                # Teaching gates, not competition scoring thresholds.
                passed = best_score >= .88 and best_score - old_validation >= .04
                event["reasoning"]["comparison"] = {
                    "selected_strategy": strategy, "old_validation_accuracy": old_validation,
                    "tie_break": "equal_scores_keep_first_preset_strategy",
                    "candidate_validation_accuracy": best_score,
                    "gain_percentage_points": (best_score-old_validation)*100,
                    "passed_validation": passed,
                }
                if passed or deployment_policy == "unconditional":
                    version += 1
                    current = candidate
                    reason = (f"{strategy}通过验证，下一批启用" if passed else
                              "教学反例：忽略验证失败，仍强制下一批启用候选")
                    event.update(action="deploy_next_batch", reason=reason,
                                 validation_passed=passed)
                    versions.append({"version": version, "effective_from_batch": batch + 1,
                                     **asdict(current)})
                    pending_followups[batch+1] = {
                        "decision_batch": batch, "deployed_version": version,
                        "parent_version": used_version, "parent_model": used_model,
                    }
                else:
                    event.update(action="reject", reason="候选未达到验证门槛，保留当前模型")
        event["next_version"] = version
        event["phases"].append("decide")
        event["reasoning"]["conclusion"] = {
            "action": event["action"], "reason": event["reason"], "next_version": version,
            "attempts_after": attempts,
        }
        events.append(event)

    return {"kind": "synthetic_teaching_experiment", "seed": seed,
            "config": {"attempt_budget": attempt_budget, "trigger_accuracy": .88,
                       "candidate_training": candidate_training,
                       "deployment_policy": deployment_policy,
                       "minimum_candidate_accuracy": .88, "minimum_gain": .04,
                       "label_protocol": "predict, release answers, split, train, validate, deploy next batch"},
            "initial_validation_accuracy": score(frozen, initial_validation),
            "attempts": attempts, "trained_candidates": attempts * 2,
            "accepted_updates": version, "events": events, "versions": versions,
            "deployment_followups": deployment_followups,
            "predictions": predictions, "elapsed_seconds": time.perf_counter() - start}


def write_outputs(result: dict, output: Path) -> None:
    output.mkdir(parents=True, exist_ok=True)
    (output / "experiment.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    fields = ["batch", "used_version", "fixed_accuracy", "adaptive_accuracy",
              "temperature_mean_shift", "action", "next_version", "reason"]
    with (output / "batches.csv").open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(result["events"])
    predictions = result["predictions"]
    with (output / "predictions.csv").open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, list(predictions[0]))
        writer.writeheader()
        writer.writerows(predictions)
    events = result["events"]
    fixed = sum(e["fixed_accuracy"] for e in events) / len(events)
    adaptive = sum(e["adaptive_accuracy"] for e in events) / len(events)
    condition = ("正常训练" if result["config"]["candidate_training"] == "correct"
                 else "故意把候选训练答案反过来，制造不合格候选；验证答案保持正确")
    policy = ("通过验证才替换" if result["config"]["deployment_policy"] == "validated"
              else "教学反例：验证失败也强制替换，不适合实际系统")
    lines = ["# 工业模型维护教学实验", "",
             "这是教学模拟：用两个归一化的传感器读数判断设备正常或异常。数据和故障规则均为人工构造，不是官方工业数据。", "",
             f"实验条件：{condition}。替换策略：{policy}。", "",
             "固定模型始终为最初的V0；维护系统当前模型是该批实际使用的版本，可以是V0、V1、V2等。", "",
             f"本次固定模型平均正确率 **{fixed:.1%}**，维护系统当前模型平均正确率 **{adaptive:.1%}**。这是一个预设漂移场景的结果，不能代表正式比赛成绩或证明方法对各种数据都有效。", "",
             f"共处理 {len(events)} 批数据，维护尝试 {result['attempts']} 次，训练候选 {result['trained_candidates']} 个，接受更新 {result['accepted_updates']} 次。", "",
             "| 批次 | 维护系统本批用的版本 | 固定V0正确率 | 维护系统当前模型正确率 | 本批结束后的决定 |", "|---|---|---|---|---|"]
    for e in events:
        lines.append(f"| {e['batch']} | V{e['used_version']} | {e['fixed_accuracy']:.1%} | {e['adaptive_accuracy']:.1%} | {e['reason']} |")
    lines += ["", "## 候选验证与替换决定", "",
              "以下正确率来自当批留出的80条验证样本，不是下一批成绩。", "",
              "| 批次 | 选出的候选 | 旧模型验证正确率 | 候选验证正确率 | 决定 |",
              "|---|---|---|---|---|"]
    for e in events:
        if e["candidates"]:
            best = max(e["candidates"], key=lambda c: c["candidate_validation_accuracy"])
            lines.append(f"| {e['batch']} | {best['strategy']} | {best['old_validation_accuracy']:.1%} | "
                         f"{best['candidate_validation_accuracy']:.1%} | {e['reason']} |")
    lines += ["", "## 怎么读这个结果", "",
              "1. 固定模型一直使用最初训练的版本，作为对照。",
              "2. 维护系统当前模型先预测本批数据，之后才获得答案；表中的正确率不会被本批更新追溯修改。",
              "3. 表现低于教学阈值时，系统用本批一部分数据训练两个候选；另一部分数据只用于验证。",
              "4. 新旧模型用同一份留出数据比较。正常策略通过门槛才下一批启用；教学反例会故意忽略门槛。",
              "5. 温度均值变化只是风险提示，系统不把它直接当作正确率下降的证明。", "",
              "## 这次还没有做的部分", "",
              "尚未接入官方数据、SDK、规定大模型和SwanLab；尚未实现上线后的自动回滚。这里只有简单规则和本地记录。维护预算按次数限制，耗时单独记录，没有冒充正式成本公式。", "",
              "本演示每次验证仅使用80条样本，并从两个候选中选优，仍可能选错；单次验证通过不保证未来更好。正式版本还需要开发数据上的反复对照、稳健判断与回滚机制。", "",
              "## 你现在只要看懂", "",
              "挑出一次接受更新：当时为什么维护？新旧模型在验证集上分别表现如何？新版本从哪一批开始使用？后续表现是否改善？", "",
              "完整过程见 experiment.json；逐批汇总见 batches.csv；逐条预测见 predictions.csv。"]
    (output / "实验结果.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    write_decision_report(result, output)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=20261106)
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parent / "results")
    args = parser.parse_args()
    result = run(args.seed)
    write_outputs(result, args.output)
    print(f"Completed: {len(result['events'])} batches, {result['attempts']} attempts, "
          f"{result['accepted_updates']} accepted updates. Report: {args.output / '实验结果.md'}")


if __name__ == "__main__":
    main()
