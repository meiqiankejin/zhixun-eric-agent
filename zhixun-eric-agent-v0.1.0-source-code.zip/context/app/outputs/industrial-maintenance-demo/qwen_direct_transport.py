"""Real HTTPS to the already authorized provider; local opener, no global edits."""
import json
import urllib.request
import urllib.error
from qwen_client import NoRedirect, ConnectionFailure


def direct_post_json(endpoint, secret, payload, timeout):
    if endpoint != 'https://pytrio.com/api/openai/v1/chat/completions':
        raise ConnectionFailure('unexpected_direct_endpoint')
    request = urllib.request.Request(endpoint, data=json.dumps(payload, ensure_ascii=False).encode('utf-8'), method='POST',
        headers={'Content-Type': 'application/json', 'Authorization': 'Bearer ' + secret})
    try:
        # Per-request route choice, not a change to proxy environment, registry, TUN or DNS.
        opener = urllib.request.build_opener(NoRedirect(), urllib.request.ProxyHandler({}))
        with opener.open(request, timeout=timeout) as response:
            raw = response.read(1_048_577)
        if len(raw) > 1_048_576:
            raise ConnectionFailure('response_too_large')
        parsed = json.loads(raw)
        if not isinstance(parsed, dict):
            raise ConnectionFailure('invalid_provider_response')
        return parsed
    except urllib.error.HTTPError as exc:
        code = exc.code
        exc.close()
        raise ConnectionFailure(f'http_{code}') from None
    except (urllib.error.URLError, TimeoutError, OSError):
        raise ConnectionFailure('network_or_timeout') from None
    except (ValueError, UnicodeError):
        raise ConnectionFailure('invalid_provider_json') from None
