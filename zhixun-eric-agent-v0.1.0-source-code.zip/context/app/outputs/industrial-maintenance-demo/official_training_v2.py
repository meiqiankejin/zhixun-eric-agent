"""Restricted configurable continuation, separate from sealed phase1 v1."""
from dataclasses import dataclass, asdict
from pathlib import Path
import hashlib
import json
import math
import shutil
import sys
import numpy as np
from official_model_adapter import sha, module_from, state_fingerprint, write_json
from training_supervisor import run_process


class IntegrityError(ValueError):
    pass


class CandidateFailure(RuntimeError):
    pass


@dataclass(frozen=True)
class Recipe:
    learning_rate: float
    batch_size: int
    epochs: int

    def __post_init__(self):
        if (isinstance(self.learning_rate, bool) or not isinstance(self.learning_rate, (int, float))
                or not math.isfinite(self.learning_rate) or not 0 < self.learning_rate <= 1):
            raise ValueError('invalid_learning_rate')
        if type(self.batch_size) is not int or not 1 <= self.batch_size <= 65536:
            raise ValueError('invalid_batch_size')
        if type(self.epochs) is not int or not 1 <= self.epochs <= 100:
            raise ValueError('invalid_epochs')

    @classmethod
    def from_dict(cls, value):
        if not isinstance(value, dict) or set(value) != {'learning_rate', 'batch_size', 'epochs'}:
            raise ValueError('invalid_recipe_fields')
        return cls(**value)

    def dictionary(self):
        return asdict(self)


def strict_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError('duplicate_json_key')
            result[key] = value
        return result
    def reject(_):
        raise ValueError('nonfinite_json')
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=reject)


def encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def recipe_key(parent_hash, training_hash, recipe):
    return hashlib.sha256(encoded({'parent': parent_hash, 'training': training_hash, 'recipe': recipe.dictionary()})).hexdigest()


def array_fingerprint(x, y):
    h = hashlib.sha256()
    for name, array in (('x', x), ('y', y)):
        h.update((name + str(array.dtype) + str(array.shape)).encode())
        h.update(array.tobytes())
    return h.hexdigest()


def expected_meta(parent_meta, recipe, rows):
    result = dict(parent_meta)
    result.update(learning_rate=recipe.learning_rate, batch_size=recipe.batch_size)
    result['epochs'] += recipe.epochs
    result['steps'] += recipe.epochs * math.ceil(rows / recipe.batch_size)
    return result


def check_child(parent, child, recipe, rows):
    if child.meta != expected_meta(parent.meta, recipe, rows):
        raise IntegrityError('child_metadata_mismatch')
    for name in ('mean', 'scale'):
        before, after = getattr(parent, name), getattr(child, name)
        if before.dtype != after.dtype or before.tobytes() != after.tobytes():
            raise IntegrityError('normalization_changed')
    if state_fingerprint(parent, True) == state_fingerprint(child, True):
        raise IntegrityError('optimizer_not_updated')
    child.validate()


def prepare(folder, model_source, expected_source_hash, parent_path, expected_parent_hash, x, y, recipe):
    if sha(model_source) != expected_source_hash or sha(parent_path) != expected_parent_hash:
        raise IntegrityError('source_or_parent_changed')
    folder = Path(folder)
    folder.mkdir(exist_ok=False)
    shutil.copyfile(model_source, folder / 'model.py')
    shutil.copyfile(parent_path, folder / 'parent.npz')
    np.savez(folder / 'train.npz', x=x, y=y)
    request = {'schema': 'official-fit-request-v2', 'model_source_sha256': expected_source_hash,
               'parent_sha256': expected_parent_hash, 'train_arrays_sha256': sha(folder / 'train.npz'),
               'rows': len(y), 'recipe': recipe.dictionary()}
    write_json(folder / 'request.json', request)
    return request


def launch(folder, timeout=60):
    worker = Path(__file__).with_name('official_fit_worker_v2.py')
    result = run_process([str(Path(sys.executable).resolve()), '-I', '-B', str(worker), str(Path(folder).resolve())],
                         str(Path(folder).resolve()), timeout, memory_mb=1024)
    write_json(Path(folder) / 'attempt.json', result)
    if result['status'] in {'timeout', 'worker_failed'}:
        failure_path = Path(folder) / 'failure.json'
        if failure_path.is_file():
            failure = strict_json(failure_path.read_text(encoding='utf-8'))
            if failure.get('kind') == 'integrity':
                raise IntegrityError('worker_integrity_failure')
        raise CandidateFailure(result['status'])
    if result['status'] != 'completed':
        raise IntegrityError('worker_cleanup_not_confirmed')
    return result


def verify(folder, request, parent, Model):
    folder = Path(folder)
    if strict_json((folder / 'request.json').read_text(encoding='utf-8')) != request:
        raise IntegrityError('request_changed')
    for name, key in (('model.py', 'model_source_sha256'), ('parent.npz', 'parent_sha256'), ('train.npz', 'train_arrays_sha256')):
        if sha(folder / name) != request[key]:
            raise IntegrityError('worker_input_changed')
    receipt = strict_json((folder / 'receipt.json').read_text(encoding='utf-8'))
    recipe = Recipe.from_dict(request['recipe'])
    child = Model.load(folder / 'model.npz')
    start_meta = dict(parent.meta)
    start_meta.update(learning_rate=recipe.learning_rate, batch_size=recipe.batch_size)
    if (receipt.get('schema') != 'official-fit-receipt-v2' or receipt['request_sha256'] != sha(folder / 'request.json')
            or receipt['parent_sha256'] != request['parent_sha256'] or receipt['child_sha256'] != sha(folder / 'model.npz')
            or receipt['train_arrays_sha256'] != request['train_arrays_sha256']
            or receipt['inherited_state_sha256'] != state_fingerprint(parent)
            or receipt['inherited_optimizer_sha256'] != state_fingerprint(parent, True)
            or receipt['configured_optimizer_sha256'] != state_fingerprint(parent, True)
            or receipt['inherited_metadata'] != parent.meta or receipt['configured_metadata'] != start_meta
            or receipt['final_metadata'] != child.meta or receipt['validation_read'] is not False
            or len(receipt['train_losses']) != recipe.epochs or not all(math.isfinite(v) for v in receipt['train_losses'])):
        raise IntegrityError('worker_receipt_mismatch')
    check_child(parent, child, recipe, request['rows'])
    return child, receipt
