"""Evidence-based notes for the teaching controller's fixed rules, not an LLM."""
from pathlib import Path


def describe_plan(batch, version, accuracy, mean_shift, history, attempts, budget, last_batch):
    """Called before candidate training; accepts only observed/current/past facts."""
    needs_attention = accuracy < .88
    can_experiment = needs_attention and attempts < budget and not last_batch
    if not needs_attention:
        hypothesis = "当前正确率未低于教学触发线，暂不提出新的维护实验。"
    elif mean_shift >= .35:
        hypothesis = ("近期传感器读数分布与初始数据不同，旧模型可能不适合近期工况。"
                      "这是待检验的解释，均值变化本身不能证明原因。")
    else:
        hypothesis = ("正确率下降，但仅凭温度均值不能解释；可能存在其他分布变化或抽样波动。"
                      "先用近期已公开数据做有限实验，不把猜测当作确定原因。")
    if can_experiment:
        plan = [
            {"strategy": "近期数据重训", "purpose": "尝试适应近期数据的规律"},
            {"strategy": "近期数据加少量旧数据", "purpose": "尝试兼顾近期变化与初始工况"},
        ]
        next_action = "比较两个预设训练方案；当前批160条训练、80条留出验证。"
    else:
        plan = []
        if not needs_attention:
            next_action = "表现达到教学触发线，保留当前模型，继续监测。"
        elif attempts >= budget:
            next_action = "预算已用完，停止新训练；这不代表模型已经恢复。"
        else:
            next_action = "没有下一批数据，不再启动训练。"
    return {
        "source": "fixed_rule_controller",
        "observations": {"batch": batch, "used_version": version,
                         "current_accuracy": accuracy, "temperature_mean_shift": mean_shift},
        "history_batches": [e["batch"] for e in history],
        "recent_history": [{"batch": e["batch"], "accuracy": e["adaptive_accuracy"],
                            "action": e["action"]} for e in history[-3:]],
        "hypothesis": hypothesis,
        "hypothesis_is_proven": False,
        "planned_candidates": plan,
        "plan": next_action,
        "budget_before": {"used_attempts": attempts, "maximum_attempts": budget},
        "validation_rule": {"minimum_accuracy": .88, "minimum_gain": .04,
                            "effective_from": "next_batch"},
        "strategy_learning_enabled": False,
    }


def write_decision_report(result, output: Path):
    events = result["events"]
    example = next((e for e in events if e["candidates"]), events[0])
    notes = example["reasoning"]
    lines = ["# 第三步：系统为什么这样决定", "",
             "这次把原来程序实际执行的固定规则写成可核对的决策记录。没有接大模型；下面的解释由程序按已观察到的指标生成，不是模型自由思考，也不是事后编造一段理由。", "",
             "同样是教学模拟数据，88%、4个百分点和样本数量都不是比赛规定。正式数据批次与评测时序仍需按官方SDK实现。", "",
             f"## 看第{example['batch']}批的一次实际决定", "",
             f"**1. 当前在用谁：** V{example['used_version']}。固定对照一直是V0。", "",
             f"**2. 看到了什么：** 本批先预测，答案公布后算出当前模型正确率{example['adaptive_accuracy']:.1%}。"
             f"温度读数均值与初始数据的绝对差为{example['temperature_mean_shift']:.3f}（归一化读数）。", "",
             f"**3. 读了哪些历史：** 第{', '.join(str(b) for b in notes['history_batches']) or '无'}批已完成记录。"
             "当前版本仅把历史保存并展示，实验方案仍然是预设的；还没有根据经验学习策略。", "",
             f"**4. 提出了什么猜测：** {notes['hypothesis']}", "",
             f"**5. 准备怎样试：** {notes['plan']}", "",
             "候选训练前已经写下观察、假设和计划；候选训练不使用验证样本。训练出错的对照实验也不会提前把故障注入信息告诉诊断规则。", "",
             "| 方案 | 为什么尝试 | 训练样本数 | 留出样本数 | 旧模型验证正确率 | 候选验证正确率 |",
             "|---|---|---:|---:|---:|---:|"]
    purposes = {p["strategy"]: p["purpose"] for p in notes["planned_candidates"]}
    for c in example["candidates"]:
        lines.append(f"| {c['strategy']} | {purposes[c['strategy']]} | {len(c['training_ids'])} | "
                     f"{len(c['validation_ids'])} | {c['old_validation_accuracy']:.1%} | "
                     f"{c['candidate_validation_accuracy']:.1%} |")
    lines += ["", "注意：前面的本批正确率用全部240条预测计算；表里的验证正确率只看留出的80条。"
              "两者数据范围不同，数值可以不同；比较候选时，新旧模型必须看同一份80条数据。", "",
              "两个候选验证分相同时，这个教学程序按预设顺序选择第一个；尚未比较它们的旧工况保持能力，"
              "也没有证明所选方案的资源消耗最优。"]
    lines += ["", "**6. 按什么标准决定：** 在同一份留出数据上，候选正确率至少88%，且比旧模型提高至少4个百分点；"
              "默认策略满足后才允许替换。一次维护尝试最多训练两个候选，次数预算控制整个实验。这里还没有把耗时作为上线门槛。", "",
              f"**7. 实际决定：** {example['reason']}。本批用V{example['used_version']}，"
              f"下一批计划用V{example['next_version']}。", ""]
    followup = next((f for f in result["deployment_followups"] if f["decision_batch"] == example["batch"]), None)
    if followup:
        lines += [f"**8. 下一批再检查：** 第{followup['evaluation_batch']}批，新版V{followup['deployed_version']}"
                  f"正确率{followup['deployed_accuracy']:.1%}；同一批数据上，被替换的V{followup['parent_version']}"
                  f"为{followup['parent_accuracy']:.1%}，相差{followup['gain_percentage_points']:+.1f}个百分点。", "",
                  "这条反馈在下一批答案公开后才生成，单独保存；不会倒过来改变上一批的假设、计划或决定。"]
    else:
        lines += ["**8. 后续检查：** 本次没有对应的已部署版本下一批反馈；不把未发生的效果写成结果。"]
    lines += ["", "## 全部批次的决定都有记录", "",
              "| 批次 | 当前模型 | 当前正确率 | 尝试前已用预算 | 决定 | 下一批版本 |", "|---|---|---:|---:|---|---|"]
    for e in events:
        lines.append(f"| {e['batch']} | V{e['used_version']} | {e['adaptive_accuracy']:.1%} | "
                     f"{e['reasoning']['budget_before']['used_attempts']} | {e['reason']} | V{e['next_version']} |")
    lines += ["", "## 这一步完成了什么", "",
              "记录了观察、历史、待检验假设、预设方案、真实训练与验证结果、上线或保留决定、下一批的实际反馈。"
              "机器可读记录在experiment.json中，按reasoning、phases和deployment_followups查看。", "",
              "## 还没有完成什么", "",
              "尚未接入官方平台与大模型，尚未实现策略随历史经验改变、自动回滚或正式SwanLab记录。"
              "读历史和写解释不等于策略自改进；下一阶段要用公平对照验证策略是否确实利用经验变好。", "",
              "这次只需看懂：为什么训练这个候选？拿什么证据决定换或不换？换完以后有没有在后续数据上检查？"]
    (output / "决策过程.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
