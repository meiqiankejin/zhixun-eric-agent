"""Set resource bounds before exec; only used on POSIX."""
import os
import resource
import sys

if __name__=='__main__':
    memory=int(sys.argv[1]);resource.setrlimit(resource.RLIMIT_AS,(memory,memory))
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    os.execve(sys.argv[2],sys.argv[2:],os.environ)
