"""Small adapter: proposal-phase finish and typed feedback, frozen v2 unchanged."""
from copy import deepcopy
import json
from official_code_controller_v2 import Controller, Actions, SYSTEM as BASE_SYSTEM
from official_training_v2 import strict_json
from official_model_adapter import write_json
from qwen_client import ConnectionFailure

SYSTEM = BASE_SYSTEM + '提案阶段也可用finish、空arguments并给reason保留当前模型结束；结果决定阶段不能finish。'


class FinishRequested(Exception):
    pass


class FinishActions(Actions):
    def parse(self, raw):
        if type(raw) is str and len(raw) <= 8192:
            action = strict_json(raw)
            if (type(action) is dict and set(action) == {'tool', 'arguments', 'reason'}
                    and action['tool'] == 'finish' and action['arguments'] == {}
                    and type(action['reason']) is str and 1 <= len(action['reason'].strip()) <= 500):
                return action
        return super().parse(raw)

    def tools(self, phase):
        tools = super().tools(phase)
        if phase == 'proposal':
            tools.append({'name': 'finish', 'description': 'Keep selected model and finish before another experiment.',
                          'parameters': {'type': 'object', 'properties': {}, 'required': [], 'additionalProperties': False}})
        return tools


class CodeController(Controller):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.actions = FinishActions(self.engine.recipes)
        self.proposal_rounds = 0

    def _request(self, phase, view, default):
        e = self.engine
        self.proposal_rounds += int(phase == 'proposal')
        expected = 'propose_experiment' if phase == 'proposal' else 'decide_candidate'
        for ordinal in (1, 2):
            if self.calls >= self.maximum:
                break
            self.calls += 1
            self.retries += int(ordinal == 2)
            request_id = e.recorder.emit('provider_call_reserved', 'controller', fields={
                'phase': phase, 'phase_request': ordinal, 'provider_attempt': self.calls})
            actual_view = {**view, 'feedback': deepcopy(self.feedback),
                          'remaining_provider_calls_after_request': self.maximum - self.calls,
                          'remaining_requests_in_phase_after_request': 2 - ordinal}
            e.recorder.emit('controller_input', 'controller', fields={'request_id': request_id, 'view': actual_view})
            try:
                raw = self.client.respond([{'role': 'system', 'content': SYSTEM},
                    {'role': 'user', 'content': json.dumps(actual_view, ensure_ascii=False)}], self.actions.tools(phase))
                action = self.actions.parse(raw)
                if action['tool'] != expected and not (phase == 'proposal' and action['tool'] == 'finish'):
                    raise ValueError('wrong_phase')
                args = action['arguments']
                if action['tool'] == 'propose_experiment':
                    if {k: args[k] for k in ('template', 'weight_power', 'recipe')} not in view['untried_options']:
                        raise ValueError('duplicate_or_stale_configuration')
                elif action['tool'] == 'decide_candidate':
                    if args['result_id'] != view['result']['result_id'] or (args['decision'] == 'accept' and not view['result']['eligible']):
                        raise ValueError('result_or_quality_mismatch')
            except (ValueError, ConnectionFailure) as exc:
                known = {'wrong_phase', 'duplicate_or_stale_configuration', 'result_or_quality_mismatch'}
                if isinstance(exc, ValueError) or str(exc) == 'invalid_remote_action':
                    code = str(exc) if str(exc) in known else 'invalid_action'
                elif str(exc) == 'network_or_timeout':
                    code = 'network_or_timeout'
                else:
                    code = 'provider_failed'
                item = {'phase': phase, 'request_id': request_id, 'provider_attempt': self.calls,
                        'reason_code': code, 'phase_request': ordinal}
                self.feedback.append(item)
                self.outcomes.append({**item, 'status': 'rejected'})
                e.recorder.emit('controller_feedback', 'controller', fields=item)
                continue
            evidence = {'phase': phase, 'request_id': request_id, 'provider_attempt': self.calls,
                        'source': self.live_source, 'action': action}
            event = e.recorder.emit('controller_action', 'controller', fields=evidence)
            self.outcomes.append({**evidence, 'status': 'ok', 'action_event': event})
            if action['tool'] == 'finish':
                e.recorder.emit('controller_finished', 'controller', fields={'request_id': request_id,
                    'action_event': event, 'source': self.live_source, 'fit_attempts': e.attempts})
                raise FinishRequested()
            return action, {'source': self.live_source, 'request_id': request_id, 'action_event': event}
        self.takeovers += 1
        event = e.recorder.emit('rule_takeover', 'controller', fields={'phase': phase, 'scope': 'current_decision_phase',
            'reason': 'phase_limit_or_provider_budget', 'action': default})
        return default, {'source': 'fixed_rule_fallback', 'action_event': event, 'request_id': None}

    def _ended(self, status, reason):
        e = self.engine
        e.recorder.emit('unified_controller_ended', 'controller', fields={'status': status, 'reason_code': reason})
        e.recorder.emit('provider_usage', 'controller', fields={'records': self.client.records,
            'provider_attempts_reserved': self.calls, 'actually_sent_requests': self.client.calls})
        core = e.close()
        report = {'schema': 'unified-code-controller-v1', 'status': status, 'reason': reason, 'engine': core,
                  'provider_calls_reserved': self.calls, 'requests_sent': self.client.calls, 'retries': self.retries,
                  'fallback_phases': self.takeovers, 'controller_cycles': self.completed,
                  'provider_outcomes': self.outcomes, 'fully_live_cycles': sum(c['both_phases_qwen_live'] for c in self.completed),
                  'proposal_rounds': self.proposal_rounds,
                  'formal_requirement_satisfied': False, 'sdk_connected': False, 'platform_runs': 0,
                  'real_provider': self.live_source == 'qwen_live'}
        write_json(e.output / 'controller-result.json', report)
        return report

    def run(self):
        try:
            report = super().run()
            report['proposal_rounds'] = self.proposal_rounds
            # Keep the frozen base report untouched; this is the adapter receipt.
            write_json(self.engine.output / 'unified-controller-result.json', report)
            return report
        except FinishRequested:
            return self._ended('finished', 'controller_finished')
        except OSError:
            # Keep I/O failures visible; no automatic retry or success receipt.
            raise
        except Exception:
            if self.engine.closed:
                raise
            if self.engine.pending is not None:
                self.engine._stop('unexpected_controller_host_error')
                return self._ended('integrity_stop', 'unexpected_controller_host_error')
            return self._ended('safe_ended', 'unexpected_controller_host_error')
