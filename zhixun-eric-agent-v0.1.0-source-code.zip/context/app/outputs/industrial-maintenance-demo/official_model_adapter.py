"""Official NumPy MLP adapter. No legacy Ridge/Gas weights or data are imported."""
from pathlib import Path
import hashlib
import importlib.util
import json
import math
import numpy as np


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    path = Path(path)
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        import os
        os.fsync(stream.fileno())


def module_from(path, expected):
    path = Path(path).resolve()
    if sha(path) != expected:
        raise ValueError('official_source_changed')
    spec = importlib.util.spec_from_file_location('official_' + path.stem + '_' + expected, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def metrics(model, x, y):
    prediction = model.predict(x)
    if model.meta['task'] == 'classification':
        labels = prediction.argmax(axis=1)
        matrix = np.zeros((len(model.meta['classes']), len(model.meta['classes'])), dtype=np.int64)
        np.add.at(matrix, (y, labels), 1)
        denom = matrix.sum(axis=0) + matrix.sum(axis=1)
        f1 = np.divide(2 * np.diag(matrix), denom, out=np.zeros(len(matrix)), where=denom > 0)
        result = {'accuracy': float(np.mean(labels == y)), 'macro_f1': float(f1.mean()),
                  'correct': int(np.sum(labels == y)), 'confusion_matrix': matrix.tolist(),
                  'classes': model.meta['classes'], 'rows': len(y)}
    else:
        error = prediction - y
        result = {'rmse': float(np.sqrt(np.mean(error ** 2))), 'mae': float(np.mean(np.abs(error))), 'rows': len(y)}
    if not all(math.isfinite(result[k]) for k in ('accuracy', 'macro_f1') if k in result):
        raise ValueError('nonfinite_metrics')
    if not all(math.isfinite(result[k]) for k in ('rmse', 'mae') if k in result):
        raise ValueError('nonfinite_metrics')
    return result, prediction


def state_fingerprint(model, optimizer_only=False):
    digest = hashlib.sha256()
    groups = [('first', model.first), ('second', model.second)]
    if not optimizer_only:
        groups += [('params', model.params), ('scaler', {'mean': model.mean, 'scale': model.scale})]
        digest.update(json.dumps(model.meta, sort_keys=True, separators=(',', ':')).encode())
    for group, values in groups:
        for name, value in sorted(values.items()):
            digest.update((group + '/' + name + '/' + str(value.shape) + '/' + str(value.dtype)).encode())
            digest.update(value.tobytes())
    return digest.hexdigest()


def check_child(parent, child, epochs, rows):
    expected = dict(parent.meta)
    expected['epochs'] += epochs
    expected['steps'] += epochs * math.ceil(rows / expected['batch_size'])
    if child.meta != expected:
        raise ValueError('child_metadata_continuity_failed')
    for name in ('mean', 'scale'):
        before, after = getattr(parent, name), getattr(child, name)
        if before.dtype != after.dtype or before.tobytes() != after.tobytes():
            raise ValueError('child_normalization_changed')
    if state_fingerprint(child, True) == state_fingerprint(parent, True):
        raise ValueError('optimizer_not_updated')
    child.validate()


def improves(primary, before, after, tolerance=1e-12):
    if not all(math.isfinite(float(v[primary])) for v in (before, after)):
        raise ValueError('invalid_selection_metric')
    gain = after[primary] - before[primary] if primary == 'macro_f1' else before[primary] - after[primary]
    return gain > tolerance
