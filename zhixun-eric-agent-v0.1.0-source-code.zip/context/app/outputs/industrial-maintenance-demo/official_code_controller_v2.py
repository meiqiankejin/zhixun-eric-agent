"""Two decision phases per experiment; <=2 requests/phase, local fallback.

Host bundles read-history/read-source and execution tools, rather than charging
one provider request per tool. Provider provenance is separate from host linkage.
"""
from copy import deepcopy
import ast
import hashlib
import json
from pathlib import Path
import shutil
from official_code_tools_v2 import (CodeToolsV2, approved_edits, apply_checked_patch, digest, POWERS)
from official_training_v2 import Recipe, strict_json
from official_model_adapter import sha, write_json
from qwen_client import QwenClient, ConnectionFailure

SYSTEM = ('你是受限工业分类训练代码实验控制器。只返回reason、tool、arguments的JSON。'
          'propose_experiment选择weighted_ce模板、weight_power、白名单recipe，hypothesis简述可检验假设；'
          '代码和差异由宿主生成，不用逐字复制代码。动作空间只有3个已审核补丁乘以白名单训练配方。'
          'decide_candidate必须准确引用宿主result_id，根据本次真实结果接受或拒绝；不合格候选只能拒绝。'
          '宿主已读取历史与源码提供给你；以这些实际结果为依据，不编造功能或成绩。'
          '这是有限预算的接口验证，不是隐藏测试或单个气体类别的专项优化，不称自改进已有效。')


class Actions:
    def __init__(self, recipes):
        self.recipes = tuple(recipes)

    def parse(self, raw):
        if type(raw) is not str or len(raw) > 8192:
            raise ValueError('invalid_action_size')
        a = strict_json(raw)
        if type(a) is not dict or set(a) != {'reason', 'tool', 'arguments'}:
            raise ValueError('invalid_action')
        if type(a['reason']) is not str or not 1 <= len(a['reason'].strip()) <= 500:
            raise ValueError('reason_required')
        args = a['arguments']
        if type(args) is not dict:
            raise ValueError('invalid_arguments')
        if a['tool'] == 'propose_experiment':
            if set(args) != {'template', 'weight_power', 'recipe', 'hypothesis'} or args['template'] != 'weighted_ce':
                raise ValueError('invalid_template')
            approved_edits(args['weight_power'])
            if Recipe.from_dict(args['recipe']) not in self.recipes:
                raise ValueError('recipe_not_allowed')
            if type(args['hypothesis']) is not str or not 1 <= len(args['hypothesis'].strip()) <= 500:
                raise ValueError('hypothesis_required')
        elif a['tool'] == 'decide_candidate':
            if (set(args) != {'result_id', 'decision'} or type(args['result_id']) is not str
                    or len(args['result_id']) != 64 or args['decision'] not in {'accept', 'reject'}):
                raise ValueError('invalid_decision')
        else:
            raise ValueError('unknown_tool')
        return a

    def tools(self, phase):
        name = 'propose_experiment' if phase == 'proposal' else 'decide_candidate'
        properties = ({'template': {'type': 'string', 'enum': ['weighted_ce']},
                       'weight_power': {'type': 'number', 'enum': list(POWERS)},
                       'recipe': {'type': 'object', 'description': 'Exactly one allowed recipe shown in context'},
                       'hypothesis': {'type': 'string'}} if phase == 'proposal' else
                      {'result_id': {'type': 'string'}, 'decision': {'type': 'string', 'enum': ['accept', 'reject']}})
        return [{'name': name, 'description': 'One bounded code experiment proposal' if phase == 'proposal' else 'Decision after seeing measured result',
                 'parameters': {'type': 'object', 'properties': properties, 'required': list(properties), 'additionalProperties': False}}]


class Controller:
    def __init__(self, engine, client, *, allow_live=False, max_provider_calls=12, experiments=3, first_nonzero=False):
        if type(engine) is not CodeToolsV2 or type(client) is not QwenClient or client.protocol != 'json_actions' or client.calls != 0:
            raise ValueError('unsupported_engine_or_client')
        if not client._transport_is_injected and not allow_live:
            raise ValueError('live_not_authorized')
        if (type(max_provider_calls) is not int or max_provider_calls < 1 or client.max_calls < max_provider_calls
                or type(experiments) is not int or not 1 <= experiments <= engine.max_fits or type(first_nonzero) is not bool):
            raise ValueError('invalid_controller_budget')
        self.engine, self.client = engine, client
        self.maximum, self.experiments = max_provider_calls, experiments
        self.first_nonzero = first_nonzero
        self.calls, self.retries, self.takeovers = 0, 0, 0
        self.feedback, self.completed, self.outcomes = [], [], []
        self.actions = Actions(engine.recipes)
        self.live_source = 'qwen_protocol_injected' if client._transport_is_injected else 'qwen_live'
        engine.recorder.emit('controller_bound', 'control', fields={'source': self.live_source,
            'max_provider_calls': max_provider_calls, 'experiments': experiments, 'phases_per_experiment': 2,
            'max_requests_per_decision_phase': 2, 'fallback_scope': 'current_decision_phase',
            'first_nonzero_for_mechanism_coverage': first_nonzero,
            'tools_bundled_by_host': True, 'finish_or_official_round_equivalence': 'not implemented/claimed'})

    def _options(self):
        e = self.engine
        options = []
        for power in POWERS:
            if self.first_nonzero and not self.completed and power == 0:
                continue
            text = apply_checked_patch(e.original, approved_edits(power), power)
            source_sha = hashlib.sha256(text.encode('utf-8')).hexdigest()
            for recipe in e.recipes:
                key = digest({'parent': e.active['sha256'], 'source': source_sha, 'recipe': recipe.dictionary()})
                if key not in e.tried:
                    options.append({'template': 'weighted_ce', 'weight_power': power, 'recipe': recipe.dictionary()})
        return options

    def _request(self, phase, view, default):
        e = self.engine
        expected = 'propose_experiment' if phase == 'proposal' else 'decide_candidate'
        for ordinal in (1, 2):
            if self.calls >= self.maximum:
                break
            self.calls += 1
            self.retries += int(ordinal == 2)
            request_id = e.recorder.emit('provider_call_reserved', 'controller', fields={
                'phase': phase, 'phase_request': ordinal, 'provider_attempt': self.calls})
            actual_view = {**view, 'feedback': deepcopy(self.feedback),
                           'remaining_provider_calls_after_request': self.maximum - self.calls,
                           'remaining_requests_in_phase_after_request': 2 - ordinal}
            e.recorder.emit('controller_input', 'controller', fields={'request_id': request_id, 'view': actual_view})
            try:
                raw = self.client.respond([{'role': 'system', 'content': SYSTEM},
                    {'role': 'user', 'content': json.dumps(actual_view, ensure_ascii=False)}], self.actions.tools(phase))
                action = self.actions.parse(raw)
                if action['tool'] != expected:
                    raise ValueError('wrong_phase')
                args = action['arguments']
                if phase == 'proposal':
                    option = {k: args[k] for k in ('template', 'weight_power', 'recipe')}
                    if option not in view['untried_options']:
                        raise ValueError('duplicate_or_stale_configuration')
                elif args['result_id'] != view['result']['result_id'] or (args['decision'] == 'accept' and not view['result']['eligible']):
                    raise ValueError('result_or_quality_mismatch')
            except (ValueError, ConnectionFailure) as exc:
                code = str(exc) if str(exc) in {'wrong_phase', 'duplicate_or_stale_configuration', 'result_or_quality_mismatch'} else 'provider_or_action_failed'
                item = {'phase': phase, 'request_id': request_id, 'provider_attempt': self.calls,
                        'reason_code': code, 'phase_request': ordinal}
                self.feedback.append(item)
                self.outcomes.append({**item, 'status': 'rejected'})
                e.recorder.emit('controller_feedback', 'controller', fields=item)
                continue
            evidence = {'phase': phase, 'request_id': request_id, 'provider_attempt': self.calls,
                        'source': self.live_source, 'action': action}
            action_event = e.recorder.emit('controller_action', 'controller', fields=evidence)
            self.outcomes.append({**evidence, 'status': 'ok', 'action_event': action_event})
            return action, {'source': self.live_source, 'request_id': request_id, 'action_event': action_event}
        self.takeovers += 1
        event = e.recorder.emit('rule_takeover', 'controller', fields={'phase': phase, 'scope': 'current_decision_phase',
                                'reason': 'phase_limit_or_provider_budget', 'action': default})
        return default, {'source': 'fixed_rule_fallback', 'action_event': event, 'request_id': None}

    @staticmethod
    def _score(score):
        return {k: score[k] for k in ('macro_f1', 'accuracy', 'rows') if k in score}

    def run(self):
        e = self.engine
        status = 'completed'
        for _ in range(self.experiments):
            history, source = e.invoke('read_history', {}), e.invoke('read_source', {})
            if not history['ok'] or not source['ok']:
                status = 'integrity_stop' if e.terminal_reason else 'safe_ended'
                break
            h, s = history['value'], source['value']
            options = self._options()
            if not options:
                status = 'no_untried_options'
                break
            fit = next(n for n in ast.walk(ast.parse(s['text'])) if isinstance(n, ast.FunctionDef) and n.name == 'fit')
            history_view = deepcopy(h['history'])
            for cycle in history_view:
                if cycle['selection'] is not None:
                    cycle['selection'] = self._score(cycle['selection'])
            view = {'phase': 'proposal', 'history_receipt': h['receipt'], 'history': history_view,
                    'source_receipt': s['receipt'], 'source_path': s['path'], 'base_sha256': s['base_sha256'],
                    'fit_source': ast.get_source_segment(s['text'], fit), 'selection': self._score(e.score),
                    'untried_options': options, 'minimum_gain': e.minimum_gain,
                    'remaining_fits': e.max_fits - e.attempts,
                    'template_semantics': 'weighted cross entropy, train-only class frequencies, average sample weight=1; source diff saved by host'}
            default = {'reason': 'fixed next untried option after provider failure', 'tool': 'propose_experiment',
                       'arguments': {**options[0], 'hypothesis': 'fixed fallback integration proposal'}}
            proposal, proposal_evidence = self._request('proposal', view, default)
            args = proposal['arguments']
            patch = e.invoke('write_patch', {'template': args['template'], 'weight_power': args['weight_power'],
                'hypothesis': args['hypothesis'], 'source_receipt': s['receipt'], 'history_receipt': h['receipt']})
            if not patch['ok']:
                status = 'integrity_stop' if patch['terminal'] else 'safe_ended'
                break
            measured = e.invoke('train_candidate', {'patch_id': patch['value']['patch_id'], 'recipe': args['recipe']})
            if not measured['ok']:
                status = 'integrity_stop' if measured['terminal'] else 'safe_ended'
                break
            result = measured['value']
            result_view = {k: result[k] for k in ('experiment_id', 'result_id', 'status', 'eligible')}
            for k in ('selection_before', 'selection'):
                if k in result:
                    result_view[k] = self._score(result[k])
            for k in ('gain', 'minimum_gain', 'reason'):
                if k in result:
                    result_view[k] = result[k]
            default = {'reason': 'host eligibility fallback after provider failure', 'tool': 'decide_candidate',
                       'arguments': {'result_id': result['result_id'], 'decision': 'accept' if result['eligible'] else 'reject'}}
            decision, decision_evidence = self._request('decision', {'phase': 'decision', 'result': result_view,
                'history_receipt': h['receipt'], 'proposal': proposal['arguments']}, default)
            decided = e.invoke('decide', {**decision['arguments'], 'reason': decision['reason']})
            if not decided['ok']:
                status = 'integrity_stop' if decided['terminal'] else 'safe_ended'
                break
            linked = {'cycle_id': decided['value']['cycle_id'], 'experiment_id': result['experiment_id'],
                      'result_id': result['result_id'], 'proposal': proposal_evidence, 'decision': decision_evidence,
                      'both_phases_qwen_live': proposal_evidence['source'] == decision_evidence['source'] == 'qwen_live'}
            self.completed.append(linked)
            e.recorder.emit('controller_cycle_evidence', 'controller', fields=linked)
            print(json.dumps({'cycle': linked['cycle_id'], 'source': proposal_evidence['source'],
                              'power': args['weight_power'], 'status': result['status'],
                              'gain': result.get('gain'), 'decision': decision['arguments']['decision']}, ensure_ascii=False), flush=True)
        # Provider records never include raw private reasoning or credentials.
        e.recorder.emit('provider_usage', 'controller', fields={'records': self.client.records,
            'provider_attempts_reserved': self.calls, 'actually_sent_requests': self.client.calls})
        core = e.close()
        summary = {'schema': 'code-controller-v2', 'status': status, 'engine': core,
                   'provider_calls_reserved': self.calls, 'requests_sent': self.client.calls,
                   'retries': self.retries, 'fallback_phases': self.takeovers,
                   'controller_cycles': self.completed, 'provider_outcomes': self.outcomes,
                   'fully_live_cycles': sum(c['both_phases_qwen_live'] for c in self.completed),
                   'formal_requirement_satisfied': False, 'sdk_connected': False,
                   'platform_runs': 0, 'real_provider': self.live_source == 'qwen_live'}
        write_json(e.output / 'controller-result.json', summary)
        return summary
