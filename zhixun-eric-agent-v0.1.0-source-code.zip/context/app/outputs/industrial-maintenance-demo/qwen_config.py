"""Local credential form and Windows user-scoped DPAPI storage; never makes API calls."""
from __future__ import annotations

import base64
import ctypes
import json
import os
import re
from pathlib import Path
from urllib.parse import urlsplit

DEFAULT_URL = "https://pytrio.com/api/openai/v1"
DEFAULT_MODEL = "Qwen/Qwen3.8-27B"


def config_path() -> Path:
    return Path(os.environ["LOCALAPPDATA"]) / "IndustrialMaintenanceDemo" / "qwen-config.json"


def validate_endpoint(url: str) -> str:
    url = url.strip().rstrip("/")
    parsed = urlsplit(url)
    host = parsed.hostname or ""
    pytrio = host == "pytrio.com" and parsed.path == "/api/openai/v1"
    bailian = (host == "dashscope.aliyuncs.com" or re.fullmatch(
        r"[a-z0-9-]+\.cn-beijing\.maas\.aliyuncs\.com", host)) and parsed.path == "/compatible-mode/v1"
    if (not (pytrio or bailian) or parsed.scheme != "https" or parsed.port not in (None, 443)
            or parsed.username or parsed.password or parsed.query or parsed.fragment):
        raise ValueError("请使用已核对的 PyTRiO 或百炼官方 HTTPS 接口地址。")
    return url


def validate_model(model: str) -> str:
    if not isinstance(model, str) or not re.fullmatch(r"(?:Qwen/)?[Qq]wen[a-zA-Z0-9_.-]{1,100}", model):
        raise ValueError("请填写服务模型列表中的完整千问模型名称。")
    return model


def provider_for_endpoint(base_url: str) -> str:
    return "pytrio" if urlsplit(validate_endpoint(base_url)).hostname == "pytrio.com" else "aliyun-bailian-beijing"


def validate_credential_provider(key: str, base_url: str) -> None:
    prefix = "trio_" if provider_for_endpoint(base_url) == "pytrio" else "sk-"
    if not key.startswith(prefix):
        raise ValueError("密钥与服务平台不匹配：PyTRiO 使用 trio_ 密钥，百炼使用其自己的密钥。")


def dpapi(data: bytes, *, decrypt: bool = False) -> bytes:
    if os.name != "nt":
        raise RuntimeError("Windows credential storage is required")
    from ctypes import wintypes

    class Blob(ctypes.Structure):
        _fields_ = [("size", wintypes.DWORD), ("data", ctypes.POINTER(ctypes.c_ubyte))]

    crypt = ctypes.WinDLL("crypt32", use_last_error=True)
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    pointer = ctypes.POINTER(Blob)
    protect = crypt.CryptProtectData
    protect.argtypes = [pointer, wintypes.LPCWSTR, pointer, ctypes.c_void_p,
                        ctypes.c_void_p, wintypes.DWORD, pointer]
    protect.restype = wintypes.BOOL
    unprotect = crypt.CryptUnprotectData
    unprotect.argtypes = [pointer, ctypes.c_void_p, pointer, ctypes.c_void_p,
                          ctypes.c_void_p, wintypes.DWORD, pointer]
    unprotect.restype = wintypes.BOOL
    kernel.LocalFree.argtypes = [ctypes.c_void_p]
    kernel.LocalFree.restype = ctypes.c_void_p
    buffer = (ctypes.c_ubyte * len(data)).from_buffer_copy(data)
    incoming = Blob(len(data), buffer)
    outgoing = Blob()
    function = unprotect if decrypt else protect
    try:
        if not function(ctypes.byref(incoming), None, None, None, None, 1, ctypes.byref(outgoing)):
            raise RuntimeError("Windows credential encryption/decryption failed")
        return ctypes.string_at(outgoing.data, outgoing.size)
    finally:
        ctypes.memset(buffer, 0, len(data))
        if outgoing.data:
            ctypes.memset(outgoing.data, 0, outgoing.size)
            kernel.LocalFree(outgoing.data)


def save_config(key: str, model: str, base_url: str, path: Path | None = None) -> None:
    if not re.fullmatch(r"[A-Za-z0-9_.-]{12,512}", key):
        raise ValueError("请填写完整 API Key，不要加入引号、换行或空格。")
    model = validate_model(model.strip())
    base_url = validate_endpoint(base_url)
    validate_credential_provider(key, base_url)
    payload = {"schema": 1, "provider": provider_for_endpoint(base_url), "model": model,
               "base_url": base_url,
               "api_key_dpapi": base64.b64encode(dpapi(key.encode())).decode("ascii")}
    path = path or config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".pending.json")
    temporary.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    temporary.replace(path)


def load_config(path: Path | None = None) -> dict:
    payload = json.loads((path or config_path()).read_text(encoding="utf-8"))
    if payload.get("schema") != 1:
        raise ValueError("Unknown local config schema")
    model = validate_model(payload["model"])
    url = validate_endpoint(payload["base_url"])
    key = dpapi(base64.b64decode(payload["api_key_dpapi"], validate=True), decrypt=True).decode()
    if not re.fullmatch(r"[A-Za-z0-9_.-]{12,512}", key):
        raise ValueError("Invalid locally stored credential")
    return {"model": model, "base_url": url, "api_key": key}


def show_form():
    import tkinter as tk
    from tkinter import messagebox, ttk

    root = tk.Tk()
    root.title("工业模型维护实验 · 填写千问 API")
    root.geometry("700x340")
    root.resizable(False, False)
    frame = ttk.Frame(root, padding=22)
    frame.pack(fill="both", expand=True)
    ttk.Label(frame, text="赛题指定 PyTRiO 平台 · 密钥只在本机填写，不用发到聊天中").grid(
        row=0, column=0, columnspan=2, sticky="w", pady=(0, 18))
    key, model, url = tk.StringVar(), tk.StringVar(value=DEFAULT_MODEL), tk.StringVar(value=DEFAULT_URL)
    if config_path().exists():
        try:
            public = json.loads(config_path().read_text(encoding="utf-8"))
            model.set(public["model"])
            url.set(public["base_url"])
        except (OSError, ValueError, KeyError):
            pass
    fields = [("API Key", key, True), ("模型名称", model, False), ("连接地址", url, False)]
    first = None
    for row, (label, value, secret) in enumerate(fields, 1):
        ttk.Label(frame, text=label, width=12).grid(row=row, column=0, sticky="w", pady=8)
        entry = ttk.Entry(frame, textvariable=value, width=66, show="●" if secret else "")
        entry.grid(row=row, column=1, sticky="ew", pady=8)
        if first is None:
            first = entry
    ttk.Label(frame, text="保存只做本地加密，不调用 API、不扣费。PyTRiO 的密钥以 trio_ 开头。\n"
              "模型名称请使用平台模型列表中的完整 ID，不要与百炼地址混用。").grid(
        row=4, column=0, columnspan=2, sticky="w", pady=(15, 12))
    status = tk.StringVar()
    ttk.Label(frame, textvariable=status, foreground="#a32020").grid(row=6, column=0, columnspan=2, sticky="w")

    def save():
        try:
            save_config(key.get().strip(), model.get(), url.get())
        except ValueError as exc:
            status.set(str(exc) if "Key" not in str(exc) else "请检查密钥是否完整，勿加入引号或空格。")
            return
        except Exception:
            status.set("保存失败，未显示任何密钥内容。请回到聊天告诉我此提示。")
            return
        key.set("")
        messagebox.showinfo("保存完成", "已加密保存。请回到聊天告诉我“填好了”，然后做一次小额连接测试。", parent=root)
        root.destroy()

    def close():
        key.set("")
        root.destroy()

    buttons = ttk.Frame(frame)
    buttons.grid(row=5, column=0, columnspan=2, sticky="e", pady=(0, 10))
    ttk.Button(buttons, text="取消", command=close).pack(side="right", padx=(12, 0))
    ttk.Button(buttons, text="保存到本机", command=save).pack(side="right")
    root.protocol("WM_DELETE_WINDOW", close)
    root.bind("<Return>", lambda _: save())
    first.focus_set()
    root.lift()
    root.attributes("-topmost", True)
    root.after(1200, lambda: root.attributes("-topmost", False))
    root.mainloop()


if __name__ == "__main__":
    show_form()
