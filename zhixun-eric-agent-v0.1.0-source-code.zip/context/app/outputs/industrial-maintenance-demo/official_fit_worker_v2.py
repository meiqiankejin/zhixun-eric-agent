"""Train-only configurable worker. No validation, Qwen, credentials or API client."""
from pathlib import Path
import sys
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import time
import numpy as np
from official_training_v2 import Recipe, strict_json, check_child, IntegrityError
from official_model_adapter import sha, module_from, state_fingerprint, write_json


def execute(folder):
    folder = Path(folder).resolve()
    request = strict_json((folder / 'request.json').read_text(encoding='utf-8'))
    if set(request) != {'schema', 'model_source_sha256', 'parent_sha256', 'train_arrays_sha256', 'rows', 'recipe'} or request['schema'] != 'official-fit-request-v2':
        raise IntegrityError('invalid_request')
    recipe = Recipe.from_dict(request['recipe'])
    for name, key in (('model.py', 'model_source_sha256'), ('parent.npz', 'parent_sha256'), ('train.npz', 'train_arrays_sha256')):
        if sha(folder / name) != request[key]:
            raise IntegrityError('worker_input_changed')
    Model = module_from(folder / 'model.py', request['model_source_sha256']).Model
    parent = Model.load(folder / 'parent.npz')
    initial_state, initial_optimizer = state_fingerprint(parent), state_fingerprint(parent, True)
    inherited_meta = dict(parent.meta)
    # Same continuation semantics as official train.py; never reset weights/Adam.
    parent.meta['learning_rate'] = recipe.learning_rate
    parent.meta['batch_size'] = recipe.batch_size
    parent.validate()
    configured_meta, configured_optimizer = dict(parent.meta), state_fingerprint(parent, True)
    with np.load(folder / 'train.npz', allow_pickle=False) as data:
        if set(data.files) != {'x', 'y'}:
            raise IntegrityError('train_only_required')
        x, y = data['x'].copy(), data['y'].copy()
    if type(request['rows']) is not int or len(x) != request['rows'] or y.shape != (len(x),) or not np.isfinite(x).all() or not np.isfinite(y).all():
        raise IntegrityError('invalid_train_arrays')
    start = time.perf_counter()
    losses = parent.fit(x, y, recipe.epochs)
    child = parent
    check_child(Model.load(folder / 'parent.npz'), child, recipe, len(y))
    child.save(folder / 'model.npz')
    result = {'schema': 'official-fit-receipt-v2', 'request_sha256': sha(folder / 'request.json'),
              'parent_sha256': request['parent_sha256'], 'train_arrays_sha256': request['train_arrays_sha256'],
              'child_sha256': sha(folder / 'model.npz'), 'inherited_state_sha256': initial_state,
              'inherited_optimizer_sha256': initial_optimizer, 'configured_optimizer_sha256': configured_optimizer,
              'inherited_metadata': inherited_meta, 'configured_metadata': configured_meta, 'final_metadata': child.meta,
              'train_losses': losses, 'fit_seconds': time.perf_counter() - start, 'validation_read': False,
              'python': sys.version.split()[0], 'numpy': np.__version__}
    write_json(folder / 'receipt.json', result)
    return result


if __name__ == '__main__':
    try:
        execute(sys.argv[1])
    except BaseException as exc:
        try:
            write_json(Path(sys.argv[1]) / 'failure.json', {'schema': 'official-worker-failure-v2',
                'kind': 'integrity' if isinstance(exc, (IntegrityError, OSError)) else 'training', 'reason': type(exc).__name__})
        except Exception:
            pass
        raise SystemExit(1)
