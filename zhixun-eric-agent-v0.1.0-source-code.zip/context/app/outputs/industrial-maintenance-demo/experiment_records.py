"""Local experiment recorder; cloud backend contract only, no network implementation."""
from datetime import datetime,timezone
from pathlib import Path
from typing import Protocol
import hashlib
import json
import os
import re
from numbers import Integral,Real


def json_ready(value):
    """Normalize integer class labels and numeric scalars, rejecting ambiguous keys."""
    if isinstance(value,dict):
        out={}
        for k,v in value.items():
            if not isinstance(k,(str,Integral)):raise ValueError('invalid_field_key')
            key=str(k)
            if key in out:raise ValueError('ambiguous_field_key')
            out[key]=json_ready(v)
        return out
    if isinstance(value,(tuple,list)):return [json_ready(v) for v in value]
    if isinstance(value,(str,bool)) or value is None:return value
    if isinstance(value,Integral):return int(value)
    if isinstance(value,Real):return float(value)
    raise ValueError('non_json_value')


def canonical(value):
    return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(",",":"),allow_nan=False).encode("utf-8")


def validate_public(value):
    if isinstance(value,dict):
        for k,v in value.items():
            if not isinstance(k,str) or k.casefold() in {"api_key","apikey","password","authorization","secret","access_token","credential"}:
                raise ValueError("private_or_invalid_field")
            validate_public(v)
    elif isinstance(value,(tuple,list)):
        for v in value:validate_public(v)
    elif isinstance(value,str) and re.search(r"(?:trio_[A-Za-z0-9]{20,}|sk-[A-Za-z0-9_-]{24,})",value):
        raise ValueError("possible_private_value")


def public_failure(exc,stage):
    """Allowlisted reasons only; never put raw exception messages into the stream."""
    known={'private_or_invalid_field','possible_private_value','invalid_field_key','ambiguous_field_key','non_json_value'}
    message=str(exc)
    reason=message if message in known else 'invariant_check_failed' if isinstance(exc,AssertionError) else 'operation_failed'
    return {'error_type':type(exc).__name__[:64],'reason_code':reason,'stage':stage}


class Backend(Protocol):
    def append(self,record:dict)->None: ...


class LocalBackend:
    def __init__(self,path):
        self.path=Path(path)
        self.path.parent.mkdir(parents=True,exist_ok=True)
        self.file=self.path.open("x",encoding="utf-8")
    def append(self,record):
        self.file.write(canonical(record).decode("utf-8")+"\n")
        self.file.flush()
        os.fsync(self.file.fileno())
    def close(self):self.file.close()


class Recorder:
    def __init__(self,study_id,backend):
        self.study_id,self.backend=study_id,backend
        self.sequence,self.previous,self.closed=0,"0"*64,False
    def emit(self,event,phase,*,seed=None,recipe=None,batch=None,fields=None):
        if self.closed:raise ValueError("recorder_closed")
        record={"schema":"industrial-local-record-v1","study_id":self.study_id,"sequence":self.sequence+1,
                "timestamp_utc":datetime.now(timezone.utc).isoformat(),"event":event,"phase":phase,
                "seed":seed,"recipe":recipe,"batch":batch,"fields":json_ready(fields or {}),"previous_sha256":self.previous}
        validate_public(record)
        digest=hashlib.sha256(canonical(record)).hexdigest()
        record["record_sha256"]=digest
        self.backend.append(record)
        self.sequence+=1;self.previous=digest
        return digest
    def close(self):
        self.closed=True
        close=getattr(self.backend,"close",None)
        if close:close()


def verify_records(path):
    records=[];previous="0"*64
    with Path(path).open(encoding="utf-8") as f:
        for sequence,line in enumerate(f,1):
            record=json.loads(line);digest=record.pop("record_sha256")
            assert record["sequence"]==sequence and record["previous_sha256"]==previous
            validate_public(record)
            assert hashlib.sha256(canonical(record)).hexdigest()==digest
            record["record_sha256"]=digest;records.append(record);previous=digest
    assert records and records[0]["event"]=="run_start" and records[-1]["event"]=="run_end"
    return records
