"""Provider-checked Qwen adapter. HTTPS only, bounded calls, no automatic retries."""
from __future__ import annotations

import argparse
import json
import re
import time
import urllib.error
import urllib.request
from copy import deepcopy
from pathlib import Path

from maintenance_harness import SYSTEM, Limits, TOOLS, parse_request, run, write_outputs
from qwen_config import (load_config, provider_for_endpoint, validate_credential_provider,
                         validate_endpoint, validate_model)

REMOTE_SYSTEM = (
    "你是工业模型维护决策端。每次只调用一个提供的函数，使用工具参数reason简述本次操作依据。"
    "不输出内部思维过程，不用自然语言代替工具调用。完成本批时调用finish。"
    "先读当前观测；需要维护时先read_history和inspect_data，再决定实验。"
    "所有实验成绩只信任工具返回；训练后先evaluate_candidate，通过后才能request_deployment。"
    "没有改善证据就finish保留。可检查上一版本是否适合恢复。"
    "收到切换申请批准后应finish，版本从下一批生效。"
    "没有下一批时直接finish。遵守训练和调用预算，不读取未来数据。"
    "数据与阈值是教学模拟，不代表正式比赛要求。"
)


class ConnectionFailure(RuntimeError):
    """Contains only a fixed diagnostic code, never provider response bodies or keys."""

    def __init__(self, code, provider_code=None):
        super().__init__(code)
        self.provider_code = provider_code


def unique_arguments(pairs):
    result = {}
    for name, value in pairs:
        if name in result:
            raise ValueError("Duplicate argument")
        result[name] = value
    return result


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, message, headers, new_url):
        return None


def post_json(endpoint: str, secret: str, payload: dict, timeout: int, *, proxy_url: str | None = None) -> dict:
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    request = urllib.request.Request(endpoint, data=body, method="POST", headers={
        "Content-Type": "application/json", "Authorization": "Bearer " + secret})
    try:
        # Use the existing network configuration; never follow a redirect carrying credentials.
        handlers = [NoRedirect()]
        if proxy_url is not None:
            handlers.append(urllib.request.ProxyHandler({"http": proxy_url, "https": proxy_url}))
        with urllib.request.build_opener(*handlers).open(request, timeout=timeout) as response:
            raw = response.read(1_048_577)
        if len(raw) > 1_048_576:
            raise ConnectionFailure("response_too_large")
        parsed = json.loads(raw)
        if not isinstance(parsed, dict):
            raise ConnectionFailure("invalid_provider_response")
        return parsed
    except urllib.error.HTTPError as exc:
        code = int(exc.code)
        provider_code = None
        try:
            error_body = json.loads(exc.read(8192))
            detail = error_body.get("error", error_body)
            candidate_code = detail.get("code") if isinstance(detail, dict) else None
            if (isinstance(candidate_code, str) and re.fullmatch(r"[A-Za-z][A-Za-z0-9_.-]{0,79}", candidate_code)
                    and secret not in candidate_code and "sk-" not in candidate_code):
                provider_code = candidate_code
        except (ValueError, TypeError, AttributeError):
            pass
        finally:
            exc.close()
        raise ConnectionFailure(f"http_{code}", provider_code) from None
    except (urllib.error.URLError, TimeoutError, OSError):
        raise ConnectionFailure("network_or_timeout") from None
    except (ValueError, UnicodeError):
        raise ConnectionFailure("invalid_provider_json") from None


class QwenClient:
    source = "qwen_service_live"
    is_remote = True

    def __init__(self, *, api_key: str, base_url: str, model: str,
                 max_calls: int = 12, max_output_tokens: int = 512,
                 max_input_bytes: int = 60_000, timeout: int = 30, transport=None,
                 protocol: str | None = None, task_system: str | None = None,
                 action_validator=None):
        self._api_key = api_key
        self.base_url = validate_endpoint(base_url)
        self.model = validate_model(model)
        self.provider = provider_for_endpoint(self.base_url)
        validate_credential_provider(api_key, self.base_url)
        self.source = f"qwen_{self.provider}_live"
        self.protocol = protocol or ("json_actions" if self.provider == "pytrio" else "native_tools")
        if self.protocol not in {"json_actions", "native_tools"}:
            raise ValueError("Unknown action protocol")
        if (task_system is None) != (action_validator is None):
            raise ValueError("Custom task requires both system and action validator")
        if task_system is not None and (self.protocol != "json_actions" or not isinstance(task_system, str)
                                        or not task_system.strip() or len(task_system) > 12000
                                        or not callable(action_validator)):
            raise ValueError("Custom task currently requires a valid JSON-actions configuration")
        self._task_system = task_system if task_system is not None else SYSTEM
        self._action_validator = action_validator or (lambda raw: parse_request(raw, Limits()))
        if not api_key or any(c.isspace() for c in api_key):
            raise ValueError("Invalid API credential")
        if any(type(v) is not int or v <= 0 for v in
               (max_calls, max_output_tokens, max_input_bytes, timeout)):
            raise ValueError("Invalid remote limits")
        self.max_calls, self.max_output_tokens = max_calls, max_output_tokens
        self.max_input_bytes, self.timeout = max_input_bytes, timeout
        self._transport = transport or post_json
        self._transport_is_injected = transport is not None
        self.calls = 0
        self.connected = False
        self.last_error = None
        self.records = []
        self._wire = []
        self._expected_prefix = []
        self._pending = None

    def __repr__(self):
        return f"QwenClient(model={self.model!r}, credential=<private>)"

    def _fail(self, code):
        self.last_error = code
        raise ConnectionFailure(code)

    def respond(self, messages: list[dict], tools: list[dict]) -> str:
        if self.calls >= self.max_calls:
            self._fail("remote_call_budget_exhausted")
        if self.protocol == "json_actions":
            # Use only the chat fields documented by PyTRIO; do not assume native tool parsing.
            self._wire = [{"role": "system", "content": self._task_system + "可用工具："
                           + json.dumps(tools, ensure_ascii=False)}]
            for message in messages[1:]:
                if message["role"] == "tool":
                    self._wire.append({"role": "user", "content": "宿主程序的工具执行结果："
                                       + message["name"] + "\n" + message["content"]})
                else:
                    self._wire.append(deepcopy(message))
        elif len(messages) == 2:
            self._wire = [{"role": "system", "content": REMOTE_SYSTEM}, deepcopy(messages[1])]
            self._pending = None
        else:
            if (self._pending is None or len(messages) != len(self._expected_prefix) + 2
                    or messages[:-2] != self._expected_prefix
                    or messages[-2] != {"role": "assistant", "content": self._pending["internal"]}
                    or messages[-1].get("role") != "tool"
                    or messages[-1].get("name") != self._pending["name"]):
                self._fail("conversation_mismatch")
            self._wire.append({"role": "tool", "tool_call_id": self._pending["id"],
                               "content": messages[-1]["content"]})
        wire_tools = []
        for tool in tools:
            definition = deepcopy(tool)
            definition["parameters"]["properties"]["reason"] = {
                "type": "string", "description": "本次操作的简短依据，最多1000字。"}
            definition["parameters"]["required"].append("reason")
            wire_tools.append({"type": "function", "function": definition})
        payload = {"model": self.model, "messages": deepcopy(self._wire), "temperature": 0,
                   "max_tokens": self.max_output_tokens, "stream": False}
        if self.protocol == "native_tools":
            payload.update(tools=wire_tools, tool_choice="auto", parallel_tool_calls=False, enable_thinking=False)
        if len(json.dumps(payload, ensure_ascii=False).encode("utf-8")) > self.max_input_bytes:
            self._fail("remote_input_budget_exhausted")
        self.calls += 1  # Every sent request counts, including failed requests.
        started = time.perf_counter()
        record = {"call": self.calls, "model_requested": self.model,
                  "status": "failed", "usage": None}
        self.records.append(record)
        try:
            response = self._transport(self.base_url + "/chat/completions", self._api_key,
                                       payload, self.timeout)
        except ConnectionFailure as exc:
            code = str(exc)
            record["provider_error_code"] = exc.provider_code
            allowed = {"network_or_timeout", "invalid_provider_json", "response_too_large", "invalid_provider_response"}
            self._fail(code if code in allowed or (code.startswith("http_") and code[5:].isdigit())
                       else "transport_failed")
        except Exception:
            self._fail("transport_failed")
        finally:
            record["seconds"] = time.perf_counter() - started
            record["error"] = self.last_error
        self.connected = True
        usage = response.get("usage")
        if isinstance(usage, dict):
            record["usage"] = {name: usage[name] for name in ("prompt_tokens", "completion_tokens", "total_tokens")
                               if type(usage.get(name)) is int and usage[name] >= 0}
        provider_model = response.get("model")
        if isinstance(provider_model, str) and len(provider_model) <= 150 and self._api_key not in provider_model:
            record["model_returned"] = provider_model
        try:
            choice = response["choices"][0]
            assistant = choice["message"]
            # Keep only bounded metadata, never response text or private reasoning.
            if choice.get("finish_reason") in {"stop", "length", "tool_calls", "content_filter", None}:
                record["finish_reason"] = choice.get("finish_reason")
            if isinstance(assistant.get("content"), str):
                record["content_chars"] = len(assistant["content"])
            if isinstance(assistant.get("reasoning_content"), str):
                record["reasoning_chars"] = len(assistant["reasoning_content"])
            if choice.get("finish_reason") == "length":
                self._fail("output_truncated")
            if self.protocol == "json_actions":
                content = assistant.get("content")
                if not isinstance(content, str):
                    self._fail("expected_json_action_text")
                internal = content.strip().replace(self._api_key, "[private]")
                action = self._action_validator(internal)
                if action["tool"] not in [t["name"] for t in tools]:
                    self._fail("unknown_remote_tool")
                record["status"], record["error"] = "ok", None
                self.last_error = None
                return internal
            calls = assistant.get("tool_calls")
            if not isinstance(calls, list) or len(calls) != 1:
                self._fail("expected_exactly_one_tool_call")
            call = calls[0]
            if call.get("type") != "function" or not isinstance(call.get("id"), str) or not call["id"]:
                self._fail("invalid_tool_call_id")
            name = call["function"]["name"]
            if name not in [t["name"] for t in tools]:
                self._fail("unknown_remote_tool")
            args = json.loads(call["function"]["arguments"], object_pairs_hook=unique_arguments)
            if not isinstance(args, dict):
                self._fail("invalid_remote_arguments")
            reason = args.pop("reason", "")
            if not isinstance(reason, str):
                self._fail("invalid_remote_reason")
            internal = json.dumps({"reason": reason.replace(self._api_key, "[private]"),
                                   "tool": name, "arguments": args}, ensure_ascii=False)
            # Same strict checks as the host; the host additionally enforces experiment budgets/gates.
            parse_request(internal, Limits())
            # Preserve the native assistant message, including ids, for the following tool result.
            self._wire.append(deepcopy(assistant))
            self._expected_prefix = deepcopy(messages)
            self._pending = {"id": call["id"], "name": name, "internal": internal}
            record["status"] = "ok"
            record["error"] = None
            self.last_error = None
            return internal
        except ConnectionFailure:
            record["error"] = self.last_error
            raise
        except (KeyError, IndexError, TypeError, ValueError):
            record["error"] = "invalid_remote_action"
            self._fail("invalid_remote_action")

    def diagnostics(self):
        return {"model": self.model, "calls": self.calls, "connected": self.connected,
                "provider": self.provider, "protocol": self.protocol,
                "system_instruction": self._task_system if self.protocol == "json_actions" else REMOTE_SYSTEM,
                "network_transport": "injected" if self._transport_is_injected else "https",
                "max_calls": self.max_calls, "max_output_tokens": self.max_output_tokens,
                "max_input_bytes": self.max_input_bytes, "timeout_seconds": self.timeout,
                "automatic_retries": 0, "last_error": self.last_error,
                "requests": deepcopy(self.records)}


def smoke_test(client: QwenClient) -> dict:
    messages = [{"role": "system", "content": "connection check"},
                {"role": "user", "content": "这是一次连接测试。请只调用finish工具，reason简写连接成功。不训练、不读取数据。"}]
    ok = False
    try:
        action = parse_request(client.respond(messages, [t for t in TOOLS if t["name"] == "finish"]), Limits())
        ok = action["tool"] == "finish"
    except ConnectionFailure:
        pass
    return {"kind": "live_connection_check", "ok": ok,
            "industrial_maintenance_tested": False, **client.diagnostics()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--demo", action="store_true", help="Explicitly run the paid eight-batch teaching experiment")
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parent / "qwen-results")
    args = parser.parse_args()
    try:
        config = load_config()
        client = QwenClient(**config, max_calls=40 if args.demo else 1)
    except Exception:
        print(json.dumps({"ok": False, "error": "local_configuration_missing_or_invalid"}))
        return 2
    args.output.mkdir(parents=True, exist_ok=True)
    if args.demo:
        result = run(client=client)
        write_outputs(result, args.output)
        print(json.dumps({"connected": client.connected, "calls": client.calls,
                          "accepted_updates": result["accepted_updates"],
                          "failed_batches": sum(e["failure"] is not None for e in result["events"])}))
        return 0 if all(e["failure"] is None for e in result["events"]) else 1
    result = smoke_test(client)
    (args.output / "connection-check.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False))
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
