"""Trusted fit process lifetime bounds, not a sandbox for arbitrary hostile code.

Windows: suspended launch, job assignment before first instruction, aggregate commit
limit and kill-on-close. POSIX: new session, group kill, inherited RLIMIT_AS.
No captured pipes; descendants cannot hold a parent's communicate() open.
"""
from pathlib import Path
from time import perf_counter,sleep
import math
import os
import signal
import subprocess
import sys

CLEANUP_SECONDS=1.
ENVIRONMENT={'SYSTEMROOT','WINDIR','TEMP','TMP','TMPDIR','LANG','LC_ALL'}


def worker_environment():
    env={k:v for k,v in os.environ.items() if k.upper() in ENVIRONMENT}
    # No host PATH, PYTHONPATH, home, proxy or credentials. Commands are absolute.
    env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',
               PYTHONIOENCODING='utf-8',PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1')
    return env


def run_process(command,cwd,timeout,memory_mb=1024):
    if not isinstance(timeout,(int,float)) or not math.isfinite(timeout) or timeout<=0:raise ValueError('invalid_timeout')
    if type(memory_mb) is not int or memory_mb<32:raise ValueError('invalid_memory_limit')
    if not command or not Path(command[0]).is_absolute():raise ValueError('absolute_executable_required')
    start=perf_counter()
    result=(_windows if os.name=='nt' else _posix)(list(map(str,command)),str(cwd),timeout,memory_mb,worker_environment())
    result.update(elapsed_seconds=perf_counter()-start,memory_limit_mb=memory_mb,
                  environment_policy='minimal_no_credentials',output_policy='discard_no_pipes',cleanup_budget_seconds=CLEANUP_SECONDS)
    return result


def _posix(command,cwd,timeout,memory_mb,env):
    launcher=Path(__file__).with_name('training_posix_launch.py')
    process=subprocess.Popen([sys.executable,'-I',str(launcher),str(memory_mb*1024*1024),*command],cwd=cwd,env=env,
        stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
    try:
        process.wait(timeout=timeout);status='completed' if process.returncode==0 else 'worker_failed'
    except subprocess.TimeoutExpired:status='timeout'
    finally:
        # Also kill descendants left behind after an otherwise successful parent.
        try:os.killpg(process.pid,signal.SIGKILL)
        except ProcessLookupError:pass
        try:process.wait(timeout=CLEANUP_SECONDS)
        except subprocess.TimeoutExpired:status='cleanup_failed'
    return {'status':status,'returncode':process.returncode,'pid':process.pid,'process_reaped':process.poll() is not None,
            'tree_termination_requested':True,'containment':'posix_session','memory_scope':'per_process_address_space'}


def _windows(command,cwd,timeout,memory_mb,env):
    import ctypes as c
    from ctypes import wintypes as w
    import msvcrt
    kernel=c.WinDLL('kernel32',use_last_error=True)
    SIZE_T=c.c_size_t
    class Startup(c.Structure):
        _fields_=[('cb',w.DWORD),('lpReserved',w.LPWSTR),('lpDesktop',w.LPWSTR),('lpTitle',w.LPWSTR),
          ('dwX',w.DWORD),('dwY',w.DWORD),('dwXSize',w.DWORD),('dwYSize',w.DWORD),('dwXCountChars',w.DWORD),
          ('dwYCountChars',w.DWORD),('dwFillAttribute',w.DWORD),('dwFlags',w.DWORD),('wShowWindow',w.WORD),
          ('cbReserved2',w.WORD),('lpReserved2',c.POINTER(w.BYTE)),('hStdInput',w.HANDLE),('hStdOutput',w.HANDLE),('hStdError',w.HANDLE)]
    class Process(c.Structure):_fields_=[('process',w.HANDLE),('thread',w.HANDLE),('pid',w.DWORD),('tid',w.DWORD)]
    class BasicLimit(c.Structure):
        _fields_=[('per_process',c.c_int64),('per_job',c.c_int64),('flags',w.DWORD),('min_ws',SIZE_T),('max_ws',SIZE_T),
                  ('active_limit',w.DWORD),('affinity',SIZE_T),('priority',w.DWORD),('scheduling',w.DWORD)]
    class IO(c.Structure):_fields_=[(n,c.c_uint64) for n in ('read_ops','write_ops','other_ops','read_bytes','write_bytes','other_bytes')]
    class ExtendedLimit(c.Structure):
        _fields_=[('basic',BasicLimit),('io',IO),('process_memory',SIZE_T),('job_memory',SIZE_T),('peak_process',SIZE_T),('peak_job',SIZE_T)]
    class Accounting(c.Structure):
        _fields_=[('user',c.c_int64),('kernel',c.c_int64),('period_user',c.c_int64),('period_kernel',c.c_int64),
                  ('page_faults',w.DWORD),('total',w.DWORD),('active',w.DWORD),('terminated',w.DWORD)]
    signatures={
      'CreateJobObjectW':([c.c_void_p,w.LPCWSTR],w.HANDLE),
      'SetInformationJobObject':([w.HANDLE,c.c_int,c.c_void_p,w.DWORD],w.BOOL),
      'AssignProcessToJobObject':([w.HANDLE,w.HANDLE],w.BOOL),
      'CreateProcessW':([w.LPCWSTR,w.LPWSTR,c.c_void_p,c.c_void_p,w.BOOL,w.DWORD,c.c_void_p,w.LPCWSTR,c.POINTER(Startup),c.POINTER(Process)],w.BOOL),
      'ResumeThread':([w.HANDLE],w.DWORD),'WaitForSingleObject':([w.HANDLE,w.DWORD],w.DWORD),
      'GetExitCodeProcess':([w.HANDLE,c.POINTER(w.DWORD)],w.BOOL),'TerminateJobObject':([w.HANDLE,w.UINT],w.BOOL),
      'TerminateProcess':([w.HANDLE,w.UINT],w.BOOL),'CloseHandle':([w.HANDLE],w.BOOL),
      'QueryInformationJobObject':([w.HANDLE,c.c_int,c.c_void_p,w.DWORD,c.c_void_p],w.BOOL)}
    for name,(args,result) in signatures.items():fn=getattr(kernel,name);fn.argtypes=args;fn.restype=result
    def check(ok):
        if not ok:raise c.WinError(c.get_last_error())
    job=kernel.CreateJobObjectW(None,None);check(job)
    info=Process();assigned=False;cleanup_deadline=None
    try:
        limits=ExtendedLimit();limits.basic.flags=0x2000|0x200 # KILL_ON_JOB_CLOSE | JOB_MEMORY
        limits.job_memory=memory_mb*1024*1024
        check(kernel.SetInformationJobObject(job,9,c.byref(limits),c.sizeof(limits)))
        with open(os.devnull,'r+b',buffering=0) as null:
            handle=msvcrt.get_osfhandle(null.fileno());os.set_handle_inheritable(handle,True)
            startup=Startup();startup.cb=c.sizeof(startup);startup.dwFlags=0x100
            startup.hStdInput=startup.hStdOutput=startup.hStdError=handle
            environment=c.create_unicode_buffer('\0'.join(f'{k}={v}' for k,v in sorted(env.items(),key=lambda kv:kv[0].upper()))+'\0\0')
            line=c.create_unicode_buffer(subprocess.list2cmdline(command))
            # Assign while suspended: no descendant can escape between launch and assignment.
            check(kernel.CreateProcessW(command[0],line,None,None,True,0x4|0x400|0x08000000,environment,cwd,c.byref(startup),c.byref(info)))
        check(kernel.AssignProcessToJobObject(job,info.process));assigned=True
        check(kernel.ResumeThread(info.thread)!=0xffffffff)
        wait=kernel.WaitForSingleObject(info.process,min(0xfffffffe,max(1,math.ceil(timeout*1000))))
        if wait not in (0,258):raise c.WinError(c.get_last_error())
        code=w.DWORD();check(kernel.GetExitCodeProcess(info.process,c.byref(code)))
        status='timeout' if wait==258 else 'completed' if code.value==0 else 'worker_failed'
        check(kernel.TerminateJobObject(job,1))
        deadline=perf_counter()+CLEANUP_SECONDS;cleanup_deadline=deadline;reaped=False;tree_empty=False
        while perf_counter()<deadline:
            reaped=kernel.WaitForSingleObject(info.process,0)==0
            account=Accounting();check(kernel.QueryInformationJobObject(job,1,c.byref(account),c.sizeof(account),None))
            tree_empty=account.active==0
            if reaped and tree_empty:break
            sleep(.005)
        if not (reaped and tree_empty):status='cleanup_failed'
        check(kernel.GetExitCodeProcess(info.process,c.byref(code)))
        return {'status':status,'returncode':code.value,'pid':info.pid,'process_reaped':reaped,'tree_reaped':tree_empty,
                'tree_termination_requested':True,'containment':'windows_job','memory_scope':'job_aggregate_commit'}
    finally:
        if info.process:
            if assigned:kernel.TerminateJobObject(job,1)
            else:kernel.TerminateProcess(info.process,1) # Still suspended, so no descendants.
            remaining=CLEANUP_SECONDS if cleanup_deadline is None else max(0.,cleanup_deadline-perf_counter())
            kernel.WaitForSingleObject(info.process,int(remaining*1000))
        for handle in (info.thread,info.process,job):
            if handle:kernel.CloseHandle(handle)
