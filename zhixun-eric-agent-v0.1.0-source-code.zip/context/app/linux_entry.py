"""Linux development entry. Explicit live flag; runtime credential on stdin only."""
from pathlib import Path
import argparse
import json
import re
import shutil
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import linux_offline_entry as offline


def engine_module():
    sys.path.insert(0, str(offline.CODE))
    import official_unified_entry_v1
    return official_unified_entry_v1


def freeze(output, tasks, fits):
    result = offline.freeze(output, tasks, fits)
    offline.write(Path(output) / 'LINUX-ENTRY-PIN.json', {
        'plan_sha256': result['plan_sha256'],
        'app_manifest_sha256': offline.sha(offline.ROOT / 'APP-MANIFEST.json'),
        'entry_source_sha256': offline.sha(Path(__file__)),
        'credential_transport': 'stdin_memory_only', 'official_sdk_compatible': False})
    return {**result, 'live_entry_implemented': True, 'credential_loaded': False}


def preflight(plan_folder, output, expected, live):
    if live is not True:
        raise ValueError('explicit_live_flag_required')
    if not isinstance(expected, str) or not re.fullmatch('[a-f0-9]{64}', expected):
        raise ValueError('external_plan_hash_required')
    offline.verify()
    engine = engine_module()
    plan_folder, output = Path(plan_folder).resolve(), Path(output).resolve()
    plan = engine.verify(plan_folder, offline.INPUTS)
    pin = offline.load(plan_folder / 'LINUX-ENTRY-PIN.json')
    if (offline.sha(plan_folder / 'plan.json') != expected or pin['plan_sha256'] != expected
            or pin['app_manifest_sha256'] != offline.sha(offline.ROOT / 'APP-MANIFEST.json')
            or pin['entry_source_sha256'] != offline.sha(Path(__file__))):
        raise ValueError('linux_external_plan_or_entry_changed')
    if (output.exists() or output.is_relative_to(offline.ROOT)
            or output.is_relative_to(plan_folder) or plan_folder.is_relative_to(output)):
        raise ValueError('output_exists_or_overlaps_plan_or_app')
    if plan['synthetic_fixture'] or plan['provider'] != {
            'endpoint': 'https://pytrio.com/api/openai/v1', 'model': 'Qwen/Qwen3.8-27B',
            'timeout': 90, 'output_tokens': 4096, 'input_bytes': 60000,
            'temperature': 0, 'thinking': 'provider default'}:
        raise ValueError('live_plan_provider_changed')
    for task, item in plan['tasks'].items():
        limits = item['budgets']
        fits = limits['fits']
        if (type(fits) is not int or not 1 <= fits <= 3 or limits['decisions'] != fits
                or limits['provider_calls'] != fits * (4 if task == 'A' else 2)):
            raise ValueError('linux_development_budget_changed')
        engine.datasets(offline.INPUTS / item['package'], task)
    return engine, plan_folder, output, plan


def read_credential(stream, plan):
    # Do not read a path, environment variable or command-line credential.
    raw = stream.read(4097)
    if not raw or len(raw) > 4096:
        raise ValueError('runtime_credential_required_or_too_large')
    sys.path.insert(0, str(offline.CODE))
    from official_training_v2 import strict_json
    from qwen_config import validate_credential_provider
    config = strict_json(raw.decode('utf-8'))
    if not isinstance(config, dict) or set(config) != {'api_key', 'base_url', 'model'}:
        raise ValueError('runtime_credential_fields_invalid')
    if (config['base_url'], config['model']) != (plan['provider']['endpoint'], plan['provider']['model']):
        raise ValueError('runtime_provider_does_not_match_plan')
    key = config['api_key']
    if not isinstance(key, str) or not re.fullmatch('[A-Za-z0-9_.-]{12,512}', key):
        raise ValueError('runtime_credential_invalid')
    validate_credential_provider(key, config['base_url'])
    return config


def run_live(plan_folder, output, expected, live, stream):
    # All expensive/data/output checks happen before reading the runtime secret.
    engine, plan_folder, output, plan = preflight(plan_folder, output, expected, live)
    config = read_credential(stream, plan)
    from experiment_records import Recorder, LocalBackend
    output.mkdir(parents=True, exist_ok=False)
    shutil.copytree(plan_folder, output / 'frozen-plan')
    (output / 'source').mkdir()
    for name in engine.SOURCES:
        shutil.copyfile(engine.CODE / name, output / 'source' / name)
    for name in ['linux_entry.py', 'linux_offline_entry.py', 'APP-MANIFEST.json']:
        shutil.copyfile(offline.ROOT / name, output / 'source' / name)
    recorder = Recorder('linux-unified-live-v2', LocalBackend(output / 'records.jsonl'))
    results, status = {}, 'completed'
    recorder.emit('run_start', 'setup', fields={'plan_sha256': expected,
        'app_manifest_sha256': offline.sha(offline.ROOT / 'APP-MANIFEST.json'),
        'mode': 'qwen_live', 'credential_transport': 'stdin_memory_only',
        'sdk_compatible': False, 'cloud_synced': False, 'platform_runs': 0})
    try:
        for task, item in plan['tasks'].items():
            if status == 'host_failure':
                results[task] = {'status': 'not_started'}
                continue
            recorder.emit('task_start', 'control', fields={'task': task, 'budgets': item['budgets']})
            try:
                offline.verify()
                engine.verify(plan_folder, offline.INPUTS)
                recipes = [engine.Recipe.from_dict(r) for r in item['recipes']]
                actions = engine.FinishActions(recipes) if task == 'A' else engine.ActionSpace(recipes)
                system = engine.CODE_SYSTEM if task == 'A' else engine.PARAM_SYSTEM
                system += f' 任务{task}；单位{item["units"]}；本地开发工程门槛，非官方评分。'
                client = engine.QwenClient(**config, max_calls=item['budgets']['provider_calls'],
                    max_output_tokens=plan['provider']['output_tokens'],
                    max_input_bytes=plan['provider']['input_bytes'], timeout=plan['provider']['timeout'],
                    task_system=system, action_validator=actions.parse)
                # Same real HTTPS route used by the verified Windows entry.
                # Construct without injection so source fields remain truthful.
                client._transport = engine.direct_post_json
                result = engine.run_task(task, item, offline.INPUTS / item['package'],
                                         output / task, client, live=True)
                engine.verify(plan_folder, offline.INPUTS)
                offline.verify()
            except Exception as exc:
                result = {'task': task, 'status': 'host_failure',
                    'reason': 'host_io_failed' if isinstance(exc, OSError) else 'host_operation_failed',
                    'budget_refunded': False, 'usage_complete': False, 'automatic_retry': False,
                    'fit_attempts': None, 'provider_reservations': None, 'export': None,
                    'partial_files_sha256': {p.relative_to(output / task).as_posix(): offline.sha(p)
                        for p in sorted((output / task).rglob('*')) if p.is_file()}}
                status = 'host_failure'
            results[task] = result
            recorder.emit('task_completed', 'control', fields={'task': task, 'result': result,
                'task_result_sha256': offline.sha(output / task / 'task-result.json')
                                     if (output / task / 'task-result.json').is_file() else None})
        if status != 'host_failure' and any(r['status'] not in {'completed', 'finished'}
                or r['training_failures'] for r in results.values()):
            status = 'completed_with_failures'
        report = {'schema': 'linux-unified-live-result-v2', 'status': status, 'tasks': results,
                  'mode': 'qwen_live', 'credential_transport': 'stdin_memory_only',
                  'plan_sha256': expected, 'sdk_compatible': False, 'cloud_synced': False,
                  'platform_runs': 0, 'formal_requirement_satisfied': False, 'claude_reviewed': False}
        offline.write(output / 'result.json', report)
        recorder.emit('run_end', 'complete', fields={'status': status,
                      'result_sha256': offline.sha(output / 'result.json')})
        offline.write(output / 'EXTERNAL-TAIL.json', {'records': recorder.sequence,
            'tail_sha256': recorder.previous, 'records_sha256': offline.sha(output / 'records.jsonl')})
        return report
    finally:
        config.clear()
        recorder.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('check')
    prediction = commands.add_parser('predict')
    prediction.add_argument('--task', choices=list('ABC'), required=True)
    prediction.add_argument('--input', required=True)
    prediction.add_argument('--output', required=True)
    plan = commands.add_parser('freeze-development')
    plan.add_argument('--tasks', nargs='+', choices=list('ABC'), default=list('ABC'))
    plan.add_argument('--max-fits', type=int, default=1)
    plan.add_argument('--output', required=True)
    live = commands.add_parser('train-live')
    live.add_argument('--plan', required=True)
    live.add_argument('--expected-plan-sha256', required=True)
    live.add_argument('--output', required=True)
    live.add_argument('--live', action='store_true')
    args = parser.parse_args()
    if args.command == 'check':
        result = {**offline.check(), 'live_entry_implemented': True, 'credential_loaded': False}
    elif args.command == 'predict':
        result = offline.predict(args.task, args.input, args.output)
    elif args.command == 'freeze-development':
        result = freeze(args.output, args.tasks, args.max_fits)
    else:
        report = run_live(args.plan, args.output, args.expected_plan_sha256, args.live, sys.stdin.buffer)
        result = {'status': report['status'], 'tasks': list(report['tasks']),
                  'credential_transport': report['credential_transport'], 'platform_runs': 0}
    print(json.dumps(result, ensure_ascii=False, allow_nan=False))


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        # Never dump stdin, config, provider response bodies, tracebacks or secrets.
        print(json.dumps({'status': 'entry_rejected', 'error_type': type(exc).__name__,
                          'reason': 'preflight_or_runtime_failed'}), file=sys.stderr)
        raise SystemExit(1)
